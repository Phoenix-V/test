import os
import inspect

from collections import OrderedDict

import sys
sys.path.append("src")
import pdb
from training_local.params import get_default_params

# /large_experiments/cmd/m2c2/cit/phoenix
class Config:
    train_data = "/datasets01/laion400m/laion400m-met-release/laion400m-dataset/{00000..41455}.tar"
    index_dir = '/checkpoint/phoenixma/full_data/clustering_laion/index'
    group_dir = '/checkpoint/phoenixma/full_data/clustering_laion/group_index_summary'
    val_data = None
    train_num_samples = None
    val_num_samples = None
    dataset_type = "auto"
    dataset_resampled = False
    csv_separator = "\t"
    csv_img_key = "filepath"
    csv_caption_key = "title"
    # imagenet_val = "/datasets01/imagenet_full_size/061417/val"
    imagenet_val = "/dvmm-filer2/datasets/ImageNet/val-folder"
    imagenet_v2 = None
    logs = "./logs/"
    log_local = False
    name = "ViT-B-32"
    workers = 4
    batch_size = 512
    epochs = 32
    lr = None
    beta1 = None
    beta2 = None
    eps = None
    wd = 0.2
    # model_index='all'
    warmup = 2000  # 10000
    use_bn_sync = False
    skip_scheduler = False
    save_frequency = 1
    save_most_recent = True  # False
    zeroshot_frequency = 1
    val_frequency = 1
    resume = None
    precision = "amp"
    clip_model = "CLIP"
    model = "ViT-B-32"
    pretrained = ''
    pretrained_image = False
    lock_image = False
    lock_image_unlocked_groups = 0
    lock_image_freeze_bn_stats = False
    grad_checkpointing = False
    local_loss = False
    gather_with_grad = True
    force_quick_gelu = True
    torchscript = False
    trace = False
    dist_url = "env://"
    dist_backend = "nccl"
    report_to = "tensorboard"
    wandb_notes = ''
    debug = False
    copy_codebase = False
    horovod = False
    ddp_static_graph = False
    no_set_device_rank = False
    seed = 0
    norm_gradient_clip = None
    # New added
    lit_mode='ori'
    routing=False
    fixscale=False
    init_epoch=-1
    mask_ratio=0.0
    num_groups=1

    distributed_engine = "ddp"
    fsdp_init_on_cpu = False
    fsdp_cpu_offload = False
    fsdp_limit_allgathers = False
    fsdp_layers_to_wrap = (
        # Match all sort of blocks
        '.*Block.*',
        'Bottleneck',
        # CLIP
        'VisualTransformer',
        'Transformer',
        # CLIP ModifiedResNet
        'ModifiedResNet',
        # HF Text
        'HFTextEncoder',
        # TIMM visual
        'TimmModel',
    )
    fsdp_layers_to_grad_checkpoint = (
        '.*Block.*',
        'Bottleneck',
    )

    def __init__(self, overwrite=None, **kwargs):
        for key in kwargs:
            setattr(self, key, kwargs[key])
        if overwrite is not None or len(overwrite) > 0:
            for key in overwrite:
                setattr(self, key, overwrite[key])

        if not hasattr(self, "output_dir"):
            # self.name = inspect.stack()[1][3]  # not correct anymore
            import sys
            self.name = sys.argv[1]
            # if len(sys.argv) >= 4:
            #     self.name = '{}_{}'.format(self.name, sys.argv[3])

            if len(sys.argv) == 4:
                assert int(sys.argv[3]) in [0,2,3]
                self.seed = int(sys.argv[2]) if len(sys.argv[2]) == 1 else sys.argv[2]
                self.random_init = (int(sys.argv[3]) == 3)
                self.feat_norm = (int(sys.argv[3]) == 0)
            
            if hasattr(self,'model_index') and isinstance(self.model_index,str):
                assert self.model_index == 'all'
                self.model_index = [i for i in range(self.seed)]
        
        if hasattr(self,'model_index'):
            ckpt_list = param_dict['ori' if self.cmode == 'ori' else 'clip'][self.seed]
            index = self.model_index if isinstance(self.model_index,int) else ''.join([str(i) for i in self.model_index])
            if isinstance(self.model_index,list) and len(self.model_index) > 10 and len(self.model_index) == self.model_index[-1] + 1:
                index = 'all'
            cmode = '' if isinstance(self.model_index,int) else self.cmode[-3:]
            self.name += '_L{}I{}_S{}'.format(self.seed, index,self.seed)
            if cmode:
                self.name = '{}_{}'.format(cmode,self.name)
            self.name += '/{}'.format('linear' if self.linear_prob else 'finetune')
            if hasattr(self,'random_init') and self.random_init:
                self.name += 'rand'
            if hasattr(self, 'feat_norm') and not self.feat_norm:
                self.name += 'dot'
            

        if hasattr(self, "adjust_shards") and self.adjust_shards and hasattr(self, "train_data"):
            from training_local import m2c2_wds
            start, end = parse_start_end(self.train_data)
            data_dir = os.path.dirname(self.train_data)
            num_shards, num_true, num_example = estimate_num_shard(data_dir, m2c2_wds.ItemFilter(self), self.train_num_samples, start)
            self.train_data = os.path.join(data_dir, f"{{{start}..{num_shards - 1}}}.tar")
            print(f"change config.train_data={self.train_data} ({num_true}/{num_example} on shard_id={start})")
        
        self.output_dir = os.path.join(self.logs, self.name)
        self.extra_from_params()

    def extra_from_params(self):
        args = self
        # If some params are not passed, we use the default values based on model name.
        default_params = get_default_params(args.model)
        for name, val in default_params.items():
            if getattr(args, name) is None:
                setattr(args, name, val)

    def add_cmd_args(self, cmd_args):
        for key, value in vars(cmd_args).items():
            if not key.startswith("__"):
                setattr(self, key, value)
        return self

    def __str__(self):
        return "\n".join([f"{k}={v}" for k, v in vars(self).items()])


def parse_start_end(shards):
    start, end = os.path.basename(shards).split("{")[1].split("}")[0].split("..")
    return int(start), int(end)


def estimate_num_shard(data_dir, filter_fn, train_num_samples, shard_id=0):
    import tarfile
    import json
    import math
    # estimate number of examples per shard.
    num_true, num_example = 0, 0
    with tarfile.open(os.path.join(data_dir, f"{shard_id % 100}", f"{shard_id}.tar")) as tar:
        members = tar.getmembers()
        for member in members:
            if member.name.endswith(".json"):
                num_example += 1
                with tar.extractfile(member) as f:
                    text_json = json.load(f)
                    if filter_fn({"json": text_json}):
                        num_true += 1
    num_shards = math.ceil(train_num_samples / num_true)
    return num_shards, num_true, num_example


def search_config(config_name):
    import importlib
    project_dir = os.path.dirname(__file__)
    all_configs = {}
    for code in os.listdir(project_dir):
        if code.endswith(".py") and code.startswith("run_configs"):
            print(f"searching config in {code}")
            module = importlib.import_module(code[:-3])
            for _config_name in dir(module):
                if _config_name in ["Config"] or _config_name.startswith("__") or _config_name.startswith("run_config"):
                    continue
                if _config_name not in all_configs:
                    all_configs[_config_name] = module
    print(f"launching {config_name} from {all_configs[config_name].__file__}")
    config = getattr(all_configs[config_name], config_name)()
    return config


def build_from_sweep_config(sweep_config):
    sweep_dict = OrderedDict()
    key_to_short = OrderedDict()
    key_to_card = OrderedDict()
    sweep_name = sweep_config.__name__
    cards = 1
    for key, value in vars(sweep_config).items():
        if not key.startswith("__"):
            sweep_dict[key] = value[0] if isinstance(value, tuple) else value
            cards *= len(sweep_dict[key])
            key_to_card[key] = len(sweep_dict[key])
            key_to_short[key] = value[1] if isinstance(value, tuple) else ""

    all_update_dicts = []
    for sweep_idx in range(cards):
        key_to_idx = OrderedDict()
        for key in key_to_card:
            key_to_idx[key] = sweep_idx % key_to_card[key]
            sweep_idx = sweep_idx // key_to_card[key]
        update_dict = OrderedDict()
        for key, idx in key_to_idx.items():
            update_dict[key] = sweep_dict[key][idx]
        update_dict["output_dir"] = "_".join([value+str(update_dict[key]).replace("/", ".") for key, value in key_to_short.items()])
        update_dict["output_dir"] = os.path.join(sweep_name, update_dict["output_dir"])
        all_update_dicts.append(update_dict)

    assert len(all_update_dicts) == cards
    return all_update_dicts