import torch
import copy
import os
import pdb
import torch.nn as nn
import torch.nn.functional as F

def torch_save(classifier, save_path):
    if os.path.dirname(save_path) != '':
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
    torch.save(classifier.state_dict(),save_path)
    # with open(save_path, 'wb') as f:
    #     pickle.dump(classifier.cpu(), f)


def torch_load(save_path, device=None):
    with open(save_path, 'rb') as f:
        classifier = pickle.load(f)
    if device is not None:
        classifier = classifier.to(device)
    return classifier


class ImageEncoder(torch.nn.Module):
    def __init__(self, model, processes, keep_lang=False, combine_mode=False):
        super().__init__()
        combine_mode = False # Just a place holder
        self.model = model
        self.train_preprocess = processes[0]
        self.val_preprocess = processes[1]

        if not keep_lang and hasattr(self.model, 'transformer'):
            delattr(self.model, 'transformer')

    def forward(self, images):
        assert self.model is not None
        return self.model.encode_image(images)

    def save(self, filename):
        print(f'Saving image encoder to {filename}')
        torch_save(self, filename)

    @classmethod
    def load(cls, filename):
        print(f'Loading image encoder from {filename}')
        return torch_load(filename)


class ImageEncoderGroup(torch.nn.Module):
    def __init__(self, model, processes, keep_lang=False, combine_mode='concat'):
        super().__init__()

        self.model = nn.ModuleList(model)
        self.combine_mode = combine_mode

        self.train_preprocess = processes[0]
        self.val_preprocess = processes[1]

        for i in range(len(self.model)):
            if not keep_lang and hasattr(self.model[i], 'transformer'):
                delattr(self.model[i], 'transformer')
                print('delete attr for model {}'.format(i))

    def forward(self, images):

        features = []
        for i in range(len(self.model)):
            feat = self.model[i].encode_image(images)
            features.append(feat) # F.normalize(feat,dim=-1)

        if self.combine_mode == 'add':
            features = torch.stack(features,dim=0)
        elif self.combine_mode == 'concat':
            pass
            # features = torch.cat(features,dim=-1)

        return features

    def save(self, filename):
        print(f'Saving image encoder to {filename}')
        torch_save(self, filename)


    @classmethod
    def load(cls, filename):
        print(f'Loading image encoder from {filename}')
        return torch_load(filename)


class ClassificationHead(torch.nn.Linear):
    def __init__(self, normalize, weights, biases=None):
        output_size, input_size = weights.shape
        super().__init__(input_size, output_size)
        self.normalize = normalize
        if weights is not None:
            self.weight = torch.nn.Parameter(weights.clone())
        if biases is not None:
            self.bias = torch.nn.Parameter(biases.clone())
        else:
            self.bias = torch.nn.Parameter(torch.zeros_like(self.bias))

    def forward(self, inputs):
        if self.normalize:
            if isinstance(inputs,list):
                inputs = [item / item.norm(dim=-1, keepdim=True) for item in inputs]
            else:
                inputs = inputs / inputs.norm(dim=-1, keepdim=True)
        if isinstance(inputs,list): # concatenation
            inputs = torch.cat(inputs,dim=-1)
        elif len(inputs.size()) == 3: # stack
            inputs = inputs.mean(dim=0)
        return super().forward(inputs)

    def save(self, filename):
        print(f'Saving classification head to {filename}')
        torch_save(self, filename)

    @classmethod
    def load(cls, filename):
        print(f'Loading classification head from {filename}')
        return torch_load(filename)


class ImageClassifier(torch.nn.Module):
    def __init__(self, image_encoder, classification_head, process_images=True):
        super().__init__()
        self.image_encoder = image_encoder
        self.classification_head = classification_head
        self.process_images = process_images
        # if self.image_encoder is not None:
        #     self.train_preprocess = self.image_encoder.train_preprocess
        #     self.val_preprocess = self.image_encoder.val_preprocess

    def forward(self, inputs):
        if self.process_images:
            inputs = self.image_encoder(inputs)
        outputs = self.classification_head(inputs)
        return outputs

    def save(self, filename):
        print(f'Saving image classifier to {filename}')
        torch_save(self, filename)

    @classmethod
    def load(cls, filename):
        print(f'Loading image classifier from {filename}')
        return torch_load(filename)