import ast
import json
import logging
import math
import os
import random
import sys
sys.path.append(".")
from dataclasses import dataclass
from multiprocessing import Value
from functools import partial
import torchvision.transforms as transforms

from PIL import Image, ImageFilter, ImageOps
# import braceexpand
import numpy as np
import pandas as pd
import torch
import torchvision.datasets as datasets
# import webdataset as wds
from PIL import Image
from torch.utils.data import Dataset, DataLoader, SubsetRandomSampler, IterableDataset, get_worker_info
from torch.utils.data.distributed import DistributedSampler
# from webdataset.filters import _shuffle
# from webdataset.tariterators import base_plus_ext, url_opener, tar_file_expander, valid_sample
import pdb
import random
# from torch.nn.functional import InterpolationMode

try:
    import horovod.torch as hvd
except ImportError:
    hvd = None

from open_clip import tokenize


class CsvDataset(Dataset):
    def __init__(self, input_filename, transforms, img_key, caption_key, sep="\t"):
        logging.debug(f'Loading csv data from {input_filename}.')
        df = pd.read_csv(input_filename, sep=sep)

        self.images = df[img_key].tolist()
        self.captions = df[caption_key].tolist()
        self.transforms = transforms
        logging.debug('Done loading data.')

    def __len__(self):
        return len(self.captions)

    def __getitem__(self, idx):
        images = self.transforms(Image.open(str(self.images[idx])))
        texts = tokenize([str(self.captions[idx])])[0]
        return images, texts


class SharedEpoch:
    def __init__(self, epoch: int = 0):
        self.shared_epoch = Value('i', epoch)

    def set_value(self, epoch):
        self.shared_epoch.value = epoch

    def get_value(self):
        return self.shared_epoch.value


@dataclass
class DataInfo:
    dataloader: DataLoader
    sampler: DistributedSampler = None
    shared_epoch: SharedEpoch = None

    def set_epoch(self, epoch, step=0):
        if self.shared_epoch is not None:
            self.shared_epoch.set_value(epoch)
        if self.sampler is not None and isinstance(self.sampler, DistributedSampler):
            self.sampler.set_epoch(epoch)
        if hasattr(self.dataloader, "dataset") and hasattr(self.dataloader.dataset, "set_epoch"):
            self.dataloader.dataset.set_epoch(epoch, self.dataloader.num_batches, step)


from .imagenet_zeroshot_data import imagenet_classnames
IMGNET_STR = ' '.join(imagenet_classnames).lower()
IMGNET_STR = IMGNET_STR.replace('/', '').split()

def save_local(file_str): # 
    if file_str is None:
        return None
    if len(file_str) == 0:
        return None
    file_str = file_str.decode('utf-8')
    if file_str in ['"',]:
        return None
    len_str = len(file_str)
    file_str_comp = [item for item in file_str.split(' ') if len(item) > 0] 
    init_str = ''.join([item[0] for item in file_str_comp[:3]])
    init_str = '{}-{}'.format(len_str,init_str)
    return init_str, file_str

def filter_cluster(sample, grp_asign, grp_map, ratio, non_ratio=0.0):
    file_str = sample['txt']
    output = save_local(file_str)
    if output is None:
        return False
    key,raw_text = output
    # check group
    if key not in sample['__group__']:
        return False
    else:
        grp = -1
        for item in sample['__group__'][key]:
            if raw_text == item['str']:
                grp = item['gid']
        if grp < 0:
            return False if non_ratio == 0.0 else  np.random.rand(1).item() < non_ratio
        else:
            new_group = grp if grp_map is None else grp_map[grp]
            if new_group == grp_asign:
                return True
            else:
                return np.random.rand(1).item() < ratio
    

def filter_no_imagenet(sample):
    words  = str(sample['txt']).lower().split()
    return len(set(words).intersection(IMGNET_STR)) > 0

def filter_imagenet_free(sample):
    words  = str(sample['txt']).lower().split()
    return len(set(words).intersection(IMGNET_STR)) == 0

from clipeval import eval_zeroshot
_,_,all_labels = eval_zeroshot.load_metadata("clipeval")


def preprocess_txt(text):
    # print('before preproc', text)
    return tokenize([str(text)])[0]

def get_dataset_size(shards):
    print('this should not happen for ImageNet')
    shards_list = list(braceexpand.braceexpand(shards))
    dir_path = os.path.dirname(shards)
    sizes_filename = os.path.join(dir_path, 'sizes.json')
    len_filename = os.path.join(dir_path, '__len__')
    if os.path.exists(sizes_filename):
        sizes = json.load(open(sizes_filename, 'r'))
        total_size = sum([int(sizes[os.path.basename(shard)]) for shard in shards_list])
    elif os.path.exists(len_filename):
        # FIXME this used to be eval(open(...)) but that seemed rather unsafe
        total_size = ast.literal_eval(open(len_filename, 'r').read())
    else:
        total_size = None  # num samples undefined
        # some common dataset sizes (at time of authors last download)
        # CC3M (train): 2905954
        # CC12M: 10968539
        # LAION-400M: 407332084
        # LAION-2B (english): 2170337258
    num_shards = len(shards_list)
    return total_size, num_shards

class GaussianBlur(object):
    """Gaussian blur augmentation from SimCLR: https://arxiv.org/abs/2002.05709"""

    def __init__(self, sigma=[.1, 2.]):
        self.sigma = sigma

    def __call__(self, x):
        sigma = random.uniform(self.sigma[0], self.sigma[1])
        x = x.filter(ImageFilter.GaussianBlur(radius=sigma))
        return x

class ContrastiveLearningViewGenerator(object):
    """Take two random crops of one image as the query and key."""

    def __init__(self, base_transform, n_views=2):
        self.base_transform = base_transform
        self.aug_transform = transforms.Compose([
            transforms.RandomResizedCrop(224, scale=(0.9, 1.)), # interpolation=InterpolationMode.BICUBIC
            transforms.RandomApply([
                transforms.ColorJitter(0.4, 0.4, 0.2, 0.1)  # not strengthened
            ], p=0.8),
            transforms.RandomGrayscale(p=0.2),
            transforms.RandomApply([GaussianBlur([.1, 2.])], p=1.0),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.48145466, 0.4578275, 0.40821073], std=[0.26862954, 0.26130258, 0.27577711])
        ])
        self.n_views = n_views
        print(base_transform)

    def __call__(self, x):
        return [self.base_transform(x), self.aug_transform(x)]

def get_imagenet(args, preprocess_fns, split, epoch=0):
    assert split in ["train", "val", "v2"]
    print('loading images for {}'.format(split))
    is_train = split == "train"
    preprocess_train, preprocess_val = preprocess_fns

    if split == "v2":
        raise ValueError('Not Implemented Yet')
        from imagenetv2_pytorch import ImageNetV2Dataset
        dataset = ImageNetV2Dataset(location=args.imagenet_v2, transform=preprocess_val)
    else:
        if epoch == -1:
            data_path = args.imagenet_train
            preprocess_fn = ContrastiveLearningViewGenerator(preprocess_val)
        elif is_train:
            data_path = args.imagenet_train
            preprocess_fn = preprocess_train
        else:
            data_path = args.imagenet_val
            preprocess_fn = preprocess_val
        assert data_path

        dataset = datasets.ImageFolder(data_path, transform=preprocess_fn)
    sampler=None
    if is_train:
        idxs = np.zeros(len(dataset.targets))
        target_array = np.array(dataset.targets)
        k = 50 if epoch==-1 else 600
        for c in range(1000):
            m = target_array == c
            n = len(idxs[m])
            arr = np.zeros(n)
            arr[:k] = 1
            if epoch >=-1:
                np.random.shuffle(arr)
            idxs[m] = arr

        idxs = idxs.astype('int')
        sampler = SubsetRandomSampler(np.where(idxs)[0])
    else:
        sampler = None

    dataloader = torch.utils.data.DataLoader(
        dataset,
        batch_size=args.batch_size if is_train else 512,
        num_workers=args.workers,
        sampler=sampler,
        shuffle=is_train and sampler is None,
    )

    return DataInfo(dataloader=dataloader, sampler=sampler)


def count_samples(dataloader):
    os.environ["WDS_EPOCH"] = "0"
    n_elements, n_batches = 0, 0
    for images, texts in dataloader:
        n_batches += 1
        n_elements += len(images)
        assert len(images) == len(texts)
    return n_elements, n_batches


def filter_no_caption(sample):
    # print(sample.keys())
    # dict_keys(['__key__', '__url__', 'jpg', 'json', 'txt'])
    # if 'txt' in sample:
    #     print(len(sample['txt']),sample['txt'])
    return 'txt' in sample


def log_and_continue(exn):
    """Call in an exception handler to ignore any exception, isssue a warning, and continue."""
    logging.warning(f'Handling webdataset error ({repr(exn)}). Ignoring.')
    return True


# def group_by_keys_nothrow(data, keys=base_plus_ext, lcase=True, suffixes=None, handler=None):
#     """Return function over iterator that groups key, value pairs into samples.

#     :param keys: function that splits the key into key and extension (base_plus_ext)
#     :param lcase: convert suffixes to lower case (Default value = True)
#     """
#     current_sample = None
#     for filesample in data:
#         assert isinstance(filesample, dict)
#         fname, value = filesample["fname"], filesample["data"]
#         prefix, suffix = keys(fname)
#         if prefix is None:
#             continue
#         if lcase:
#             suffix = suffix.lower()
#         # FIXME webdataset version throws if suffix in current_sample, but we have a potential for
#         #  this happening in the current LAION400m dataset if a tar ends with same prefix as the next
#         #  begins, rare, but can happen since prefix aren't unique across tar files in that dataset
#         if current_sample is None or prefix != current_sample["__key__"] or suffix in current_sample:
#             if valid_sample(current_sample):
#                 yield current_sample
#             current_sample = dict(__key__=prefix, __url__=filesample["__url__"])
#         if suffixes is None or suffix in suffixes:
#             current_sample[suffix] = value
#     if valid_sample(current_sample):
#         yield current_sample


# def group_by_keys_nothrow_group(data, keys=base_plus_ext, lcase=True, suffixes=None, handler=None):
#     """Return function over iterator that groups key, value pairs into samples.

#     :param keys: function that splits the key into key and extension (base_plus_ext)
#     :param lcase: convert suffixes to lower case (Default value = True)
#     """
#     current_sample = None
#     group_data = None
#     for filesample in data:
#         assert isinstance(filesample, dict)
#         fname, value = filesample["fname"], filesample["data"]
#         if group_data is None and '__url__' in filesample:
#             tar_id = int(filesample['__url__'].split('/')[-1][:5])
#             shard_folder = tar_id % 100
#             json_path = f'/checkpoint/phoenixma/full_data/clustering_laion/K8B1-Caption/{shard_folder}/{tar_id}_group.json'
#             # json_path = f'/checkpoint/phoenixma/full_data/clustering_laion/ClipFeat-Cluster/{shard_folder}/{tar_id}_group.json'
#             with open(json_path,'r') as json_file:
#                 group_data = json.load(json_file)

#         prefix, suffix = keys(fname)
#         if prefix is None:
#             continue
#         if lcase:
#             suffix = suffix.lower()
#         # FIXME webdataset version throws if suffix in current_sample, but we have a potential for
#         #  this happening in the current LAION400m dataset if a tar ends with same prefix as the next
#         #  begins, rare, but can happen since prefix aren't unique across tar files in that dataset
#         if current_sample is None or prefix != current_sample["__key__"] or suffix in current_sample:
#             if valid_sample(current_sample):
#                 yield current_sample
#             current_sample = dict(__key__=prefix, __url__=filesample["__url__"], __group__=group_data)
#         if suffixes is None or suffix in suffixes:
#             current_sample[suffix] = value
#     if valid_sample(current_sample):
#         yield current_sample


def tarfile_to_samples_nothrow(src, handler=log_and_continue):
    # NOTE this is a re-impl of the webdataset impl with group_by_keys that doesn't throw
    streams = url_opener(src, handler=handler)
    files = tar_file_expander(streams, handler=handler)
    samples = group_by_keys_nothrow_group(files, handler=handler)
    return samples


def pytorch_worker_seed():
    """get dataloader worker seed from pytorch"""
    worker_info = get_worker_info()
    if worker_info is not None:
        # favour the seed already created for pytorch dataloader workers if it exists
        return worker_info.seed
    # fallback to wds rank based seed
    return wds.utils.pytorch_worker_seed()


_SHARD_SHUFFLE_SIZE = 2000
_SHARD_SHUFFLE_INITIAL = 500
_SAMPLE_SHUFFLE_SIZE = 5000
_SAMPLE_SHUFFLE_INITIAL = 1000


class ResampledShards2(IterableDataset):
    """An iterable dataset yielding a list of urls."""

    def __init__(
        self,
        urls,
        nshards=sys.maxsize,
        worker_seed=None,
        deterministic=False,
        epoch=-1,
    ):
        """Sample shards from the shard list with replacement.

        :param urls: a list of URLs as a Python list or brace notation string
        """
        super().__init__()
        urls = wds.shardlists.expand_urls(urls)
        self.urls = urls
        assert isinstance(self.urls[0], str)
        self.nshards = nshards
        self.rng = random.Random()
        self.worker_seed = pytorch_worker_seed if worker_seed is None else worker_seed
        self.deterministic = deterministic
        self.epoch = epoch

    def __iter__(self):
        """Return an iterator over the shards."""
        if isinstance(self.epoch, SharedEpoch):
            epoch = self.epoch.get_value()
        else:
            # NOTE: this is epoch tracking is problematic in a multiprocess (dataloader workers or train)
            # situation as different workers may wrap at different times (or not at all).
            self.epoch += 1
            epoch = self.epoch
        if self.deterministic:
            # reset seed w/ epoch if deterministic, worker seed should be deterministic due to arg.seed
            self.rng.seed(self.worker_seed() + epoch)
        for _ in range(self.nshards):
            yield dict(url=self.rng.choice(self.urls))



def get_data(args, preprocess_fns, epoch=0):
    preprocess_train, preprocess_val = preprocess_fns
    data = {}

    # if args.train_data:
    #     print('train_data should not show up here')
    #     data["train"] = get_dataset_fn(args.train_data, args.dataset_type, args)(
    #         args, preprocess_train, is_train=True, epoch=epoch)

    # if args.val_data:
    #     data["val"] = get_dataset_fn(args.val_data, args.dataset_type, args)(
    #         args, preprocess_val, is_train=False)

    if args.imagenet_val is not None:
        data["imagenet-val"] = get_imagenet(args, preprocess_fns, "val")
    
    # if args.imagenet_train is not None:
    #     data["imagenet-train"] = get_imagenet(args, preprocess_fns, "train", epoch=epoch)

    # if args.imagenet_v2 is not None:
    #     data["imagenet-v2"] = get_imagenet(args, preprocess_fns, "v2")

    return data
