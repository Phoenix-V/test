import os
import json

import torch
import numpy as np
import pdb
from tqdm import tqdm

def eval_single_dataset(model, datainfo, args):
    
    model.eval()
    batched_data = enumerate(datainfo.dataloader)
    device = args.device

    with torch.no_grad():
        top1, correct, n = 0., 0., 0.
        for i, data in tqdm(batched_data):
            x = data[0].to(device)
            y = data[1].to(device)
            
            logits = model(x) 

            pred = logits.argmax(dim=1, keepdim=False).to(device)
            acc1 = torch.eq(pred, y)
            correct += acc1.sum()
            n += len(pred)

    top1 = correct / n
    return {'top1':top1}

def evaluate(image_classifier, dataloader_dict, args, epoch):
    info_full = vars(args)
    info = {'epoch':epoch}
    for key in  ["imagenet_train", "seed", "model_index", "lr", "batch_size", "linear_prob", "warmup",  "model"]:
        info[key] = info_full[key]
    for dataset_name, dataset in dataloader_dict.items():
        print('Evaluating on', dataset_name)
        results = eval_single_dataset(image_classifier, dataset, args)

        if 'top1' in results:
            print(f"{dataset_name} Top-1 accuracy: {results['top1']:.4f}")
        for key, val in results.items():
            info[dataset_name + ':' + key] = val.cpu().item()

    dirname = os.path.dirname(args.checkpoint_path)
    with open(os.path.join(dirname,'eval.jsonl'), 'a+') as f:
        f.write(json.dumps(info) + '\n')

    return info