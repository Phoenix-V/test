import json
import logging
import math
import os
import time
from contextlib import suppress

import numpy as np
import torch
import torch.nn.functional as F

import collections
from collections import defaultdict
from .tune_evaluate import evaluate as evaluate_finetune

try:
    import wandb
except ImportError:
    wandb = None

from open_clip_local import ClipLoss, get_mean_std
from .distributed import is_master, world_info_from_env, is_using_distributed
from .zero_shot import zero_shot_eval
import pdb

def log_GPU_mem(name, args):
    keys = ["memory_allocated", "memory_reserved", "max_memory_allocated", "max_memory_reserved"]
    if is_master(args, num_groups=args.num_groups):
        print(f"{name}: " + " ".join([f"{key}={getattr(torch.cuda, key)()/1024**3:.3}" for key in keys]))


def save_checkpoint(model, optimizer, scaler, epoch, i, args):
    checkpoint_dict = {
        "epoch": epoch,
        "epoch_step": i,  # inner loop saves step and args.resume in main.py will decide if a checkpoint is saved by innerloop or epoch loop (in main).
        "name": args.name,
        "state_dict": model.classification_head.state_dict(),
        "optimizer": optimizer.state_dict(),
    }
    if scaler is not None:
        checkpoint_dict["scaler"] = scaler.state_dict()

    # Saving checkpoints. use eval_steps to save a checkpoint.
    if args.save_logs:  # master_only.
        # epoch saving is removed. only save `epoch_latest.pt`.
        if args.save_most_recent:
            torch.save(
                checkpoint_dict,
                os.path.join(args.checkpoint_path, f"epoch_latest.pt"),
            )


class AverageMeter(object):
    """Computes and stores the average and current value"""
    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

def unwrap_model(model):
    if hasattr(model, 'module'):
        return model.module
    else:
        return model

def unwrap_model_semi(model):
    if hasattr(model, 'module'):
        return model.module
    elif hasattr(model, 'logit_postpro'):
        if hasattr(model.logit_postpro, 'module'):
            return model.logit_postpro.module
        else:
            return model.logit_postpro
    else:
        return model


def to_device(batch, device, args, tokenizer=None):
    if isinstance(batch, dict):  # huxu: handling old m2c2 format.
        inputs = {}
        for key in batch:
            if key not in ["image_ids", "captions"]:
                inputs[key] = batch[key].to(device, non_blocking=True)
                if key == "pixel_values" and inputs[key].dtype == torch.uint8:
                    # inmem data. normalize it.
                    inputs[key] = inputs[key].to(torch.float32).div_(255.)  # b, 3, 224, 224
                    mean, std = get_mean_std(args)
                    mean = torch.as_tensor(mean, device=inputs[key].device)[None, :, None, None]
                    std = torch.as_tensor(std, device=inputs[key].device)[None, :, None, None]
                    inputs[key].sub_(mean).div_(std)
        return inputs["pixel_values"], inputs["input_ids"]
    else:
        if len(batch) == 2:
            images, texts = batch
        else:
            images, texts, weights = batch
            weights = weights.to(device, non_blocking=True)
        if images.size(0) == 1:  # handling one worker one batch.
            images = images.squeeze(0)
        images = images.to(device=device, non_blocking=True)
        if hasattr(args, "inmem") and args.inmem and len(images.size()) > 2:
            images = images.to(torch.float32).div_(255.)  # b, 3, 224, 224
            mean, std = get_mean_std(args)
            mean = torch.as_tensor(mean, device=images.device)[None, :, None, None]
            std = torch.as_tensor(std, device=images.device)[None, :, None, None]
            images.sub_(mean).div_(std)

        if isinstance(texts, list):
            text_inputs = defaultdict(list)
            for example in texts:
                for key in example:
                    text_inputs[key].append(example[key])
            for key in text_inputs:
                text_inputs[key] = torch.stack(text_inputs[key]).to(device=device, non_blocking=True)
            texts = text_inputs
        elif isinstance(texts, tuple):
            assert tokenizer is not None
            texts = tokenizer(list(texts), padding=True, truncation=True, max_length=77, return_tensors="pt")
            texts = {key:value.to(device=device, non_blocking=True) for key,value in texts.items()}
        else:
            if texts.size(0) == 1:  # handling one worker one batch.
                texts = texts.squeeze(0)
            texts = texts.to(device=device, non_blocking=True)
        if len(batch) == 2:
            return images, texts
        else:
            return images, texts, weights


def detect_nan(model, optimizer):
    try:
        for name, parameter in model.named_parameters():
            if parameter.grad is not None:
                if not torch.isfinite(parameter.grad).all():
                    # check local gradnorm single GPU case, trigger NanDetector
                    raise FloatingPointError(f"gradients are Nan/Inf on {name}")
    except FloatingPointError as e:
        logging.warn(f"{str(e)}, skip batch.")
        optimizer.zero_grad()


def train_one_epoch_ex(model, data, epoch, epoch_step, optimizer, scaler, scheduler, args, tb_writer=None):
    # fix: train_one_epoch won't terminate on M2C2.
    device = torch.device(args.device)
    autocast = torch.cuda.amp.autocast if args.precision == 'amp' else suppress

    model.train()

    if hasattr(args, "loss"):
        from open_clip_local import loss
        loss_cls = getattr(loss, args.loss)
    else:
        from open_clip_local import loss
        loss_cls = getattr(loss, "ClipLoss")

    loss = loss_cls(
        local_loss=args.local_loss,
        gather_with_grad=args.gather_with_grad,
        cache_labels=True,
        rank=args.rank,
        world_size=args.world_size,
        use_horovod=args.horovod,
        opts=args,)

    data['train'].set_epoch(epoch, epoch_step)  # set epoch in process safe manner via sampler or shared_epoch
    dataloader = data['train'].dataloader
    num_batches_per_epoch = dataloader.num_batches
    sample_digits = math.ceil(math.log(dataloader.num_samples + 1, 10))

    loss_m = AverageMeter()
    batch_time_m = AverageMeter()
    data_time_m = AverageMeter()
    end = time.time()

    batch_iter = iter(dataloader) if not hasattr(args, "one_iter") else dataloader
    # log_GPU_mem("Before train loop", args)

    # for i, batch in enumerate(dataloader):
    for i in range(num_batches_per_epoch):
        if i < epoch_step:  # skip to the right i when resuming happens.
            continue
        batch = next(batch_iter)  # set_epoch made a new shuffled list based on epoch+step.
        step = num_batches_per_epoch * epoch + i
        scheduler(step)
        images, texts = to_device(batch[:2], device, args, dataloader.dataset.tokenizer)

        data_time_m.update(time.time() - end)
        optimizer.zero_grad()

        with autocast():
            image_features, text_features, logit_scale = model(images, texts)
            if hasattr(args, "loss") and args.loss == 'ClipDeDupLoss':
                total_loss = loss(image_features, text_features, logit_scale, texts)
            else:
                total_loss = loss(image_features, text_features, logit_scale)

        if torch.isfinite(total_loss).all():
            if scaler is not None:
                scaler.scale(total_loss).backward()
                # detect_nan(model, optimizer)
                # log_GPU_mem("After BP", args)

                if args.horovod:
                    optimizer.synchronize()
                    scaler.unscale_(optimizer)
                    if args.norm_gradient_clip is not None:
                        torch.nn.utils.clip_grad_norm_(model.parameters(), args.norm_gradient_clip, norm_type=2.0)
                    with optimizer.skip_synchronize():
                        scaler.step(optimizer)
                else:
                    if args.norm_gradient_clip is not None:
                        scaler.unscale_(optimizer)
                        torch.nn.utils.clip_grad_norm_(model.parameters(), args.norm_gradient_clip, norm_type=2.0)
                    scaler.step(optimizer)
                scaler.update()
            else:
                total_loss.backward()
                # detect_nan(model, optimizer)
                if args.norm_gradient_clip is not None:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), args.norm_gradient_clip, norm_type=2.0)
                optimizer.step()

            # Note: we clamp to 4.6052 = ln(100), as in the original paper.
            if args.distributed_engine == 'fsdp':
                model(image=None, text=None, clamp_logit_scale_to=math.log(100))
            else:
                with torch.no_grad():
                    unwrap_model(model).logit_scale.clamp_(0, math.log(100))
        else:
            logging.warn(f"Loss is {total_loss}, skip back prop.")
            import sys
            sys.exit(1)  # protect the checkpoint for debugging.

        # log_GPU_mem("After step", args)

        batch_time_m.update(time.time() - end)
        end = time.time()
        batch_count = i + 1
        if is_master(args,num_groups=args.num_groups) and (i % 100 == 0 or batch_count == num_batches_per_epoch):
            batch_size = len(images)
            num_samples = batch_count * batch_size * args.world_size
            samples_per_epoch = dataloader.num_samples
            percent_complete = 100.0 * batch_count / num_batches_per_epoch

            # NOTE loss is coarsely sampled, just master node and per log update
            loss_m.update(total_loss.item(), batch_size)
            logit_scale_scalar = logit_scale.item()
            logging.info(
                f"Train Epoch: {epoch} [{num_samples:>{sample_digits}}/{samples_per_epoch} ({percent_complete:.0f}%)] "
                f"Loss: {loss_m.val:#.5g} ({loss_m.avg:#.4g}) "
                f"Data (t): {data_time_m.avg:.3f} "
                f"Batch (t): {batch_time_m.avg:.3f}, {args.batch_size*args.world_size / batch_time_m.val:#g}/s "
                f"LR: {optimizer.param_groups[0]['lr']:5f} "
                f"Logit Scale: {logit_scale_scalar:.3f}"
            )

            # Save train loss / etc. Using non avg meter values as loggers have their own smoothing
            log_data = {
                "loss": loss_m.val,
                "data_time": data_time_m.val,
                "batch_time": batch_time_m.val,
                "samples_per_scond": args.batch_size*args.world_size / batch_time_m.val,
                "scale":  logit_scale_scalar,
                "lr": optimizer.param_groups[0]["lr"]
            }
            for name, val in log_data.items():
                name = "train/" + name
                if tb_writer is not None:
                    tb_writer.add_scalar(name, val, step)
                if args.wandb:
                    assert wandb is not None, 'Please install wandb.'
                    wandb.log({name: val, 'step': step})

            # resetting batch / data time meters per log window
            batch_time_m.reset()
            data_time_m.reset()

        if hasattr(args, "save_steps") and (step + 1) % args.save_steps == 0:
            save_checkpoint(model, optimizer, scaler, epoch, i, args)
    
        # TODO: copied from main.py, wrap as a function call.
        if hasattr(args, "eval_steps") and (step + 1) % args.eval_steps == 0: # TODO (huxu): put eval on master only?
            if any(v in data for v in ('val', 'imagenet-val', 'imagenet-v2')):
                evaluate_ex(model, data, step, args, tb_writer)  # completed_epoch -> epoch, writer -> tb_writer
            save_checkpoint(model, optimizer, scaler, epoch, i, args)
            model.train()  # evaluate won't turn model back to train."""


def finetune_one_epoch_ex(model, data, epoch, epoch_step, optimizer, scaler, scheduler, args, tb_writer=None):
    # fix: train_one_epoch won't terminate on M2C2.
    device = torch.device(args.device)
    autocast = torch.cuda.amp.autocast if args.precision == 'amp' else suppress

    model.train()
    loss_fn = torch.nn.CrossEntropyLoss().cuda()
    if epoch == 0 and not (hasattr(args, 'skipeval') and args.skipeval):
        eval_results = evaluate_finetune(model, {key:item for key,item in data.items() if 'train' not in key}, args, epoch)

    dataloader = data['imagenet-train'].dataloader
    num_batches_per_epoch = int(np.ceil(len(dataloader) / args.world_size).item())
    sample_digits = math.ceil(math.log(len(data['imagenet-train'].dataloader.dataset) + 1, 10))

    loss_m = AverageMeter()
    batch_time_m = AverageMeter()
    data_time_m = AverageMeter()
    end = time.time()

    batch_iter = iter(dataloader)
    for i in range(num_batches_per_epoch):

        batch = next(batch_iter) 
        start_time = time.time()
        step = i + epoch * num_batches_per_epoch
        scheduler(step)

        inputs = batch[0].cuda()
        labels = batch[1].cuda()

        data_time = time.time() - end
        data_time_m.update(data_time)
        optimizer.zero_grad()

        with autocast():
            logits = model(inputs)
            loss = loss_fn(logits, labels)
        
        if torch.isfinite(loss).all():
            if scaler is not None:
                scaler.scale(loss).backward()
                if args.norm_gradient_clip is not None:
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), args.norm_gradient_clip, norm_type=2.0)
                scaler.step(optimizer)
                scaler.update()
            else:
                loss.backward()
                torch.nn.utils.clip_grad_norm_(params, 1.0)
                optimizer.step()

        batch_time = time.time() - end
        batch_time_m.update(batch_time)

        if is_master(args,num_groups=args.num_groups) and (i % 100 == 0 or i == num_batches_per_epoch-1):
            batch_size = len(inputs)
            batch_count = i + 1
            num_samples = batch_count * batch_size * args.world_size
            samples_per_epoch = len(dataloader) * batch_size
            percent_complete = 100.0 * batch_count / num_batches_per_epoch

            # NOTE loss is coarsely sampled, just master node and per log update
            loss_m.update(loss.item(), batch_size)
            logging.info(
                f"Train Epoch: {epoch} [{num_samples:>{sample_digits}}/{samples_per_epoch} ({percent_complete:.0f}%)] "
                f"Loss: {loss_m.val:#.5g} ({loss_m.avg:#.4g}) "
                f"Data (t): {data_time_m.avg:.3f} "
                f"Batch (t): {batch_time_m.avg:.3f}, {args.batch_size*args.world_size / batch_time_m.val:#g}/s "
                f"LR: {optimizer.param_groups[0]['lr']:5f} "
            )

            # Save train loss / etc. Using non avg meter values as loggers have their own smoothing
            log_data = {
                "loss": loss_m.val,
                "data_time": data_time_m.val,
                "batch_time": batch_time_m.val,
                "samples_per_scond": args.batch_size*args.world_size / batch_time_m.val,
                "lr": optimizer.param_groups[0]["lr"]
            }
            for name, val in log_data.items():
                name = "train/" + name
                if tb_writer is not None:
                    tb_writer.add_scalar(name, val, step)

            # resetting batch / data time meters per log window
            batch_time_m.reset()
            data_time_m.reset()
    

    # Saving model
    save_checkpoint(model,optimizer,scaler,epoch,0,args)
    eval_results = evaluate_finetune(model, {key:item for key,item in data.items() if 'train' not in key}, args, epoch+1)


def train_one_epoch_sigmoid(model, data, epoch, epoch_step, optimizer, scaler, scheduler, args, tb_writer=None):
    # fix: train_one_epoch won't terminate on M2C2.
    device = torch.device(args.device)
    autocast = torch.cuda.amp.autocast if args.precision == 'amp' else suppress

    model.train()
    from open_clip_local import loss
    loss = getattr(loss, "ClipSigmoidLoss")(
        local_loss=args.local_loss,
        gather_with_grad=args.gather_with_grad,
        cache_labels=True,
        rank=args.rank,
        world_size=args.world_size,
        use_horovod=args.horovod,
        opts=args,)

    data['train'].set_epoch(epoch, epoch_step)  # set epoch in process safe manner via sampler or shared_epoch
    dataloader = data['train'].dataloader
    num_batches_per_epoch = dataloader.num_batches
    sample_digits = math.ceil(math.log(dataloader.num_samples + 1, 10))

    loss_m = AverageMeter()
    batch_time_m = AverageMeter()
    data_time_m = AverageMeter()
    end = time.time()

    batch_iter = iter(dataloader) if not hasattr(args, "one_iter") else dataloader
    # log_GPU_mem("Before train loop", args)

    # for i, batch in enumerate(dataloader):
    for i in range(num_batches_per_epoch):
        if i < epoch_step:  # skip to the right i when resuming happens.
            continue
        batch = next(batch_iter)  # set_epoch made a new shuffled list based on epoch+step.
        step = num_batches_per_epoch * epoch + i
        scheduler(step)
        images, texts = to_device(batch[:2], device, args, dataloader.dataset.tokenizer)

        data_time_m.update(time.time() - end)
        optimizer.zero_grad()

        with autocast():
            image_features, text_features, logit_scale, logit_bias = model(images, texts)            
            total_loss = loss(image_features, text_features, logit_scale, logit_bias)

        if torch.isfinite(total_loss).all():
            if scaler is not None:
                scaler.scale(total_loss).backward()
                # detect_nan(model, optimizer)
                # log_GPU_mem("After BP", args)

                if args.horovod:
                    optimizer.synchronize()
                    scaler.unscale_(optimizer)
                    if args.norm_gradient_clip is not None:
                        torch.nn.utils.clip_grad_norm_(model.parameters(), args.norm_gradient_clip, norm_type=2.0)
                    with optimizer.skip_synchronize():
                        scaler.step(optimizer)
                else:
                    if args.norm_gradient_clip is not None:
                        scaler.unscale_(optimizer)
                        torch.nn.utils.clip_grad_norm_(model.parameters(), args.norm_gradient_clip, norm_type=2.0)
                    scaler.step(optimizer)
                scaler.update()
            else:
                total_loss.backward()
                # detect_nan(model, optimizer)
                if args.norm_gradient_clip is not None:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), args.norm_gradient_clip, norm_type=2.0)
                optimizer.step()

            # Note: we clamp to 4.6052 = ln(100), as in the original paper.
            if args.distributed_engine == 'fsdp':
                model(image=None, text=None, clamp_logit_scale_to=math.log(100))
            else:
                with torch.no_grad():
                    unwrap_model(model).logit_scale.clamp_(0, math.log(100))
        else:
            logging.warn(f"Loss is {total_loss}, skip back prop.")
            import sys
            sys.exit(1)  # protect the checkpoint for debugging.

        batch_time_m.update(time.time() - end)
        end = time.time()
        batch_count = i + 1
        if is_master(args,num_groups=args.num_groups) and (i % 100 == 0 or batch_count == num_batches_per_epoch):
            batch_size = len(images)
            num_samples = batch_count * batch_size * args.world_size
            samples_per_epoch = dataloader.num_samples
            percent_complete = 100.0 * batch_count / num_batches_per_epoch

            # NOTE loss is coarsely sampled, just master node and per log update
            loss_m.update(total_loss.item(), batch_size)
            logit_scale_scalar = logit_scale.item()
            logging.info(
                f"Train Epoch: {epoch} [{num_samples:>{sample_digits}}/{samples_per_epoch} ({percent_complete:.0f}%)] "
                f"Loss: {loss_m.val:#.5g} ({loss_m.avg:#.4g}) "
                f"Data (t): {data_time_m.avg:.3f} "
                f"Batch (t): {batch_time_m.avg:.3f}, {args.batch_size*args.world_size / batch_time_m.val:#g}/s "
                f"LR: {optimizer.param_groups[0]['lr']:5f} "
                f"Logit Scale: {logit_scale_scalar:.3f}"
            )

            # Save train loss / etc. Using non avg meter values as loggers have their own smoothing
            log_data = {
                "loss": loss_m.val,
                "data_time": data_time_m.val,
                "batch_time": batch_time_m.val,
                "samples_per_scond": args.batch_size*args.world_size / batch_time_m.val,
                "scale":  logit_scale_scalar,
                "lr": optimizer.param_groups[0]["lr"]
            }
            for name, val in log_data.items():
                name = "train/" + name
                if tb_writer is not None:
                    tb_writer.add_scalar(name, val, step)
                if args.wandb:
                    assert wandb is not None, 'Please install wandb.'
                    wandb.log({name: val, 'step': step})

            # resetting batch / data time meters per log window
            batch_time_m.reset()
            data_time_m.reset()

        if hasattr(args, "save_steps") and (step + 1) % args.save_steps == 0:
            save_checkpoint(model, optimizer, scaler, epoch, i, args)
    
        # TODO: copied from main.py, wrap as a function call.
        if hasattr(args, "eval_steps") and (step + 1) % args.eval_steps == 0: # TODO (huxu): put eval on master only?
            if any(v in data for v in ('val', 'imagenet-val', 'imagenet-v2')):
                evaluate_ex(model, data, step, args, tb_writer)  # completed_epoch -> epoch, writer -> tb_writer
            save_checkpoint(model, optimizer, scaler, epoch, i, args)
            model.train()  # evaluate won't turn model back to train."""



def train_one_epoch(model, data, epoch, optimizer, scaler, scheduler, args, tb_writer=None):
    device = torch.device(args.device)
    autocast = torch.cuda.amp.autocast if args.precision == 'amp' else suppress

    model.train()
    loss = ClipLoss(
        local_loss=args.local_loss,
        gather_with_grad=args.gather_with_grad,
        cache_labels=True,
        rank=args.rank,
        world_size=args.world_size,
        use_horovod=args.horovod)

    data['train'].set_epoch(epoch)  # set epoch in process safe manner via sampler or shared_epoch
    dataloader = data['train'].dataloader
    num_batches_per_epoch = dataloader.num_batches
    sample_digits = math.ceil(math.log(dataloader.num_samples + 1, 10))

    loss_m = AverageMeter()
    batch_time_m = AverageMeter()
    data_time_m = AverageMeter()
    end = time.time()
    for i, batch in enumerate(dataloader):
        step = num_batches_per_epoch * epoch + i
        scheduler(step)

        images, texts = to_device(batch[:2], device, args, dataloader.dataset.tokenizer)

        data_time_m.update(time.time() - end)
        optimizer.zero_grad()

        with autocast():
            image_features, text_features, logit_scale = model(images, texts)
            total_loss = loss(image_features, text_features, logit_scale)

        if scaler is not None:
            scaler.scale(total_loss).backward()
            if args.horovod:
                optimizer.synchronize()
                scaler.unscale_(optimizer)
                if args.norm_gradient_clip is not None:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), args.norm_gradient_clip, norm_type=2.0)
                with optimizer.skip_synchronize():
                    scaler.step(optimizer)
            else:
                if args.norm_gradient_clip is not None:
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), args.norm_gradient_clip, norm_type=2.0)
                scaler.step(optimizer)
            scaler.update()
        else:
            total_loss.backward()
            if args.norm_gradient_clip is not None:
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.norm_gradient_clip, norm_type=2.0)
            optimizer.step()

        # Note: we clamp to 4.6052 = ln(100), as in the original paper.
        if args.distributed_engine == 'fsdp':
            model(image=None, text=None, clamp_logit_scale_to=math.log(100))
        else:
            with torch.no_grad():
                unwrap_model(model).logit_scale.clamp_(0, math.log(100))

        batch_time_m.update(time.time() - end)
        end = time.time()
        batch_count = i + 1
        if is_master(args, num_groups=args.num_groups) and (i % 100 == 0 or batch_count == num_batches_per_epoch):
            batch_size = len(images)
            num_samples = batch_count * batch_size * args.world_size
            samples_per_epoch = dataloader.num_samples
            percent_complete = 100.0 * batch_count / num_batches_per_epoch

            # NOTE loss is coarsely sampled, just master node and per log update
            loss_m.update(total_loss.item(), batch_size)
            logit_scale_scalar = logit_scale.item()
            logging.info(
                f"Train Epoch: {epoch} [{num_samples:>{sample_digits}}/{samples_per_epoch} ({percent_complete:.0f}%)] "
                f"Loss: {loss_m.val:#.5g} ({loss_m.avg:#.4g}) "
                f"Data (t): {data_time_m.avg:.3f} "
                f"Batch (t): {batch_time_m.avg:.3f}, {args.batch_size*args.world_size / batch_time_m.val:#g}/s "
                f"LR: {optimizer.param_groups[0]['lr']:5f} "
                f"Logit Scale: {logit_scale_scalar:.3f}"
            )

            # Save train loss / etc. Using non avg meter values as loggers have their own smoothing
            log_data = {
                "loss": loss_m.val,
                "data_time": data_time_m.val,
                "batch_time": batch_time_m.val,
                "samples_per_scond": args.batch_size*args.world_size / batch_time_m.val,
                "scale":  logit_scale_scalar,
                "lr": optimizer.param_groups[0]["lr"]
            }
            for name, val in log_data.items():
                name = "train/" + name
                if tb_writer is not None:
                    tb_writer.add_scalar(name, val, step)
                if args.wandb:
                    assert wandb is not None, 'Please install wandb.'
                    wandb.log({name: val, 'step': step})

            # resetting batch / data time meters per log window
            batch_time_m.reset()
            data_time_m.reset()


# huxu: used inside train_epoch.
def evaluate_ex(model, data, step, args, tb_writer=None):
    metrics = {}
    if not is_master(args, num_groups=args.num_groups) and args.distributed_engine != 'fsdp':
        return metrics
    device = torch.device(args.device)
    model.eval()

    zero_shot_metrics = zero_shot_eval(model, data, 0, args)  # huxu: epoch = 0 as a trick to bypass checking.
    metrics.update(zero_shot_metrics)

    autocast = torch.cuda.amp.autocast if args.precision == 'amp' else suppress
    if 'val' in data:  # and (args.val_frequency and ((epoch % args.val_frequency) == 0 or epoch == args.epochs)):  # huxu: val anytime called.
        dataloader = data['val'].dataloader
        num_samples = 0
        samples_per_val = dataloader.num_samples

        # FIXME this does not scale past small eval datasets
        # all_image_features @ all_text_features will blow up memory and compute very quickly
        cumulative_loss = 0.0
        all_image_features, all_text_features = [], []
        with torch.no_grad():
            for i, batch in enumerate(dataloader):
                images, texts = to_device(batch, device, args)

                with autocast():
                    image_features, text_features, logit_scale = model(images, texts)
                    # features are accumulated in CPU tensors, otherwise GPU memory exhausted quickly
                    # however, system RAM is easily exceeded and compute time becomes problematic
                    all_image_features.append(image_features.cpu())
                    all_text_features.append(text_features.cpu())
                    logit_scale = logit_scale.mean()
                    logits_per_image = logit_scale * image_features @ text_features.t()
                    logits_per_text = logits_per_image.t()

                    batch_size = images.shape[0]
                    labels = torch.arange(batch_size, device=device).long()
                    total_loss = (
                        F.cross_entropy(logits_per_image, labels) +
                        F.cross_entropy(logits_per_text, labels)
                    ) / 2

                cumulative_loss += total_loss * batch_size
                num_samples += batch_size
                if is_master(args, num_groups=args.num_groups) and (i % 100) == 0:
                    logging.info(
                        f"Eval Step: {step} [{num_samples} / {samples_per_val}]\t"
                        f"Loss: {cumulative_loss / num_samples:.6f}\t")

            val_metrics = get_metrics(
                image_features=torch.cat(all_image_features),
                text_features=torch.cat(all_text_features),
                logit_scale=logit_scale.cpu(),
            )
            loss = cumulative_loss / num_samples
            metrics.update(
                {**val_metrics, "val_loss": loss.item(), "step": step, "num_samples": num_samples}
            )

    if not metrics:
        return metrics

    logging.info(
        f"Eval Step: {step} "
        + "\t".join([f"{k}: {round(v, 4):.4f}" for k, v in metrics.items()])
    )

    if args.save_logs:
        for name, val in metrics.items():
            if tb_writer is not None:
                tb_writer.add_scalar(f"val_step/{name}", val, step)

        with open(os.path.join(args.checkpoint_path, "results.jsonl"), "a+") as f:
            f.write(json.dumps(metrics))
            f.write("\n")

    if args.wandb:
        assert wandb is not None, 'Please install wandb.'
        for name, val in metrics.items():
            wandb.log({f"val_step/{name}": val, 'step': step})

    return metrics


def evaluate(model, data, epoch, args, tb_writer=None):
    metrics = {}
    if not is_master(args, num_groups=args.num_groups) and args.distributed_engine != 'fsdp':
        return metrics
    device = torch.device(args.device)
    model.eval()

    zero_shot_metrics = zero_shot_eval(model, data, epoch, args)
    metrics.update(zero_shot_metrics)

    autocast = torch.cuda.amp.autocast if args.precision == 'amp' else suppress
    if 'val' in data and (args.val_frequency and ((epoch % args.val_frequency) == 0 or epoch == args.epochs)):
        dataloader = data['val'].dataloader
        num_samples = 0
        samples_per_val = dataloader.num_samples

        # FIXME this does not scale past small eval datasets
        # all_image_features @ all_text_features will blow up memory and compute very quickly
        cumulative_loss = 0.0
        all_image_features, all_text_features = [], []
        with torch.no_grad():
            for i, batch in enumerate(dataloader):
                images, texts = to_device(batch, device, args)

                with autocast():
                    image_features, text_features, logit_scale = model(images, texts)
                    # features are accumulated in CPU tensors, otherwise GPU memory exhausted quickly
                    # however, system RAM is easily exceeded and compute time becomes problematic
                    all_image_features.append(image_features.cpu())
                    all_text_features.append(text_features.cpu())
                    logit_scale = logit_scale.mean()
                    logits_per_image = logit_scale * image_features @ text_features.t()
                    logits_per_text = logits_per_image.t()

                    batch_size = images.shape[0]
                    labels = torch.arange(batch_size, device=device).long()
                    total_loss = (
                        F.cross_entropy(logits_per_image, labels) +
                        F.cross_entropy(logits_per_text, labels)
                    ) / 2

                cumulative_loss += total_loss * batch_size
                num_samples += batch_size
                if is_master(args, num_groups=args.num_groups) and (i % 100) == 0:
                    logging.info(
                        f"Eval Epoch: {epoch} [{num_samples} / {samples_per_val}]\t"
                        f"Loss: {cumulative_loss / num_samples:.6f}\t")

            val_metrics = get_metrics(
                image_features=torch.cat(all_image_features),
                text_features=torch.cat(all_text_features),
                logit_scale=logit_scale.cpu(),
            )
            loss = cumulative_loss / num_samples
            metrics.update(
                {**val_metrics, "val_loss": loss.item(), "epoch": epoch, "num_samples": num_samples}
            )

    if not metrics:
        return metrics

    logging.info(
        f"Eval Epoch: {epoch} "
        + "\t".join([f"{k}: {round(v, 4):.4f}" for k, v in metrics.items()])
    )

    if args.save_logs:
        for name, val in metrics.items():
            if tb_writer is not None:
                tb_writer.add_scalar(f"val/{name}", val, epoch)

        with open(os.path.join(args.checkpoint_path, "results.jsonl"), "a+") as f:
            f.write(json.dumps(metrics))
            f.write("\n")

    if args.wandb:
        assert wandb is not None, 'Please install wandb.'
        for name, val in metrics.items():
            wandb.log({f"val/{name}": val, 'epoch': epoch})

    return metrics


def get_metrics(image_features, text_features, logit_scale):
    metrics = {}
    logits_per_image = (logit_scale * image_features @ text_features.t()).detach().cpu()
    logits_per_text = logits_per_image.t().detach().cpu()

    logits = {"image_to_text": logits_per_image, "text_to_image": logits_per_text}
    ground_truth = torch.arange(len(text_features)).view(-1, 1)

    for name, logit in logits.items():
        ranking = torch.argsort(logit, descending=True)
        preds = torch.where(ranking == ground_truth)[1]
        preds = preds.detach().cpu().numpy()
        metrics[f"{name}_mean_rank"] = preds.mean() + 1
        metrics[f"{name}_median_rank"] = np.floor(np.median(preds)) + 1
        for k in [1, 5, 10]:
            metrics[f"{name}_R@{k}"] = np.mean(preds < k)

    return metrics



def epoch_init_wrap(epoch, epoch_step, args, loss_cls, data):
    loss = loss_cls(
        local_loss=args.local_loss,
        gather_with_grad=args.gather_with_grad,
        cache_labels=True,
        rank=args.rank,
        world_size=args.world_size,
        use_horovod=args.horovod,
        opts=args,)

    data['train'].set_epoch(epoch, epoch_step)  # set epoch in process safe manner via sampler or shared_epoch
    dataloader = data['train'].dataloader
    num_batches_per_epoch = dataloader.num_batches
    sample_digits = math.ceil(math.log(dataloader.num_samples + 1, 10))

    loss_m = AverageMeter()
    batch_time_m = AverageMeter()
    data_time_m = AverageMeter()
    end = time.time()

    batch_iter = iter(dataloader) if not hasattr(args, "one_iter") else dataloader
    return loss, batch_iter, dataloader, num_batches_per_epoch, sample_digits, loss_m, batch_time_m, data_time_m, end

def step_logging_wrap(i, step, epoch, total_loss, images, dataloader, optimizer, sample_digits, logit_scale, prev_end, loss_m, batch_time_m, data_time_m, tb_writer, args, num_batches_per_epoch):
    batch_time_m.update(time.time() - prev_end)
    end = time.time()
    batch_count = i + 1
    if is_master(args,num_groups=args.num_groups) and (i % 100 == 0 or batch_count == num_batches_per_epoch):
        batch_size = len(images)
        num_samples = batch_count * batch_size * args.world_size
        samples_per_epoch = dataloader.num_samples
        percent_complete = 100.0 * batch_count / num_batches_per_epoch

        # NOTE loss is coarsely sampled, just master node and per log update
        loss_m.update(total_loss.item(), batch_size)
        logit_scale_scalar = logit_scale.item()
        logging.info(
            f"Train Epoch: {epoch} [{num_samples:>{sample_digits}}/{samples_per_epoch} ({percent_complete:.0f}%)] "
            f"Loss: {loss_m.val:#.5g} ({loss_m.avg:#.4g}) "
            f"Data (t): {data_time_m.avg:.3f} "
            f"Batch (t): {batch_time_m.avg:.3f}, {args.batch_size*args.world_size / batch_time_m.val:#g}/s "
            f"LR: {optimizer.param_groups[0]['lr']:5f} "
            f"Logit Scale: {logit_scale_scalar:.3f}"
        )

        # Save train loss / etc. Using non avg meter values as loggers have their own smoothing
        log_data = {
            "loss": loss_m.val,
            "data_time": data_time_m.val,
            "batch_time": batch_time_m.val,
            "samples_per_scond": args.batch_size*args.world_size / batch_time_m.val,
            "scale":  logit_scale_scalar,
            "lr": optimizer.param_groups[0]["lr"]
        }
        for name, val in log_data.items():
            name = "train/" + name
            if tb_writer is not None:
                tb_writer.add_scalar(name, val, step)
            if args.wandb:
                assert wandb is not None, 'Please install wandb.'
                wandb.log({name: val, 'step': step})

        # resetting batch / data time meters per log window
        batch_time_m.reset()
        data_time_m.reset()


def step_update_wrap(total_loss, model, scaler, optimizer, args):
    if torch.isfinite(total_loss).all():
        if scaler is not None:
            scaler.scale(total_loss).backward()
            # detect_nan(model, optimizer)
            # log_GPU_mem("After BP", args)

            if args.horovod:
                optimizer.synchronize()
                scaler.unscale_(optimizer)
                if args.norm_gradient_clip is not None:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), args.norm_gradient_clip, norm_type=2.0)
                with optimizer.skip_synchronize():
                    scaler.step(optimizer)
            else:
                if args.norm_gradient_clip is not None:
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), args.norm_gradient_clip, norm_type=2.0)
                scaler.step(optimizer)
            scaler.update()
        else:
            total_loss.backward()
            # detect_nan(model, optimizer)
            if args.norm_gradient_clip is not None:
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.norm_gradient_clip, norm_type=2.0)
            optimizer.step()

        # Note: we clamp to 4.6052 = ln(100), as in the original paper.
        if args.distributed_engine == 'fsdp':
            model(image=None, text=None, clamp_logit_scale_to=100.0)
        else:
            with torch.no_grad():
                unwrap_model(model).logit_scale.clamp_(0, 100.0)
    else:
        logging.warn(f"Loss is {total_loss}, skip back prop.")
        import sys
        sys.exit(1)  # protect the checkpoint for debugging.

