import torch
import mmap
import os
import json

from typing import Any, Callable, Optional

import numpy as np
import random

from torch.utils.data import Dataset, DataLoader
from torch.utils.data.distributed import DistributedSampler
from transformers import AutoTokenizer

from io import BytesIO
from PIL import Image, ImageDraw, ImageFilter
from training_local.distributed import world_info_from_env

from open_clip_local import tokenize
from .data import DataInfo
import pdb
import torch.nn.functional as F


"""
IterativeWebDataset: vanilla, cluster-specific selection
IterativeSoftWebDataset: soft label generation
IterativeDynamicSubSampleWebDataset: dynamic across batches
"""
LU_LIST = ['u','du']

def fairblurbbox(image, faces):
    if len(faces) == 0:
        return image

    mask = Image.new(mode="L", size=image.size, color="white")
    width, height = image.size
    max_diagonal = 0
    for face in faces:
        x0, y0, x1, y1 = faces[face]["facial_area"]
        if x0 > x1:
            x0, x1 = x1, x0
        if y0 > y1:
            y0, y1 = y1, y0
        x0 = min(x0, width)
        x1 = min(x1, width)
        y0 = min(y0, height)
        y1 = min(y1, height)
        bbox = [x0, y0, x1, y1]
        erosion = 0.1
        blur_radius = 1/17
        mask_radius = 0.1

        diagonal = max(bbox[2] - bbox[0], bbox[3] - bbox[1])
        max_diagonal = max(max_diagonal, diagonal)
        bbox = [
            bbox[0] - erosion * diagonal,
            bbox[1] - erosion * diagonal,
            bbox[2] + erosion * diagonal,
            bbox[3] + erosion * diagonal,
        ]
        draw = ImageDraw.Draw(mask)
        draw.rectangle(bbox, fill="black")
    blurred_img = image.filter(ImageFilter.GaussianBlur(blur_radius * max_diagonal))
    blurred_mask = mask.filter(ImageFilter.GaussianBlur(mask_radius * max_diagonal))
    img = Image.composite(image, blurred_img, blurred_mask)
    return img


def load_fb_bbox(args, shard_id):
    fb_dir = os.path.dirname(args.train_data)
    with open(f"{fb_dir}/fb/{shard_id % 100}/{shard_id}.json") as fr:
        return json.load(fr)


cit_index = None
query_counts = None

def dp(args, shard_id):
    if args.cit_dir.endswith(".npy"):
        global cit_index
        if cit_index is None:
            cit_index = np.load(args.cit_dir, mmap_mode="r")  # (shard_id, wordid_offsets)
        wordid_offsets = np.sort(cit_index[:, 1][cit_index[:, 0] == shard_id])
        output_fn = os.path.join(os.path.dirname(args.cit_dir), f"{shard_id % 100}", f"{shard_id}.npy")

        cit_subset = np.load(output_fn, mmap_mode="r")[wordid_offsets]
        rowid_col = cit_subset[:, 2]  # using jpeg start offset since all images should be different.
        rowids = np.unique(rowid_col)
        results = np.empty(shape=(rowids.shape[0], cit_subset.shape[1]), dtype=np.uint32)
        for ix, rowid in enumerate(rowids):
            matching_rows = cit_subset[rowid_col==rowid]
            results[ix] = matching_rows[random.randint(0, matching_rows.shape[0] - 1)]
        return results
    elif "subset" in args.cit_dir:
        offsets_fn = os.path.join(args.cit_dir, f"{shard_id % 100}", f"{shard_id}.npy")
        if not os.path.exists(offsets_fn):
            return None

        wordid_offsets = np.load(offsets_fn, mmap_mode="r")
        output_fn = os.path.join(os.path.dirname(args.cit_dir), f"{shard_id % 100}", f"{shard_id}.npy")

        cit_subset = np.load(output_fn, mmap_mode="r")[wordid_offsets]
        rowid_col = cit_subset[:, 2]  # using jpeg start offset since all images should be different.
        rowids = np.unique(rowid_col)
        results = np.empty(shape=(rowids.shape[0], cit_subset.shape[1]), dtype=np.uint32)
        for ix, rowid in enumerate(rowids):
            matching_rows = cit_subset[rowid_col==rowid]
            results[ix] = matching_rows[random.randint(0, matching_rows.shape[0] - 1)]
        return results
    else:
        if hasattr(args, "max_match"):
            global query_counts
            if query_counts is None:
                query_counts = np.load(args.word_counts, mmap_mode="r")
            inverted_query_fn = os.path.join(args.cit_dir, f"{shard_id % 100}", f"{shard_id}_inverted.npy")
            query_offsets = np.load(inverted_query_fn, mmap_mode="r")

            query_ids = query_offsets[:, 0]
            query_id_counts = query_counts[query_ids]
            query_id_counts[query_id_counts < args.max_match] = args.max_match

            query_probs = args.max_match / query_id_counts

            offsets_selector = np.random.random_sample((query_offsets.shape[0],)) < query_probs

            offsets = np.sort(np.unique(query_offsets[:, 1][offsets_selector]))
            if offsets.shape[0] == 0:
                return None
            cit_subset_fn = os.path.join(args.cit_dir, f"{shard_id % 100}", f"{shard_id}.npy")
            cit_subset = np.load(cit_subset_fn, mmap_mode="r")[offsets]
            rowid_col = cit_subset[:, 2]  # using jpeg start offset since all images should be different.
            rowids = np.unique(rowid_col)
            results = np.empty(shape=(rowids.shape[0], cit_subset.shape[1]), dtype=np.uint32)
            for ix, rowid in enumerate(rowids):
                matching_rows = cit_subset[rowid_col==rowid]
                results[ix] = matching_rows[random.randint(0, matching_rows.shape[0] - 1)]
            return results
        else:
            output_fn = os.path.join(args.cit_dir, f"{shard_id % 100}", f"{shard_id}.npy")
            cit_subset = np.load(output_fn, mmap_mode="r")
            rowid_col = cit_subset[:, 2]  # using jpeg start offset since all images should be different.
            rowids = np.unique(rowid_col)
            results = np.empty(shape=(rowids.shape[0], cit_subset.shape[1]), dtype=np.uint32)
            for ix, rowid in enumerate(rowids):
                matching_rows = cit_subset[rowid_col==rowid]
                results[ix] = matching_rows[random.randint(0, matching_rows.shape[0] - 1)]
            return results


class IterativeWebDataset(torch.utils.data.IterableDataset):
    '''
    Generating minibatch from all datasampels randomly or for only one cluster specifically.
    '''
    def __init__(self, args, transform, tokenize):
        self.args = args
        start, end = os.path.basename(args.train_data).split("{")[1].split("}")[0].split("..")
        self.num_shards = int(end) - int(start)
        self.root_dir = os.path.dirname(args.train_data)
        self.cit_dir = args.cit_dir
        self.transform = transform
        self.tokenizer = tokenize
        self.start_shard_id = 0
        self.shard_ids = list(range(self.num_shards))
        self.rank = args.rank

        with open("/private/home/huxu/mmpt/open_clip/data/CLIP/imagenet_pca_hash.json") as f:
            dedup_hash = json.load(f)
            self.dedup_set = set(dedup_hash.values())
        
        if hasattr(args,'num_groups') and args.num_groups > 1:
            self.cluster_id = args.rank % args.num_groups if hasattr(args,'cluster_key') else None
        else:
            self.cluster_id = args.cluster_id if hasattr(args, 'cluster_id') else None
        
        self.distr_temp = None
        if hasattr(args,'dataset_arg') and self.cluster_id is not None:
            self.distr_temp = args.dataset_arg[1]['distr_temp'] if 'distr_temp' in args.dataset_arg[1] else None
            if self.distr_temp is not None:
                self.prepare_calculator()
        
        # cit_subset = dp(self.args, 50)
        # cit_subset, kept_keys = self.dataset_filter(50, cit_subset)

    def set_epoch(self, epoch, num_batches, step=0):
        random.seed(epoch+step)
        self.shard_ids = list(range(self.num_shards))
        random.shuffle(self.shard_ids)
        self.start_shard_id = (num_batches * epoch) % self.num_shards
    
    def _get_tarball_path(self, shard_id):
        return os.path.join(self.root_dir, f"{shard_id % 100}", f"{shard_id}.tar")

    def _get_next_shard_id(self, shard_id):
        shard_id += self.group_size
        return shard_id % self.num_shards
    
    def get_worder_info(self):
        worker_info = torch.utils.data.get_worker_info()
        if worker_info is None:
            num_workers = 1
            worker_id = 0
        else:
            num_workers = worker_info.num_workers
            worker_id = worker_info.id
        _, global_rank, world_size = world_info_from_env()
        self.group_size = int(num_workers * world_size)
        shard_id = num_workers * global_rank + worker_id
        shard_id = (shard_id + self.start_shard_id) % self.num_shards
        shard_id = self.shard_ids[shard_id]
        return worker_id, num_workers, shard_id

    def __iter__(self):
        worker_id, num_workers, shard_id = self.get_worder_info()

        while True:
            cit_subset = dp(self.args, shard_id)
            if cit_subset is None or cit_subset.shape[0] == 0:
                shard_id = self._get_next_shard_id(shard_id)
                continue

            fb_bboxes = load_fb_bbox(self.args, shard_id)
            tarball_path = self._get_tarball_path(shard_id)

            with open(tarball_path) as f:
                with mmap.mmap(fileno=f.fileno(), length=0, access=mmap.ACCESS_READ) as m:

                    cit_subset, kept_keys = self.dataset_filter(shard_id, cit_subset)
                    for fileidx, entry in enumerate(cit_subset):
                        image_txt = self.datapoint_loading(fileidx, entry, fb_bboxes, m)
                        if image_txt is None:
                            continue 
                        yield image_txt[0], image_txt[1]

            shard_id = self._get_next_shard_id(shard_id)
    
    def datapoint_loading(self, fileidx, entry, fb_bboxes, m):
        keyid, keyoffset, jpg_start_offset, jpg_end_offset, txt_start_offset, txt_end_offset = entry[0], entry[1], entry[2], entry[3], entry[4], entry[5]
        assert txt_start_offset != txt_end_offset
        text_json = json.load(BytesIO(m[txt_start_offset:txt_end_offset]))
        if text_json["hash"] in self.dedup_set:
            return None

        if isinstance(text_json["texts"], dict):
            text_key = ["alt", "title", "data-image-title"][keyid]
            txt = text_json["texts"][text_key][keyoffset]["text"]
        else:
            txt = text_json["texts"][keyoffset][1]
        if hasattr(self.args,'lu_mode') and self.args.lu_mode not in LU_LIST:
            txt = self.tokenizer([txt], padding=True, truncation=True, return_tensors="pt")
        else:
            txt = self.tokenizer([txt])[0]

        with Image.open(BytesIO(m[jpg_start_offset:jpg_end_offset])) as img:
            image = img.convert("RGB")
            faces = fb_bboxes[str(jpg_start_offset)]
            image = fairblurbbox(image, faces)
            image = self.transform(image)
        return image, txt
    
    def datapoint_feat_loading(self, sample_idx, all_caption, all_feat):
        if all_caption['index'][sample_idx-1] == sample_idx:
            txt = all_caption['caption'][sample_idx-1]
            image = all_feat['vitl14v2'][sample_idx-1]
        elif sample_idx < len(all_caption['caption']) and all_caption['index'][sample_idx] == sample_idx:
            txt = all_caption['caption'][sample_idx]
            image = all_feat['vitl14v2'][sample_idx]
        else:
            return None
        if hasattr(self.args,'lu_mode') and self.args.lu_mode not in LU_LIST:
            pass
        else:
            txt = self.tokenizer([txt])[0]
        return image, txt
    
    def dataset_filter(self, shard_id, cit_subset):
        # Sampling data for each cluster
        if self.cluster_id is None:
            return cit_subset, None
        assert os.path.exists(self.args.group_dir)
        group_file_path = os.path.join(self.args.group_dir, str(shard_id%100), f'{shard_id}_group.json')
        
        with open(group_file_path, 'r') as json_file:
            group_file = json.load(json_file)
        file_grp = group_file[self.args.cluster_key]
        filekeys = 'filekeys' if 'filekeys' in group_file else 'key'
        file_idx = group_file[filekeys]
        
        # kept_keys is ranked by nature
        if isinstance(self.cluster_id,int):
            index = np.array(file_grp)==self.cluster_id
        else:
            index = (np.array(file_grp)[:,None]==np.array(self.cluster_id)[None]).sum(axis=-1)==1
        kept_keys = np.array(file_idx)[index]

        dist_file_path = os.path.join(self.args.group_dir, str(shard_id%100), f'{shard_id}_dist.pth')
        if hasattr(self.args, 'dedup'):
            dist = torch.load(dist_file_path,map_location='cpu')[self.args.cluster_key]
            dist_cluster = dist[index,self.cluster_id]
            close = dist_cluster < self.args.dedup[0]
            close_keys = kept_keys[close]
            mid_keys = kept_keys[~close]
            if self.args.dedup[1] > 0.0 and int(len(close_keys)*self.args.dedup[1]) > 0:
                kept_close_keys = np.random.choice(close_keys,int(len(close_keys)*self.args.dedup[1]))
                kept_keys = np.concatenate([mid_keys,kept_close_keys])
            else:
                kept_keys = mid_keys

        # Include data from other groups
        if self.args.soft_cluster > 0.0: 
            out_group_keys = np.array(file_idx)[~index]
            if self.distr_temp is None:
                the_keys = np.random.choice(out_group_keys, int(len(out_group_keys) * self.args.soft_cluster), replace=False)
            else:
                the_keys = self.distribution_subsample(shard_id,index,file_idx)
            
            all_keys = np.concatenate([kept_keys,the_keys])
            index = np.argsort(all_keys)
            kept_keys = all_keys[index]
        
        if cit_subset is not None:
            cit_subset = cit_subset[kept_keys].tolist()

        return cit_subset, kept_keys
    

    def distribution_subsample(self, shard_id, index, file_idx):
        dist_file_path = os.path.join(self.args.group_dir, str(shard_id%100), f'{shard_id}_dist.pth')
        full_dist = torch.load(dist_file_path,map_location='cpu')[self.args.cluster_key]
        if not torch.is_tensor(full_dist):
            full_dist = torch.from_numpy(full_dist)
        out_group_keys = np.array(file_idx)[~index]
        dist = full_dist[~index,self.cluster_id]

        prob = torch.exp(-1.0 * self.distr_temp * (dist - self.dist_center[self.cluster_id])).numpy() / self.scaler[self.cluster_id]
        prob = prob / prob.sum()
        the_keys = np.random.choice(out_group_keys, int(len(out_group_keys) * self.args.soft_cluster[0]), replace=False, p = prob)

        return the_keys


    def prepare_calculator(self):
        statistics = [
            {'min': 0.5956248044967651, 'max': 2.8052046298980713},
            {'min': 0.6685439348220825, 'max': 2.7690610885620117},
            {'min': 0.47844812273979187, 'max': 2.750685453414917},
            {'min': 0.5937503576278687, 'max': 2.6991653442382812},
            {'min': 0.6449447274208069, 'max': 2.8133444786071777},
            {'min': 0.5251179337501526, 'max': 2.8260412216186523},
            {'min': 0.542658805847168, 'max': 2.771731376647949},
            {'min': 0.48344263434410095, 'max': 2.8329687118530273},
        ]
        self.dist_center = [item['min'] for item in statistics]
        self.scaler = [(1 - np.exp(-self.distr_temp * (item['max'] - item['min'])).item()) / self.distr_temp for item in statistics]


class IterativeFeatDataset(IterativeWebDataset):
    def __init__(self, args, transform, tokenize):
        super(IterativeFeatDataset,self).__init__(args, transform, tokenize)
        self.feat_path = '/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/2.feature-index-pretrained/dino'
        self.caption_path = '/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/3.caption-index'

    def __iter__(self):
        worker_id, num_workers, shard_id = self.get_worder_info()

        while True:
            _, kept_keys = self.dataset_filter(shard_id, None)

            all_feat = torch.load(os.path.join(self.feat_path, str(shard_id%100), f'{shard_id}_feat.pth'))
            all_caption = json.load(open(os.path.join(self.caption_path, str(shard_id%100), f'{shard_id}_caption.json'),'r'))
            kept_keys = all_caption['index'] if kept_keys is None else kept_keys
            # print('{}_{}_{}_{}'.format(len(kept_keys), shard_id, self.rank, self.cluster_id))

            for sample_idx in kept_keys:
                assert sample_idx in all_caption['index']
                
                image_txt = self.datapoint_feat_loading(sample_idx, all_caption, all_feat)
                if image_txt is None:
                    continue
                else:
                    image, txt = image_txt
                yield image, txt

            shard_id = self._get_next_shard_id(shard_id)
        

class IterativeHrchyWebDataset(IterativeWebDataset):
    # cluster agnostic
    def __init__(self, args, transform, tokenize):
        super(IterativeHrchyWebDataset,self).__init__(args, transform, tokenize)
        self.num_clusters = int(self.args.cluster_key[1:].split('B')[0])
        self.cluster_ids_init()
        self.warmup = None # self.warmup = self.args.soft_cluster if hasattr(args, 'rerun') and 'warm' in args.rerun else None

        # shard_id = 19807
        # cit_subset = dp(self.args, shard_id)
        # cit_subset,kept_keys = self.dataset_filter(shard_id, cit_subset)

    def cluster_ids_init(self):
        # from .cluster_list import build_feedback
        # cluster_dict = build_feedback(self.args)
        # if self.args.fine_mode in ['ImgNetAvg','ImgNetInd','CLIPInd','CLIPAvg']:
        #     self.cluster_id = cluster_dict[self.args.fine_mode][self.num_clusters]
        #     if hasattr(self.args,'cut') and self.args.cut >= 0:
        #         topx = cluster_dict[self.args.fine_mode]['cut'][self.num_clusters][self.args.cut]
        #         self.cluster_id = self.cluster_id[:topx]
        #     if 'Ind' in self.args.fine_mode and hasattr(self.args,'fuseavg') and self.args.fuseavg:
        #         avg_key = {'ImgNetInd':'ImgNetAvg','CLIPInd':'CLIPAvg'}[self.args.fine_mode]
        #         self.cluster_id = list(set(self.cluster_id + cluster_dict[avg_key][self.num_clusters]))
        #     if self.args.fine_mode == 'CLIPInd' and hasattr(self.args,'fusemust') and self.args.fusemust:
        #         self.cluster_id = list(set(self.cluster_id + cluster_dict['CLIPMust'][self.num_clusters]))
        #     # print(len(self.cluster_id))
        if self.args.fine_mode.startswith('H'):
            components = self.args.fine_mode.split('C')
            hrchy_root = '/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/clusterers/2-sbert/hrchy'
            hrchy = torch.load(os.path.join(hrchy_root,'F{}-C{}.pth'.format(self.num_clusters, components[0][1:])))
            self.cluster_id = [i for i,a in enumerate(hrchy['assign'].tolist()) if a==int(components[1])]
            # hrchy = {
            #     4:[0, 2, 1, 2, 1, 1, 3, 0, 0, 1, 1, 2, 1, 1, 0, 2, 2, 2, 3, 2, 2, 1, 2, 2, 2, 0, 1, 3, 2, 1, 3, 3, 1, 0, 3, 3, 0, 1, 1, 2, 2, 0, 0, 0, 2, 0, 3, 3, 0, 1, 1, 3, 2, 3, 0, 1, 2, 3, 2, 2, 3, 2, 1, 2, 3, 1, 3, 3, 3, 3, 1, 2, 1, 2, 0, 3, 3, 1, 0, 2, 2, 3, 0, 2, 1, 3, 0, 0, 0, 1, 1, 2, 0, 3, 0, 3, 2, 0, 2, 2, 0, 3, 2, 3, 2, 1, 3, 2, 2, 3, 1, 3, 2, 2, 3, 0, 2, 2, 2, 0, 0, 2, 3, 1, 0, 0, 3, 1, 2, 3, 2, 2, 3, 2, 1, 1, 0, 1, 1, 3, 1, 1, 3, 1, 1, 1, 0, 3, 3, 2, 3, 0, 2, 2, 0, 3, 2, 3, 0, 1, 1, 3, 3, 3, 1, 3, 3, 1, 3, 0, 2, 3, 1, 1, 3, 1, 2, 0, 0, 3, 0, 2, 0, 1, 1, 3, 0, 2, 3, 3, 3, 3, 1, 2, 2, 0, 1, 0, 1, 0, 3, 2, 3, 1, 2, 1, 3, 1, 3, 0, 0, 3, 3, 0, 0, 3, 2, 0, 1, 2, 3, 2, 1, 3, 3, 0, 2, 2, 1, 2, 3, 1, 1, 1, 2, 3, 1, 1, 1, 3, 2, 1, 0, 0, 1, 3, 0, 2, 3, 1, 1, 3, 2, 2, 3, 2, 1, 0, 0, 1, 2, 1, 0, 2, 3, 1, 3, 3, 2, 0, 0, 3, 2, 0, 1, 2, 3, 2, 0, 1, 3, 2, 0, 2, 3, 1, 2, 1, 0, 2, 3, 3, 0, 0, 0, 3, 2, 2, 2, 1, 0, 2, 1, 1, 2, 1, 0, 0, 2, 2, 2, 0, 3, 1, 2, 1, 2, 2, 3, 0, 2, 2, 3, 1, 1, 1, 3, 1, 3, 1, 0, 1, 3, 1, 0, 3, 2, 0, 1, 3, 2, 2, 3, 3, 2, 2, 1, 0, 3, 1, 3, 3, 0, 3, 3, 2, 1, 2, 2, 3, 1, 1, 3, 2, 2, 0, 3, 2, 2, 1, 0, 3, 0, 3, 2, 3, 2, 0, 2, 2, 2, 2, 0, 3, 2, 1, 0, 0, 0, 0, 2, 1, 1, 1, 0, 0, 3, 2, 2, 0, 3, 1, 1, 3, 3, 0, 0, 3, 2, 0, 1, 3, 0, 3, 1, 0, 3, 0, 3, 1, 0, 3, 2, 2, 3, 0, 0, 0, 2, 3, 0, 2, 0, 3, 2, 2, 3, 0, 1, 2, 3, 0, 3, 2, 3, 3, 3, 2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 1, 0, 0, 1, 0, 3, 0, 3, 3, 2, 2, 0, 1, 1, 0, 0, 2, 1, 3, 3, 3, 3, 0, 1, 3, 0, 3, 3, 2, 2, 3, 1, 1, 2, 2, 2, 1, 2, 2, 2, 3, 3, 1, 3, 1, 0, 1, 2, 0, 2, 3, 2, 1, 3, 3, 1, 2, 2, 2, 2, 0, 0, 1, 0, 2, 3, 0, 3, 2, 2, 2, 0, 3, 1, 1, 2, 1, 3, 0, 1, 2, 0, 3, 0, 3, 0, 2, 2, 3, 1, 2, 1, 3, 2, 1, 3, 3, 0, 2, 3, 2, 2, 1, 1, 2, 3, 2, 0, 3, 3, 1, 2, 3, 3, 0, 0, 3, 1, 2, 0, 2, 1, 2, 0, 0, 0, 1, 2, 0, 2, 2, 1, 3, 1, 1, 3, 3, 1, 0, 3, 2, 0, 3, 1, 1, 3, 3, 2, 3, 3, 2, 3, 2, 1, 1, 2, 0, 1, 0, 2, 0, 3, 1, 0, 3, 0, 3, 2, 0, 0, 3, 0, 0, 2, 2, 3, 2, 1, 2, 0, 2, 1, 1, 2, 1, 2, 2, 3, 0, 3, 0, 3, 2, 0, 1, 0, 3, 0, 2, 1, 0, 0, 2, 2, 1, 2, 3, 0, 1, 0, 3, 1, 1, 0, 2, 2, 3, 3, 2, 2, 0, 3, 3, 0, 1, 2, 0, 2, 3, 1, 0, 2, 0, 0, 3, 3, 3, 3, 3, 0, 2, 3, 1, 0, 0, 3, 0, 1, 2, 0, 2, 0, 3, 0, 2, 3, 3, 1, 1, 3, 3, 0, 0, 2, 3, 0, 2, 2, 1, 0, 3, 3, 2, 3, 2, 1, 2, 3, 0, 0, 0, 3, 1, 3, 1, 2, 1, 1, 2, 2, 1, 3, 3, 2, 2, 0, 2, 1, 0, 1, 2, 1, 2, 1, 3, 2, 1, 0, 0, 0, 2, 0, 0, 0, 1, 2, 2, 0, 0, 2, 1, 0, 3, 2, 3, 1, 2, 1, 2, 1, 3, 1, 3, 0, 3, 2, 0, 2, 0, 3, 1, 3, 2, 0, 1, 2, 2, 2, 0, 1, 2, 1, 3, 0, 0, 3, 2, 2, 2, 1, 1, 3, 3, 1, 2, 0, 3, 3, 3, 2, 1, 2, 2, 1, 3, 2, 0, 0, 1, 2, 3, 3, 0, 1, 1, 1, 0, 1, 2, 2, 1, 1, 3, 0, 1, 2, 3, 1, 3, 2, 1, 1, 2, 1, 2, 2, 3, 2, 3, 2, 1, 2, 2, 3, 0, 0, 0, 0, 1, 1, 2, 2, 3, 2, 1, 1, 0, 1, 3, 0, 3, 3, 3, 3, 0, 2, 1, 3, 2, 1, 2, 1, 2, 2, 3, 3, 2, 1, 0, 1, 2, 2, 1, 1, 1, 3, 2, 1, 1, 2, 1, 1, 0, 0, 1, 0, 3, 2, 3, 2, 1, 2, 2, 0, 1, 1, 2, 2, 2, 3, 1, 3, 0, 1, 1, 1, 2, 0, 1, 2, 1, 0, 2, 3, 0, 1, 2, 2, 1, 3, 3, 0, 1, 0, 1, 3, 2, 0, 0, 0, 1, 3, 3, 3, 0, 2, 2, 3, 1, 1, 1, 1, 1, 3, 2, 1, 0, 1, 1, 3, 2, 1, 0, 1, 1, 3, 3, 2, 1, 0, 3, 2, 0, 2, 2, 3, 1, 0, 0, 2, 3, 3, 1, 3, 1, 0, 3, 0, 1, 1, 0, 1, 2, 2, 2, 1],
            #     2:[0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1],
            # }
            # self.cluster_id = [i for i,a in enumerate(hrchy[int(components[0][1])]) if a==int(components[1])]
            # print(len(self.cluster_id))
        else:
            raise ValueError('Not Implemented Yet')

    def dataset_filter(self, shard_id, cit_subset):
        # Cluster-Agnostic
        if self.cluster_id is None:
            return cit_subset, None
        assert os.path.exists(self.args.group_dir)
        group_file_path = os.path.join(self.args.group_dir, str(shard_id%100), f'{shard_id}_assign_dist.json')
        # print(group_file_path)
        with open(group_file_path, 'r') as json_file:
            group_file = json.load(json_file)
        file_grp = group_file[self.args.cluster_key]
        filekeys = 'filekeys' if 'filekeys' in group_file else 'key'
        file_idx = group_file[filekeys]
        
        # kept_keys is ranked by nature
        index = (np.array(file_grp['assign'])[:,None]==np.array(self.cluster_id)[None]).sum(axis=-1)==1
        kept_keys = np.array(file_idx)[index]
        
        if 'thre_ic' in self.args.dataset_arg[1] and self.args.dataset_arg[1]['thre_ic'] > 0.0:
            dist = np.array(file_grp['dist'])[index]
            kept_ic_keys = kept_keys[dist >= self.args.dataset_arg[1]['thre_ic']]
            if self.args.dataset_arg[1]['rand_ic'] > 0.0:
                remove_ic_keys = kept_keys[dist < self.args.dataset_arg[1]['thre_ic']]
                the_keys = np.random.choice(remove_ic_keys, int(len(remove_ic_keys) * self.args.dataset_arg[1]['rand_ic']), replace=False)
                kept_keys = np.concatenate([kept_ic_keys,the_keys])
            else:
                kept_keys = kept_ic_keys

        if self.args.soft_cluster == 0.0 and self.warmup is None:
            all_keys = kept_keys
        else:
            out_group_keys = np.array(file_idx)[~index]
            num_ooc_samples = int(len(out_group_keys) * self.args.soft_cluster) if self.warmup is None else int(len(out_group_keys) * self.warmup)
            # if hasattr(self.args, 'head'):
            #     ooc_assign = np.array(file_grp['assign'])[~index]
            #     ooc_idx = (ooc_assign == 0) if self.args.head == 0 else (ooc_assign != 0)
            #     if ooc_idx.sum() >= num_ooc_samples:
            #         the_keys = np.random.choice(out_group_keys[ooc_idx], num_ooc_samples, replace=False)
            #     else:
            #         the_keys = np.concatenate([out_group_keys[ooc_idx],np.random.choice(out_group_keys[~ooc_idx], num_ooc_samples-ooc_idx.sum(), replace=False)])
            # else:
            if len(self.args.dataset_arg[1]) == 0:
                p = [1.0 for d in np.array(file_grp['assign'])[~index]]
            else:
                p=[self.args.dataset_arg[1]['rand_ooc'] if self.args.dataset_arg[1]['thre_ooc'] > 0.0 and d < self.args.dataset_arg[1]['thre_ooc'] else 1.0 for d in np.array(file_grp['dist'])[~index]]
            p = np.array(p) / np.array(p).sum()
            the_keys = np.random.choice(out_group_keys, num_ooc_samples, p=p, replace=False)

            all_keys = np.concatenate([kept_keys,the_keys])

        index = np.argsort(all_keys)
        kept_keys = all_keys[index]

        cit_subset = cit_subset[kept_keys]
        return cit_subset.tolist(), None


class IterativeHrchySoftWebDataset(IterativeWebDataset):
    # cluster agnostic
    def __init__(self, args, transform, tokenize):
        super(IterativeHrchySoftWebDataset,self).__init__(args, transform, tokenize)
        self.num_clusters = int(self.args.cluster_key[1:].split('B')[0])
        self.cluster_ids = np.arange(self.num_clusters)
        self.cluster_ids_init()

        shard_id = 19807
        cit_subset = dp(self.args, shard_id)
        cit_subset,kept_keys = self.dataset_filter(shard_id, cit_subset)

    def cluster_ids_init(self):
        from .cluster_list import build_feedback
        cluster_dict = build_feedback(self.args)

        if self.args.fine_mode in ['ImgNetAvg','ImgNetInd','CLIPInd','CLIPAvg']:
            self.cluster_prob = cluster_dict[self.args.fine_mode]['soft'][self.num_clusters]
        elif self.args.fine_mode.startswith('H'):
            hrchy_root = '/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/clusterers/2-sbert/hrchy'
            components = self.args.fine_mode.split('C')
            hrchy = torch.load(os.path.join(hrchy_root,'F{}-C{}.pth'.format(self.num_clusters, components[0][1:])))
            self.cluster_id = [i for i,a in enumerate(hrchy['assign'].tolist()) if a==int(components[1])]
            # print(len(self.cluster_id))
        else:
            raise ValueError('Not Implemented Yet')

    def dataset_filter(self, shard_id, cit_subset):
        assert os.path.exists(self.args.group_dir)
        group_file_path = os.path.join(self.args.group_dir, str(shard_id%100), f'{shard_id}_assign_dist.json')
        # print(group_file_path)
        with open(group_file_path, 'r') as json_file:
            group_file = json.load(json_file)
        file_grp = group_file[self.args.cluster_key]
        filekeys = 'filekeys' if 'filekeys' in group_file else 'key'
        file_idx = group_file[filekeys]

        cluster_prob = np.random.rand(self.num_clusters)
        cluster_id = self.cluster_ids[cluster_prob <= self.cluster_prob]
        # kept_keys is ranked by nature
        index = (np.array(file_grp['assign'])[:,None]==cluster_id[None]).sum(axis=-1)==1
        kept_keys = np.array(file_idx)[index]
        
        if 'sample_dist_scaler' in self.args.dataset_arg[1] and self.args.dataset_arg[1]['sample_dist_scaler'] >= 0:
            scaler = self.args.dataset_arg[1]['sample_dist_scaler']
            cluster_prob = np.random.rand(len(kept_keys))
            s2f_dist = np.array(file_grp['dist'])[index]
            s2f_assign = np.array(file_grp['assign'])[index]
            if scaler == 0:
                prob = 1.77 - s2f_dist
            else:
                raise ValueError('Not Implemented Yet')
            if self.args.dataset_arg[1]['cs_joint']:
                prob = prob * self.cluster_prob[s2f_assign]
            kept_keys = kept_keys[cluster_prob < prob]

        cit_subset = cit_subset[kept_keys]
        return cit_subset.tolist(), None
    

# ==============================================
# Cluster Agnostic Sampling
# 1. IterativeDynamicSubSampleWebDataset remove clusters
# 2. IterativeCASubSampleWebDataset remove IC samples
# 3. IterativeHrchyWebDataset remove IC samples in finegrained
# ==============================================
class IterativeDynamicSubSampleWebDataset(IterativeWebDataset):
    def __init__(self, args, transform, tokenize):
        super(IterativeDynamicSubSampleWebDataset,self).__init__(args, transform, tokenize)

        self.num_clusters = int(self.args.cluster_key[1:].split('B')[0])
        from itertools import combinations
        self.cluster_comb = list(combinations([i for i in range(self.num_clusters)], args.dataset_arg[1]['cluster_per_batch']))
        self.entr_temp = 15.0 if self.num_clusters < 128 else 18.0
        self.sample_mode = args.dataset_arg[1]['mode'] if len(args.dataset_arg)==2 and 'mode' in args.dataset_arg[1] else 1

    def set_epoch(self, epoch, num_batches, step=0):
        random.seed(epoch+step)
        self.shard_ids = list(range(self.num_shards))
        random.shuffle(self.shard_ids)
        random.shuffle(self.cluster_comb)
        self.start_shard_id = (num_batches * epoch) % self.num_shards

    def dataset_filter(self, cit_subset, shard_id, cluster_grp):
        # Cluster-Agnostic
        assert os.path.exists(self.args.group_dir)
        group_file_path = os.path.join(self.args.group_dir, str(shard_id%100), f'{shard_id}_group.json')
        dist_file_path = os.path.join(self.args.group_dir, str(shard_id%100), f'{shard_id}_dist.pth')
        with open(group_file_path, 'r') as json_file:
            group_file = json.load(json_file)
        file_grp = group_file[self.args.cluster_key]
        filekeys = 'filekeys' if 'filekeys' in group_file else 'key'
        all_keys = np.array(group_file[filekeys]) 

        dist = torch.load(dist_file_path,map_location='cpu')[self.args.cluster_key]
        if not torch.is_tensor(dist):
            dist = torch.from_numpy(dist)
        sim = 1.0-dist/2.0        
        prob = F.softmax(self.entr_temp * sim,dim=-1)
        entropy = torch.special.entr(prob).sum(dim=-1) / torch.log(torch.tensor(self.num_clusters))

        # kept_keys is ranked by nature
        kept_keys,cluster_idx = [],[]
        for cluster_id in list(cluster_grp):
            index = np.array(file_grp) == cluster_id
            keys_candidate = all_keys[index]
            entr_candidate = 1.0 - entropy[index].numpy()
            sub_index = np.random.choice(len(keys_candidate),512,replace=False,p=entr_candidate/entr_candidate.sum())
            kept_keys.append(keys_candidate[sub_index])
            cluster_idx.append([cluster_id,] * 512)

        if self.sample_mode == 1:
            kept_keys = np.stack(kept_keys,axis=-1).reshape(-1)
            cluster_idx = np.stack(cluster_idx,axis=-1).reshape(-1)
        else:
            kept_keys = np.concatenate(kept_keys)
            index = np.argsort(kept_keys)
            kept_keys = kept_keys[index]
            cluster_idx = np.array(cluster_idx)[index]
        cit_subset = cit_subset[kept_keys]

        return cit_subset.tolist(), cluster_idx.tolist()

    def __iter__(self):
        worker_id, num_workers, shard_id = self.get_worder_info()
        cluster_id = 0+worker_id
        cluster_grp = self.cluster_comb[cluster_id]

        while True:
            cit_subset = dp(self.args, shard_id)
            if cit_subset is None or cit_subset.shape[0] == 0:
                shard_id = self._get_next_shard_id(shard_id)
                continue
            cit_subset,_ = self.dataset_filter(cit_subset, shard_id, cluster_grp)

            fb_bboxes = load_fb_bbox(self.args, shard_id)
            tarball_path = self._get_tarball_path(shard_id)

            with open(tarball_path) as f:
                with mmap.mmap(fileno=f.fileno(), length=0, access=mmap.ACCESS_READ) as m:
                    for fileidx, entry in enumerate(cit_subset):
                        image_txt = self.datapoint_loading(fileidx, entry, fb_bboxes, m)
                        if image_txt is None:
                            continue 
                        yield image_txt[0], image_txt[1]

            shard_id = self._get_next_shard_id(shard_id)
            cluster_id,cluster_grp = self._get_next_cluster_comb(cluster_id, num_workers)
    
    def _get_next_cluster_comb(self, cluster_id, num_workers):
        cluster_id = (cluster_id + num_workers) % len(self.cluster_comb)
        return cluster_id, self.cluster_comb[cluster_id]


class IterativeCASubSampleWebDataset(IterativeWebDataset):
    # cluster agnostic
    def __init__(self, args, transform, tokenize):
        super(IterativeCASubSampleWebDataset,self).__init__(args, transform, tokenize)
        self.num_clusters = int(self.args.cluster_key[1:].split('B')[0])
        center_root = '/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/clusterers'
        self.cluster_centers = torch.load(os.path.join(center_root, '2-sbert', f'kmeans-{self.num_clusters}-bal-1-dim768-cos.pth'))

    def dataset_filter(self, shard_id, cit_subset):
        # Cluster-Agnostic
        assert os.path.exists(self.args.group_dir)
        group_file_path = os.path.join(self.args.group_dir, str(shard_id%100), f'{shard_id}_group.json')
        with open(group_file_path, 'r') as json_file:
            group_file = json.load(json_file)
        file_grp = group_file[self.args.cluster_key]
        filekeys = 'filekeys' if 'filekeys' in group_file else 'key'
        all_keys = np.array(group_file[filekeys]) 

        if self.num_clusters > 128:
            embed_root = '/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/2.feature-index-pretrained/simcse-1'
            embed_path = os.path.join(embed_root, str(shard_id%100), f'{shard_id}_feat.pth')
            embedding = torch.load(embed_path)
        else:
            dist_file_path = os.path.join(self.args.group_dir, str(shard_id%100), f'{shard_id}_dist.pth')
            dist = torch.load(dist_file_path,map_location='cpu')[self.args.cluster_key]
            if not torch.is_tensor(dist):
                dist = torch.from_numpy(dist)
            sim = 1.0-dist/2.0        
            prob = F.softmax(self.entr_temp * sim,dim=-1)
            entropy = torch.special.entr(prob).sum(dim=-1) / torch.log(torch.tensor(self.num_clusters))

        # kept_keys is ranked by nature
        kept_keys,cluster_idx = [],[]
        for cluster_id in list(cluster_grp):
            index = np.array(file_grp) == cluster_id
            keys_candidate = all_keys[index]
            entr_candidate = 1.0 - entropy[index].numpy()
            sub_index = np.random.choice(len(keys_candidate),512,replace=False,p=entr_candidate/entr_candidate.sum())
            kept_keys.append(keys_candidate[sub_index])
            cluster_idx.append([cluster_id,] * 512)

        if self.sample_mode == 1:
            kept_keys = np.stack(kept_keys,axis=-1).reshape(-1)
            cluster_idx = np.stack(cluster_idx,axis=-1).reshape(-1)
        else:
            kept_keys = np.concatenate(kept_keys)
            index = np.argsort(kept_keys)
            kept_keys = kept_keys[index]
            cluster_idx = np.array(cluster_idx)[index]
        cit_subset = cit_subset[kept_keys]

        return cit_subset.tolist(), None


class IterativeMultiWebDataset(IterativeWebDataset):
    # cluster agnostic
    def __init__(self, args, transform, tokenize):
        super(IterativeMultiWebDataset,self).__init__(args, transform, tokenize)
        self.num_clusters = int(self.args.cluster_key[1:].split('B')[0])
        center_root = '/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/clusterers'
        self.num_fine_clusters = int(self.args.fine_key[1:].split('B')[0])

    def dataset_filter(self, shard_id, cit_subset):
        # Cluster-Agnostic
        if self.cluster_id is None:
            return cit_subset, None
        assert os.path.exists(self.args.group_dir)
        group_file_path = os.path.join(self.args.group_dir, str(shard_id%100), f'{shard_id}_group.json')
        
        with open(group_file_path, 'r') as json_file:
            group_file = json.load(json_file)
        file_grp = group_file[self.args.cluster_key]
        filekeys = 'filekeys' if 'filekeys' in group_file else 'key'
        file_idx = group_file[filekeys]
        
        # kept_keys is ranked by nature
        if isinstance(self.cluster_id,int):
            index = np.array(file_grp)==self.cluster_id
        else:
            index = (np.array(file_grp)[:,None]==np.array(self.cluster_id)[None]).sum(axis=-1)==1
        kept_keys = np.array(file_idx)[index]

        find_assign_path = os.path.join(self.args.group_dir, str(shard_id%100), f'{shard_id}_assign_dist.json')
        fine_assign = json.load(open(find_assign_path, 'r'))[self.args.fine_key]

        if 'thre_ic' in self.args.dataset_arg[1] and self.args.dataset_arg[1]['thre_ic'] > 0.0:
            dist = np.array(fine_assign['dist'])[index]
            kept_ic_keys = kept_keys[dist >= self.args.dataset_arg[1]['thre_ic']]
            if self.args.dataset_arg[1]['rand_ic'] > 0.0:
                remove_ic_keys = kept_keys[dist < self.args.dataset_arg[1]['thre_ic']]
                the_keys = np.random.choice(remove_ic_keys, int(len(remove_ic_keys) * self.args.dataset_arg[1]['rand_ic']), replace=False)
                kept_keys = np.concatenate([kept_ic_keys,the_keys])
            else:
                kept_keys = kept_ic_keys

        out_group_keys = np.array(file_idx)[~index]
        num_ooc_samples = int(len(out_group_keys) * self.args.soft_cluster)
        p=[self.args.dataset_arg[1]['rand_ooc'] if self.args.dataset_arg[1]['thre_ooc'] > 0.0 and d < self.args.dataset_arg[1]['thre_ooc'] else 1.0 for d in np.array(fine_assign['dist'])[~index]]
        p = np.array(p) / np.array(p).sum()
        the_keys = np.random.choice(out_group_keys, num_ooc_samples, p=p, replace=False)

        all_keys = np.concatenate([kept_keys,the_keys])
        index = np.argsort(all_keys)
        kept_keys = all_keys[index]

        cit_subset = cit_subset[kept_keys]
        return cit_subset.tolist(), None
    
# =================================================
# Soft Label Generation
# =================================================
class IterativeSoftWebDataset(IterativeWebDataset):
    def __init__(self, args, transform, tokenize):
        super(IterativeSoftWebDataset,self).__init__(args, transform, tokenize)
        # self.get_item(26854)
        self.fileter_ref = args.dataset_arg[1]['remove'] if len(args.dataset_arg) == 2 and 'remove' in args.dataset_arg[1] else None
        assert hasattr(self.args,'cluster_key') and self.args.cluster_key is not None
        self.num_clusters = int(self.args.cluster_key[1:].split('B')[0])
        self.entr_temp = 15.0 if self.num_clusters < 128 else 18.0

    def __iter__(self):
        worker_id, num_workers, shard_id = self.get_worder_info()

        while True:
            cit_subset = dp(self.args, shard_id)
            if cit_subset is None or cit_subset.shape[0] == 0:
                shard_id = self._get_next_shard_id(shard_id)
                continue

            fb_bboxes = load_fb_bbox(self.args, shard_id)
            tarball_path = self._get_tarball_path(shard_id)
            hard_assign, soft_assign, entropy = self.loading_soft(shard_id)
            with open(tarball_path) as f:
                with mmap.mmap(fileno=f.fileno(), length=0, access=mmap.ACCESS_READ) as m:
                    for fileidx, entry in enumerate(cit_subset):
                        if entropy is not None and entropy[fileidx] > self.fileter_ref:
                            continue
                        image_txt = self.datapoint_loading(fileidx, entry, fb_bboxes, m)
                        if image_txt is None:
                            continue 
                        image, txt = image_txt
                        yield image, txt, {'hard':hard_assign[fileidx], 'soft':soft_assign[fileidx]}

            shard_id = self._get_next_shard_id(shard_id)
    
    def loading_soft(self, shard_id):
        group_file_path = os.path.join(self.args.group_dir, str(shard_id%100), f'{shard_id}_group.json')
        dist_file_path = os.path.join(self.args.group_dir, str(shard_id%100), f'{shard_id}_dist.pth')
        with open(group_file_path, 'r') as json_file:
            group_file = json.load(json_file)
        
        assignment = group_file[self.args.cluster_key]
        file_idx = group_file['filekeys' if 'filekeys' in group_file else 'key']
        distance = torch.load(dist_file_path,map_location='cpu')[self.args.cluster_key]
        if not torch.is_tensor(distance):
            distance = torch.from_numpy(distance)
        if 'svd' in  self.args.group_dir or 'cos' in self.args.group_dir:
            sim = 1.0-distance/2
        elif self.args.group_dir in ['2-bert','2-roberta']:
            sim = 1.0-distance # JPM: Tentatively set this form, will change later
        if self.fileter_ref is not None:
            prob = F.softmax(self.entr_temp * sim,dim=-1)
            entropy = torch.special.entr(prob).sum(dim=-1) / torch.log(torch.tensor(self.num_clusters))
        else:
            entropy = None

        if max(file_idx) == len(file_idx) - 1:
            hard_assign = assignment
            soft_assign = sim
        else:
            hard_assign = {k:v for k,v in zip(file_idx,assignment)}
            soft_assign = {k:v for k,v in zip(file_idx,sim)}
            entropy = None if entropy is None else {k:v for k,v in zip(file_idx,entropy)}
        return hard_assign, soft_assign, entropy


class IterativeSoftFeatDataset(IterativeSoftWebDataset):
    def __init__(self, args, transform, tokenize):
        super(IterativeSoftFeatDataset,self).__init__(args, transform, tokenize)
        self.feat_path = '/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/2.feature-index-pretrained/dino'
        self.caption_path = '/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/3.caption-index'

    def __iter__(self):
        worker_id, num_workers, shard_id = self.get_worder_info()
        while True:
            hard_assign, soft_assign, entropy = self.loading_soft(shard_id)

            all_feat = torch.load(os.path.join(self.feat_path, str(shard_id%100), f'{shard_id}_feat.pth'))
            all_caption = json.load(open(os.path.join(self.caption_path, str(shard_id%100), f'{shard_id}_caption.json'),'r'))
            kept_keys = all_caption['index']
            # print(entropy.size(), len(kept_keys), (entropy <= self.fileter_ref).sum() )

            for sample_idx in kept_keys:
                assert sample_idx in all_caption['index']
                if entropy is not None and entropy[sample_idx] > self.fileter_ref:
                    continue
                
                image_txt = self.datapoint_feat_loading(sample_idx, all_caption, all_feat)
                if image_txt is None:
                    continue
                else:
                    image, txt = image_txt
                yield image, txt, {'hard':hard_assign[sample_idx], 'soft':soft_assign[sample_idx]}

            shard_id = self._get_next_shard_id(shard_id)


def get_cit_iter_wds_dataset(args, preprocess_fn, is_train, epoch=0):
    # borrowed from get_csv_dataset
    input_filename = args.train_data if is_train else args.val_data
    assert input_filename
    if hasattr(args,'lu_mode') and args.lu_mode not in LU_LIST:
        try:
            tokenizer_kwargs = {}
            txt_tokenize = AutoTokenizer.from_pretrained(args.lu_mode) 
        except:
            txt_tokenize = AutoTokenizer.from_pretrained("princeton-nlp/sup-simcse-bert-base-uncased") 
    else:
        txt_tokenize = tokenize

    if hasattr(args,'dataset_arg'):
        if args.dataset_arg[0] == 'IterativeSoftWebDataset':
            dataset = IterativeSoftWebDataset(args, preprocess_fn, txt_tokenize)
        elif args.dataset_arg[0] == 'IterativeSoftFeatDataset':
            dataset = IterativeSoftFeatDataset(args, preprocess_fn, txt_tokenize)
        elif args.dataset_arg[0] == 'IterativeDynamicSubSampleWebDataset':
            dataset = IterativeDynamicSubSampleWebDataset(args, preprocess_fn, txt_tokenize)
        elif args.dataset_arg[0] == 'IterativeCASubSampleWebDataset':
            dataset = IterativeCASubSampleWebDataset(args, preprocess_fn, txt_tokenize)
        elif args.dataset_arg[0] == 'IterativeHrchyWebDataset':
            dataset = IterativeHrchyWebDataset(args, preprocess_fn, txt_tokenize)
        elif args.dataset_arg[0] == 'IterativeMultiWebDataset':
            dataset = IterativeMultiWebDataset(args, preprocess_fn, txt_tokenize)
        elif args.dataset_arg[0] == 'IterativeHrchySoftWebDataset':
            dataset = IterativeHrchySoftWebDataset(args, preprocess_fn, txt_tokenize)
        elif hasattr(args,'no_aug_lit') or args.dataset_arg[0] == 'IterativeFeatDataset':
            dataset = IterativeFeatDataset(args, preprocess_fn, txt_tokenize)
        else:
            dataset = IterativeWebDataset(args, preprocess_fn, txt_tokenize)
    else:
        if hasattr(args,'no_aug_lit'):
            dataset = IterativeFeatDataset(args, preprocess_fn, txt_tokenize)
        else:
            dataset = IterativeWebDataset(args, preprocess_fn, txt_tokenize)

    assert is_train
    num_samples = args.train_num_samples
    sampler = None

    dataloader = torch.utils.data.DataLoader(
        dataset, sampler=sampler,
        batch_size=args.batch_size,
        num_workers=args.workers,
        pin_memory=False,
        drop_last=True,
    )

    if hasattr(args, "one_iter"):
        dataloader = iter(dataloader)
        print("[training/data.py] dataloader = iter(dataloader) as a cross-epoch dataloader.")

    dataloader.num_samples = num_samples
    dataloader.num_batches = int(num_samples / (args.batch_size * args.world_size))
    return DataInfo(dataloader, sampler)



# class IterativeSoftSubSampleWebDataset(IterativeWebDataset):
#     def __init__(self, args, transform, tokenize):
#         super(IterativeSoftSubSampleWebDataset,self).__init__(args, transform, tokenize)

#         self.remove_list = args.remove_list if hasattr(args, 'remove_list') else None
#         self.num_classes = int(self.args.cluster_key[1:].split('B')[0])
#         self.entr_temp = 15.0 if self.num_classes < 128 else 18.0

#     def dataset_filter(self, cit_subset, shard_id):
#         # Cluster-Agnostic
#         assert os.path.exists(self.args.group_dir)
#         group_file_path = os.path.join(self.args.group_dir, str(shard_id%100), f'{shard_id}_group.json')
#         dist_file_path = os.path.join(self.args.group_dir, str(shard_id%100), f'{shard_id}_dist.pth')
#         with open(group_file_path, 'r') as json_file:
#             group_file = json.load(json_file)
#         file_grp = group_file[self.args.cluster_key]
#         filekeys = 'filekeys' if 'filekeys' in group_file else 'key'
#         kept_keys = np.array(group_file[filekeys]) 
        
#         # kept_keys is ranked by nature
#         index = None
#         if self.remove_list is not None:
#             if isinstance(self.remove_list,int):
#                 index = np.array(file_grp)!=self.remove_list
#             else:
#                 index = (np.array(file_grp)[:,None]==np.array(self.remove_list)[None]).sum(axis=-1)==0
#             kept_keys = kept_keys[index]
        
#         # Fileter In-Group Data points
#         sim = None
#         if self.args.soft_cluster[1] > 0.0:
#             dist = torch.load(dist_file_path,map_location='cpu')[self.args.cluster_key]
#             if not torch.is_tensor(dist):
#                 dist = torch.from_numpy(dist)
#             if index is not None:
#                 dist = dist[index] 
#             sim = 1.0-dist/2.0
            
#             prob = F.softmax(self.entr_temp * sim,dim=-1)
#             entropy = torch.special.entr(prob).sum(dim=-1) / torch.log(torch.tensor(self.num_classes))
#             ref = 1.0-self.args.soft_cluster[1]
#             kept_keys = kept_keys[entropy<=ref]
#             sim = sim[entropy<=ref]

#         cit_subset = cit_subset[kept_keys]

#         return cit_subset.tolist(), sim 

#     def __iter__(self):
#         worker_info = torch.utils.data.get_worker_info()
#         if worker_info is None:
#             num_workers = 1
#             worker_id = 0
#         else:
#             num_workers = worker_info.num_workers
#             worker_id = worker_info.id
#         _, global_rank, world_size = world_info_from_env()
#         self.group_size = int(num_workers * world_size)
#         shard_id = num_workers * global_rank + worker_id
#         shard_id = (shard_id + self.start_shard_id) % self.num_shards
#         shard_id = self.shard_ids[shard_id]

#         while True:
#             cit_subset = dp(self.args, shard_id)
#             if cit_subset is None or cit_subset.shape[0] == 0:
#                 shard_id = self._get_next_shard_id(shard_id)
#                 continue
#             cit_subset, similarity = self.dataset_filter(cit_subset, shard_id)

#             fb_bboxes = load_fb_bbox(self.args, shard_id)
#             tarball_path = self._get_tarball_path(shard_id)

#             with open(tarball_path) as f:
#                 with mmap.mmap(fileno=f.fileno(), length=0, access=mmap.ACCESS_READ) as m:
#                     for fileidx, entry in enumerate(cit_subset):
#                         keyid, keyoffset, jpg_start_offset, jpg_end_offset, txt_start_offset, txt_end_offset = entry[0], entry[1], entry[2], entry[3], entry[4], entry[5]
                        
#                         assert txt_start_offset != txt_end_offset
#                         text_json = json.load(BytesIO(m[txt_start_offset:txt_end_offset]))
#                         if text_json["hash"] in self.dedup_set:
#                             continue
                        
#                         if isinstance(text_json["texts"], dict):
#                             text_key = ["alt", "title", "data-image-title"][keyid]
#                             txt = text_json["texts"][text_key][keyoffset]["text"]
#                         else:
#                             txt = text_json["texts"][keyoffset][1]
#                         txt = self.tokenizer([txt])[0]

#                         with Image.open(BytesIO(m[jpg_start_offset:jpg_end_offset])) as img:
#                             image = img.convert("RGB")
#                             faces = fb_bboxes[str(jpg_start_offset)]
#                             image = fairblurbbox(image, faces) # 25~40s
#                             image = self.transform(image)
                        
#                         yield image, txt, 1.0 #similarity[fileidx]

#             shard_id = self._get_next_shard_id(shard_id)
    