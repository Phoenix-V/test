import math
import torch
import torch.nn.functional as F

import json
import os
import logging

from tqdm import tqdm
from collections import defaultdict


@torch.no_grad()
def slip_evaluate(args, model, val_transform, tokenizer):  # huxu: borrowed from CiT, think about how to merge into `CLIP_benchmark`.
    from clipeval import datasets, eval_zeroshot

    catalog, all_templates, all_labels = eval_zeroshot.load_metadata("clipeval")

    if hasattr(model, "module"):
        model = model.module

    metrics = {}
    for d in catalog:
        val_dataset = datasets.get_downstream_dataset(
            catalog, d, is_train=False, transform=val_transform)
        templates = all_templates[d]
        labels = all_labels[d]

        val_loader = torch.utils.data.DataLoader(
            val_dataset, batch_size=args.batch_size//2, shuffle=False,
            num_workers=args.workers, pin_memory=False, drop_last=False)
            
        logging.info(f'eval starts for {d}')
        metric = eval_zeroshot.evaluate(d, val_loader, templates, labels, model, tokenizer)
        logging.info(f'eval ends for {d}')
        metrics[d] = metric
        json_str = json.dumps({"task": d, "acc": metric})
        if args.rank == 0:
            print(json_str)
            with open(os.path.join(args.output_dir, "slip.txt"), mode="a+", encoding="utf-8") as f:
                f.write(json_str + "\n")
    return metrics


@torch.no_grad()
def slip_evaluate_center(args, model, val_transform, tokenizer, path):  # huxu: borrowed from CiT, think about how to merge into `CLIP_benchmark`.
    from clipeval import datasets, eval_zeroshot

    catalog, all_templates, all_labels = eval_zeroshot.load_metadata("clipeval")

    if hasattr(model, "module"):
        model = model.module
    metrics = {}
    for d in catalog:

        templates = all_templates[d]
        labels = all_labels[d]
        text_features, _, _ = eval_zeroshot.build_text_features(templates, labels, model, tokenizer)

        torch.save(text_features, os.path.join(path,f'{d}-center.pth'))


@torch.no_grad()
def slip_evaluate_logits(args, model, val_transform, tokenizer, idx):  # huxu: borrowed from CiT, think about how to merge into `CLIP_benchmark`.
    from clipeval import datasets, eval_zeroshot

    catalog, all_templates, all_labels = eval_zeroshot.load_metadata("clipeval")

    if hasattr(model, "module"):
        model = model.module
    metrics = {}
    for d in catalog:
        # if d not in ['KITTI','OxfordPets','StanfordCars','FacialEmotionRecognition2013']:
        #     continue
        val_dataset = datasets.get_downstream_dataset(
            catalog, d, is_train=False, transform=val_transform)
        templates = all_templates[d]
        labels = all_labels[d]

        # if args.val_task not in ["mt", "imagenet21k", "imagenet1k"] and hasattr(args, "extra_prompt") and d == "imagenet":  # not eval MT in LiT setup.
        #    templates.extend(["A photo of a {}", "{}"])  # see LiT page 16.

        val_loader = torch.utils.data.DataLoader(
            val_dataset, batch_size=args.batch_size//2, shuffle=False,
            num_workers=args.workers, pin_memory=False, drop_last=False)

        metric, logits, centers = eval_zeroshot.evaluate_logits(d, val_loader, templates, labels, model, tokenizer)
        # metrics[d] = metric
        json_str = json.dumps({"model": idx, "task": d, "acc": metric})
        print(json_str)
        logging.info(json_str)
        torch.save({'logits':logits[0], 'targets':logits[1], "centers":centers}, os.path.join(args.slip_dir, f'{d}_pred-{idx}.pth'))
        with open(os.path.join(args.slip_dir, "slip.txt"), mode="a+", encoding="utf-8") as f:
            f.write(json_str + "\n")
        
    return metrics