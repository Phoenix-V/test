import os
import json
import math
import webdataset as wds
import random

from io import BytesIO
from PIL import Image

from .data import (
    get_dataset_size,
    SharedEpoch,
    ResampledShards2,
    detshuffle2,
    tarfile_to_samples_nothrow,
    log_and_continue,
    DataInfo,
    filter_no_caption,
    preprocess_txt,
)
from .data import (
    _SHARD_SHUFFLE_SIZE,
    _SHARD_SHUFFLE_INITIAL,
    _SAMPLE_SHUFFLE_SIZE,
    _SAMPLE_SHUFFLE_INITIAL,
)


class ImageLoader:
    def __init__(self, preprocess_img):
        self.preprocess_img = preprocess_img

    def __call__(self, data):
        with Image.open(BytesIO(data)) as image:
            image = image.convert("RGB")
        return self.preprocess_img(image)


class ItemFilter:
    def __init__(self, args):
        self.args = args
        self.shard_id = -1

    def __call__(self, sample):
        text_json = sample["json"]
        if hasattr(self.args, "cit_dir"):
            shard_id = int(os.path.basename(sample["__url__"])[:-len(".tar")])
            if shard_id != self.shard_id:
                self.shard_id = shard_id
                shard_folder = self.shard_id % 100
                fn = os.path.join(self.args.cit_dir, f"{shard_folder}", f"{self.shard_id}.json")
                with open(fn) as f:
                    self.query_subset = json.load(f)
            uuid = sample["__key__"]  # os.path.basename(sample["__key__"])
            if uuid not in self.query_subset:
                return False

        # valid keys: ['width', 'height', 'hash', 'texts', 'top_lang', 'concepts']
        # TODO: (only support a single key).
        assert hasattr(self.args, "use_key"), "use_key to avoid using other surrounding text."
        if self.args.use_key in text_json["texts"]:
            sample["text"] = random.choice(text_json["texts"][self.args.use_key])["text"]
            return True
        return False


def get_m2c2_wds_dataset(args, preprocess_img, is_train, epoch=0, floor=False):
    input_shards = args.train_data if is_train else args.val_data
    assert input_shards is not None
    resampled = getattr(args, 'dataset_resampled', False) and is_train

    num_samples, num_shards = get_dataset_size(input_shards)
    if not num_samples:
        if is_train:
            num_samples = args.train_num_samples
            if not num_samples:
                raise RuntimeError(
                    'Currently, number of dataset samples must be specified for training dataset. '
                    'Please specify via `--train-num-samples` if no dataset length info present.')
        else:
            num_samples = args.val_num_samples or 0  # eval will just exhaust the iterator if not specified

    # huxu: group by shard_id.
    from configs import parse_start_end
    start, end = parse_start_end(input_shards)
    dirname = os.path.dirname(input_shards)
    shards_list = [os.path.join(dirname, f"{shard_id % 100}", f"{shard_id}.tar") for shard_id in range(int(start), int(end))]
    print(f"built group of shards from {input_shards}, start={start}, end={end}")

    shared_epoch = SharedEpoch(epoch=epoch)  # create a shared epoch store to sync epoch to dataloader worker proc
    if resampled:
        pipeline = [ResampledShards2(shards_list, deterministic=True, epoch=shared_epoch)]
    else:
        pipeline = [wds.SimpleShardList(shards_list)]

    # at this point we have an iterator over all the shards
    if is_train:
        if not resampled:
            pipeline.extend([
                detshuffle2(
                    bufsize=_SHARD_SHUFFLE_SIZE,
                    initial=_SHARD_SHUFFLE_INITIAL,
                    seed=args.seed,
                    epoch=shared_epoch,
                ),
                wds.split_by_node,
                wds.split_by_worker,
            ])
        pipeline.extend([
            # at this point, we have an iterator over the shards assigned to each worker at each node
            tarfile_to_samples_nothrow,  # wds.tarfile_to_samples(handler=log_and_continue),
            wds.shuffle(
                bufsize=_SAMPLE_SHUFFLE_SIZE,
                initial=_SAMPLE_SHUFFLE_INITIAL,
            ),
        ])
    else:
        pipeline.extend([
            wds.split_by_worker,
            # at this point, we have an iterator over the shards assigned to each worker
            wds.tarfile_to_samples(handler=log_and_continue),
        ])

    pipeline.extend([
        wds.decode(handler=log_and_continue),  # load json using default but not decode image.
        wds.select(ItemFilter(args)),  # create text field from json
        wds.rename(image="jpeg"),
        wds.map_dict(image=ImageLoader(preprocess_img), text=preprocess_txt),
        wds.to_tuple("image", "text"),
        wds.batched(args.batch_size, partial=not is_train),
    ])

    dataset = wds.DataPipeline(*pipeline)
    if is_train:
        if not resampled:
            assert num_shards >= args.workers * args.world_size, 'number of shards must be >= total workers'
        # roll over and repeat a few samples to get same number of full batches on each node
        round_fn = math.floor if floor else math.ceil
        global_batch_size = args.batch_size * args.world_size
        num_batches = round_fn(num_samples / global_batch_size)
        num_workers = max(1, args.workers)
        num_worker_batches = round_fn(num_batches / num_workers)  # per dataloader worker
        num_batches = num_worker_batches * num_workers
        num_samples = num_batches * global_batch_size
        dataset = dataset.with_epoch(num_worker_batches)  # each worker is iterating over this
    else:
        # last batches are partial, eval is done on single (master) node
        num_batches = math.ceil(num_samples / args.batch_size)

    dataloader = wds.WebLoader(
        dataset,
        batch_size=None,
        shuffle=False,
        num_workers=args.workers,
        persistent_workers=True,
    )

    # FIXME not clear which approach is better, with_epoch before vs after dataloader?
    # hoping to resolve via https://github.com/webdataset/webdataset/issues/169
    # if is_train:
    #     # roll over and repeat a few samples to get same number of full batches on each node
    #     global_batch_size = args.batch_size * args.world_size
    #     num_batches = math.ceil(num_samples / global_batch_size)
    #     num_workers = max(1, args.workers)
    #     num_batches = math.ceil(num_batches / num_workers) * num_workers
    #     num_samples = num_batches * global_batch_size
    #     dataloader = dataloader.with_epoch(num_batches)
    # else:
    #     # last batches are partial, eval is done on single (master) node
    #     num_batches = math.ceil(num_samples / args.batch_size)

    # add meta-data to dataloader instance for convenience
    dataloader.num_batches = num_batches
    dataloader.num_samples = num_samples

    return DataInfo(dataloader=dataloader, shared_epoch=shared_epoch)
