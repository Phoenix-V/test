import torch
import torch.nn as nn
from torch.nn import functional as F
import pdb
import numpy as np

try:
    import torch.distributed.nn
    from torch import distributed as dist
    has_distributed = True
except ImportError:
    has_distributed = False

try:
    import horovod.torch as hvd
except ImportError:
    hvd = None


def gather_features(
        image_features,
        text_features,
        local_loss=False,
        gather_with_grad=False,
        rank=0,
        world_size=1,
        use_horovod=False,
        gpu_idx=None, #place holder purpose only
):
    assert has_distributed, 'torch.distributed did not import correctly, please use a PyTorch version with support.'
    if use_horovod:
        assert hvd is not None, 'Please install horovod'
        if gather_with_grad:
            all_image_features = hvd.allgather(image_features)
            all_text_features = hvd.allgather(text_features)
        else:
            with torch.no_grad():
                all_image_features = hvd.allgather(image_features)
                all_text_features = hvd.allgather(text_features)
            if not local_loss:
                gathered_image_features = list(all_image_features.chunk(world_size, dim=0))
                gathered_text_features = list(all_text_features.chunk(world_size, dim=0))
                gathered_image_features[rank] = image_features
                gathered_text_features[rank] = text_features
                all_image_features = torch.cat(gathered_image_features, dim=0)
                all_text_features = torch.cat(gathered_text_features, dim=0)
    else:
        if gather_with_grad:
            all_image_features = torch.cat(torch.distributed.nn.all_gather(image_features), dim=0)
            all_text_features = torch.cat(torch.distributed.nn.all_gather(text_features), dim=0)
        else:
            gathered_image_features = [torch.zeros_like(image_features) for _ in range(world_size)]
            gathered_text_features = [torch.zeros_like(text_features) for _ in range(world_size)]
            dist.all_gather(gathered_image_features, image_features)
            dist.all_gather(gathered_text_features, text_features)
            if not local_loss:
                gathered_image_features[rank] = image_features
                gathered_text_features[rank] = text_features
            all_image_features = torch.cat(gathered_image_features, dim=0)
            all_text_features = torch.cat(gathered_text_features, dim=0)

    return all_image_features, all_text_features

def order_recovery(features, index, batch_size, local_contrast, rank):
    '''index = [sample idx, gpu idx]
    gpu idx is based on the order of anchor features
    if local_contrast is False, return all features
    if local_contrast is True, return features of paired with anchors in current GPU (may not all of them are from the current GPU)
    '''
    if local_contrast:
        features = features[index[:,1]==rank]
        index = index[index[:,1]==rank]
        index[:,1] = 0

    global_idx = index[:,1] * batch_size + index[:,0]
    ref_idx = torch.arange(len(index),dtype=index.dtype, device=index.device)
    recover_idx = torch.zeros_like(ref_idx)
    recover_idx[global_idx] = ref_idx
    features = features[recover_idx]
    return features


def CrossEntropyLossDeDup(logits, labels, ref):
    with torch.no_grad():
        anchor, contrast = ref
        diff = torch.cdist(anchor[None].half(),contrast[None].half(),p=1)[0]
        dedup_label = (diff==0).long()
        dedup_mark = dedup_label.sum(dim=-1)
    if dedup_mark.min() > 1 or dedup_mark.max() < 1:
        return 0
    dedup_logits = logits[dedup_mark==1]
    dedup_labels = labels[dedup_mark==1]
    return F.cross_entropy(dedup_logits, dedup_labels)
    

class ClipLoss(nn.Module):
    def __init__(
            self,
            local_loss=False,
            gather_with_grad=False,
            cache_labels=False,
            rank=0,
            world_size=1,
            use_horovod=False,
            opts=None,
    ):
        super().__init__()
        self.local_loss = local_loss
        self.gather_with_grad = gather_with_grad
        self.cache_labels = cache_labels
        self.rank = rank
        self.world_size = world_size
        self.use_horovod = use_horovod

        # cache state
        self.prev_num_logits = 0
        self.labels = {}

    def forward(self, image_features, text_features, logit_scale):
        device = image_features.device
        all_image_features, all_text_features = self.forward_feature(image_features,text_features)

        logits_per_image = logit_scale * image_features @ all_text_features.T
        logits_per_text = logit_scale * text_features @ all_image_features.T

        # calculated ground-truth and cache if enabled
        num_logits = logits_per_image.shape[0]
        labels = torch.arange(num_logits, device=device, dtype=torch.long)
        if self.world_size > 1:
            labels = labels + num_logits * self.rank
        
        total_loss = (
            F.cross_entropy(logits_per_image, labels) +
            F.cross_entropy(logits_per_text, labels)
        ) / 2
        return total_loss
    
    def forward_feature(self, image_features, text_features):
        if self.world_size > 1:
            all_image_features, all_text_features = gather_features(
                image_features, text_features,
                self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)
        else:
            all_image_features = image_features
            all_text_features = text_features
        
        return all_image_features, all_text_features


class ClipDeDupLoss(ClipLoss):
    def __init__(
            self,
            local_loss=False,
            gather_with_grad=False,
            cache_labels=False,
            rank=0,
            world_size=1,
            use_horovod=False,
            opts=None
    ):
        super(ClipDeDupLoss, self).__init__(local_loss,gather_with_grad,cache_labels,rank,world_size,use_horovod,opts)  
    
    def forward(self, image_features, text_features, logit_scale, text_token):
        device = image_features.device
        all_image_features, all_text_features = self.forward_feature(image_features,text_features)

        logits_per_image = logit_scale * image_features @ all_text_features.T
        logits_per_text = logit_scale * text_features @ all_image_features.T

        # calculated ground-truth and cache if enabled
        num_logits = logits_per_image.shape[0]
        labels = torch.arange(num_logits, device=device, dtype=torch.long)

        if self.world_size > 1:
            labels = labels + num_logits * self.rank
            all_text_token = torch.cat(torch.distributed.nn.all_gather(text_token), dim=0)
        else:
            all_text_token = text_token

        total_loss = (
            CrossEntropyLossDeDup(logits_per_image, labels, (text_token, all_text_token)) +
            F.cross_entropy(logits_per_text, labels)
            ) / 2
        return total_loss


class ClipSigmoidLoss(ClipLoss):
    def __init__(
            self,
            local_loss=False,
            gather_with_grad=False,
            cache_labels=False,
            rank=0,
            world_size=1,
            use_horovod=False,
            opts=None
    ):
        super(ClipSigmoidLoss, self).__init__(local_loss,gather_with_grad,cache_labels,rank,world_size,use_horovod,opts)  
    
    def forward(self, image_features, text_features, logit_scale, logit_bias):

        device = image_features.device
        all_image_features, _ = self.forward_feature(image_features,text_features)

        logits_per_text = logit_scale * text_features @ all_image_features.T + logit_bias
        
        # calculated ground-truth and cache if enabled
        num_logits = logits_per_text.shape[0]
        num_contrast = all_image_features.shape[0]
        labels_global = 2 * torch.eye(num_contrast) - torch.ones(num_contrast)

        labels_idx = torch.arange(num_logits, dtype=torch.long)
        if self.world_size > 1:
            labels_idx = labels_idx + num_logits * self.rank
        labels_local = labels_global[labels_idx].to(device=device)

        total_loss = -F.logsigmoid(logits_per_text * labels_local).sum(dim=-1).mean()
        return total_loss


class GroupClipLoss(ClipLoss):

    def __init__(
            self,
            local_loss=False,
            gather_with_grad=False,
            cache_labels=False,
            rank=0,
            world_size=1,
            use_horovod=False,
            opts=None
    ):
        super(GroupClipLoss, self).__init__(local_loss,gather_with_grad,cache_labels,rank,world_size,use_horovod,opts)
        self.num_clusters = int(opts.cluster_key[1:].split('B')[0])
        self.entr_temp = 15.0 if self.num_clusters < 128 else 18.0
        self.weight_temp = opts.dataset_arg[1]['wgt_temp'] if hasattr(opts,'dataset_arg') and len(opts.dataset_arg) == 2 and 'wgt_temp' in opts.dataset_arg[1] else 1.0            

    def forward(self, image_features, text_features, logit_scale, add_arg):

        device = image_features.device
        all_image_features, all_text_features = self.forward_feature(image_features,text_features)
        prob = F.softmax(add_arg['soft'] * (self.weight_temp ** 2), dim=-1)
        weight = 1.0 - torch.special.entr(prob).sum(dim=-1) / torch.log(torch.tensor(self.num_clusters).to(device=device))

        logits_per_image = logit_scale * image_features @ all_text_features.T
        logits_per_text = logit_scale * text_features @ all_image_features.T
        
        # calculated ground-truth and cache if enabled
        num_logits = logits_per_image.shape[0]
        labels_vis = torch.arange(num_logits, device=device, dtype=torch.long)
        if self.world_size > 1 and not self.local_loss:
            labels_vis = (labels_vis + num_logits * self.rank).long()
        labels_txt = labels_vis

        all_weight = torch.cat(torch.distributed.nn.all_gather(weight), dim=0) if self.world_size > 1 else weight
        weight = weight / all_weight.sum() * len(all_image_features)
        total_loss = torch.stack([
            F.cross_entropy(logits_per_image, labels_vis, reduction='none'),
            F.cross_entropy(logits_per_text, labels_txt, reduction='none'),
        ],dim=0)
        total_loss = total_loss * weight[None]
        return total_loss.mean()
        

class DomainClipLoss(ClipLoss):

    def __init__(
            self,
            local_loss=False,
            gather_with_grad=False,
            cache_labels=False,
            rank=0,
            world_size=1,
            use_horovod=False,
            opts=None
    ):
        super(DomainClipLoss, self).__init__(local_loss,gather_with_grad,cache_labels,rank,world_size,use_horovod,opts)
        self.domain_cross = opts.domain_cross
        self.num_clusters = int(opts.cluster_key[1:].split('B')[0])
        self.entr_temp = 15.0 if self.num_clusters < 128 else 18.0
        self.filter_ref = opts.dataset_arg[1]['filter']

    def forward(self, image_features, text_features, logit_scale, add_arg):
        device = image_features.device
        all_image_features, all_text_features = self.forward_feature(image_features,text_features)
        assign_hard = add_arg['hard']
        assign_soft = add_arg['soft'][F.one_hot(assign_hard,num_classes=self.num_clusters)==1]
        entropy = torch.special.entr(F.softmax(add_arg['soft']*self.entr_temp, dim=-1)).sum(dim=-1) / torch.log(torch.tensor(self.num_clusters)).to(device=device)
        assign_hard[entropy > self.filter_ref] = -1

        logits_per_image = logit_scale * image_features @ all_text_features.T
        logits_per_text = logit_scale * text_features @ all_image_features.T
        
        # calculated ground-truth and cache if enabled
        num_logits = logits_per_image.shape[0]
        labels_vis = torch.arange(num_logits, device=device, dtype=torch.long)
        if self.world_size > 1 and not self.local_loss:
            labels_vis = (labels_vis + num_logits * self.rank).long()
        labels_txt = labels_vis

        if self.world_size > 1:
            all_assign_hard = torch.cat(torch.distributed.nn.all_gather(assign_hard), dim=0)
            all_assign_soft = torch.cat(torch.distributed.nn.all_gather(assign_soft), dim=0)
        else:
            all_assign_hard = assign_hard.clone()
            all_assign_soft = assign_soft
        
        all_assign_hard[all_assign_hard==-1] = -2
        domain_label = assign_hard.view(-1,1) == all_assign_hard[None].float()
        domain_label = domain_label * (assign_soft.view(-1,1) * all_assign_soft[None])
        
        if self.domain_cross == 'n':
            total_loss = (F.cross_entropy(logits_per_image, labels_vis) + F.cross_entropy(logits_per_text, labels_txt)) / 2.0
            txt_loss = self.forward_inner_domain(text_features @ all_text_features.T, domain_label, labels_txt, logit_scale)
            total_loss += txt_loss
        else:
            vis_loss = self.forward_cross_domain(logits_per_image, domain_label, labels_vis, 'v' in self.domain_cross)
            txt_loss = self.forward_cross_domain(logits_per_text, domain_label, labels_txt, 't' in self.domain_cross)
            total_loss = (txt_loss + vis_loss) / 2.0
        
        return total_loss
    
    def forward_cross_domain(self, logits, domain_label, match_label, joint=False):
        contrast_count = logits.size(-1)
        label = F.one_hot(match_label,num_classes=contrast_count).half()
        if joint:
            label += domain_label
        return -((F.log_softmax(logits,dim=-1) * label).sum(dim=-1)/label.sum(dim=-1)).mean()

    def forward_inner_domain(self, logits, domain_label, match_label, temp):
        contrast_count = logits.size(-1)
        logits_mask = 1.0-F.one_hot(match_label,num_classes=contrast_count).half()
        
        logits_max, _ = torch.max(logits, dim=1, keepdim=True)
        logits = logits - logits_max.detach()

        logits = logits * temp.log()
        exp_logits = torch.exp(logits) * logits_mask
        log_prob = logits - torch.log(exp_logits.sum(1, keepdim=True))

        pos_index = domain_label.sum(1) > 0.01 # torch.log(temp) * 0.07*
        # compute mean of log-likelihood over positive
        mean_log_prob_pos = (domain_label[pos_index] * log_prob[pos_index]).sum(1) / domain_label[pos_index].sum(1)
        return -mean_log_prob_pos.mean() * 0.3


class AsymmCLIPLoss(ClipLoss):

    def __init__(
            self,
            local_loss=False,
            gather_with_grad=False,
            cache_labels=False,
            rank=0,
            world_size=1,
            use_horovod=False,
            opts=None
    ):
        super(AsymmCLIPLoss, self).__init__(local_loss,gather_with_grad,cache_labels,rank,world_size,use_horovod,opts)
        self.mode = opts.asymm
        self.scale = opts.store_scale if hasattr(opts, 'store_scale') else 0

    def forward(self, image_features, text_features, logit_scale, image_asymm, text_asymm):
        device = image_features.device
        all_image_features, all_text_features = self.forward_feature(image_features, text_features)

        if image_asymm is None and text_asymm is None:
            all_image_asymm, all_text_asymm = None, None
        else:
            all_image_asymm, all_text_asymm = self.forward_feature(image_asymm, text_asymm)
        contrast_text = torch.cat([all_text_features,all_text_asymm],dim=0) if 't' in self.mode and all_text_asymm is not None else all_text_features
        contrast_image = torch.cat([all_image_features,all_image_asymm],dim=0) if 'v' in self.mode and all_image_asymm is not None else all_image_features
        
        logits_per_image = logit_scale * image_features @ contrast_text.T
        logits_per_text = logit_scale * text_features @ contrast_image.T
        # print(logits_per_image.shape, logits_per_text.shape)
        # calculated ground-truth and cache if enabled
        num_logits = logits_per_image.shape[0]
        labels_vis = torch.arange(num_logits, device=device, dtype=torch.long)
        if self.world_size > 1 and not self.local_loss:
            labels_vis = (labels_vis + num_logits * self.rank).long()
        labels_txt = labels_vis
        
        total_loss = (
            F.cross_entropy(logits_per_image, labels_vis) +
            F.cross_entropy(logits_per_text, labels_txt)
            ) / 2
        return total_loss
    
    # def forward(self, image_features, text_features, logit_scale, cluster_logits, soft_label):
    #     device = image_features.device
    #     all_image_features, all_text_features = self.forward_feature(image_features, text_features)

    #     logits_per_image = logit_scale * image_features @ all_text_features.T
    #     logits_per_text = logit_scale * text_features @ all_image_features.T

    #     # calculated ground-truth and cache if enabled
    #     num_logits = logits_per_image.shape[0]
    #     labels_vis = torch.arange(num_logits, device=device, dtype=torch.long)
    #     if self.world_size > 1 and not self.local_loss:
    #         labels_vis = (labels_vis + num_logits * self.rank).long()
    #     labels_txt = labels_vis
    #     soft_label = F.softmax(self.temp * soft_label, dim=-1)

    #     matching_loss = (F.cross_entropy(logits_per_image, labels_vis) + F.cross_entropy(logits_per_text, labels_txt)) / 2.0
    #     cluster_loss = (
    #         self.kldiv(F.log_softmax(logit_scale * cluster_logits['tc'], dim=-1), soft_label) + 
    #         self.kldiv(F.log_softmax(cluster_logits['vc'] @ F.softmax(cluster_logits['vt'] * logit_scale, dim=0), dim=-1), soft_label)
    #     )
    #     return matching_loss + cluster_loss * 0.5



class MoCoClipLoss(ClipLoss):

    def __init__(
            self,
            local_loss=False,
            gather_with_grad=False,
            cache_labels=False,
            rank=0,
            world_size=1,
            use_horovod=False,
            opts=None
    ):
        super(MoCoClipLoss, self).__init__(local_loss,gather_with_grad,cache_labels,rank,world_size,use_horovod,opts)      
        self.scale = opts.store_scale

    def forward(self, image_features, text_features, logit_scale, image_prevfeat, text_prevfeat):

        device = image_features.device
        all_image_features, all_text_features = self.forward_feature(image_features,text_features)

        logits_per_image = logit_scale * image_features @ all_text_features.T
        logits_per_text = logit_scale * text_features @ all_image_features.T
        
        # calculated ground-truth and cache if enabled
        num_logits = logits_per_image.shape[0]
        labels_vis = torch.arange(num_logits, device=device, dtype=torch.long)
        if self.world_size > 1 and not self.local_loss:
            labels_vis = (labels_vis + num_logits * self.rank).long()
        labels_txt = labels_vis

        align_loss = (
            F.cross_entropy(logits_per_image, labels_vis) +
            F.cross_entropy(logits_per_text, labels_txt)
        ) / 2

        if image_prevfeat is None or text_prevfeat is None:
            total_loss = align_loss
        else:
            all_image_prevfeat, all_text_prevfeat = self.forward_feature(image_prevfeat,text_prevfeat)
            logits_contrast_image = logit_scale * image_features @ torch.cat([all_text_features.detach(),all_text_prevfeat],dim=0).T
            logits_contrast_text = logit_scale * text_features @ torch.cat([all_image_features.detach(),all_image_prevfeat],dim=0).T
            contrast_loss = (
                F.cross_entropy(logits_contrast_image, labels_vis) +
                F.cross_entropy(logits_contrast_text, labels_txt)
            ) / 2
            total_loss = align_loss + 0.5 * contrast_loss
        return total_loss



class SoftClipLoss(ClipLoss):

    def __init__(
            self,
            local_loss=False,
            gather_with_grad=False,
            cache_labels=False,
            rank=0,
            world_size=1,
            use_horovod=False,
            opts=None
    ):
        super(SoftClipLoss, self).__init__(local_loss,gather_with_grad,cache_labels,rank,world_size,use_horovod,opts)
        self.cluster_id = opts.cluster_id if hasattr(opts,'cluster_id') else None
        self.temp = opts.soft_param['temp']
        self.in_group_replace = opts.soft_param['replace'] == 1 and self.cluster_id is not None
        self.entr_normalizer = torch.log(torch.tensor(int(opts.cluster_key.split('B')[0][1:])))
        self.entr_temp = torch.tensor(15.0) if self.entr_normalizer < 2.71 else torch.tensor(18.0)
        
    def forward(self, image_features, text_features, logit_scale,  assign_hard, similarity):
        device = image_features.device
        global_idx_device, all_image_features, all_text_features = self.forward_feature(image_features, text_features, None)

        logits_per_image = logit_scale * image_features @ all_text_features.T
        logits_per_text = logit_scale * text_features @ all_image_features.T
        
        # calculated ground-truth and cache if enabled
        num_logits = logits_per_image.shape[0]
        labels_vis = torch.arange(num_logits, device=device, dtype=torch.long)
        if self.world_size > 1:
            labels_vis = (labels_vis + num_logits * self.rank).long()
            all_assign_hard = torch.cat(torch.distributed.nn.all_gather(assign_hard), dim=0)
            all_similarity = torch.cat(torch.distributed.nn.all_gather(similarity), dim=0)
        else:
            all_assign_hard = assign_hard.clone()
            all_similarity = similarity.clone()
        labels_txt = labels_vis
        
        all_weight = 1.0-torch.special.entr(F.softmax(self.entr_temp * all_similarity, dim=-1)).sum(dim=-1) / self.entr_normalizer 
        if self.in_group_replace:
            all_weight[all_assign_hard==self.cluster_id] = 1.0
        all_weight = F.softmax(all_weight/self.temp,dim=-1) * len(all_image_features)
        weight = all_weight[labels_vis]
        # print(all_weight.min().item(),all_weight.max().item(),weight.min(),weight.max())
        
        total_loss = torch.stack([
            F.cross_entropy(logits_per_image, labels_vis, reduction='none'),
            F.cross_entropy(logits_per_text, labels_txt, reduction='none'),
        ],dim=0)
        total_loss = total_loss * weight[None]
        return total_loss.mean()



# class PartialClipLoss(ClipLoss):

#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#             opts=None
#     ):
#         super(PartialClipLoss, self).__init__(local_loss,gather_with_grad,cache_labels,rank,world_size,use_horovod,opts)  
#         self.num_groups = opts.num_groups
#         self.mark = opts.rerun if hasattr(opts,'rerun') else 0

#     def forward(self, image_features, text_features, logit_scale):

#         device = image_features.device
#         all_image_features, all_text_features = self.forward_feature(image_features,text_features)
#         group = self.rank * torch.ones_like(image_features[:,0]) % self.num_groups

#         all_group = torch.cat(torch.distributed.nn.all_gather(group), dim=0)
#         contrast_text = all_text_features[all_group==group[0]]
#         contrast_image = all_image_features # [all_group==group[0]]

#         logits_per_image = logit_scale * image_features @ contrast_text.T
#         logits_per_text = logit_scale * text_features @ contrast_image.T
        
#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         labels_vis = torch.arange(num_logits, device=device, dtype=torch.long)
#         labels_txt = torch.arange(num_logits, device=device, dtype=torch.long)
#         local_rank = self.rank // self.num_groups
#         if self.world_size > 1 and not self.local_loss:
#             labels_vis = (labels_vis + num_logits * local_rank).long()
#             labels_txt = (labels_txt + num_logits * self.rank).long()
#         else:
#             labels_txt = labels_vis

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels_vis) * (1.5 if self.mark > 0 else 1) + 
#             F.cross_entropy(logits_per_text, labels_txt)
#         ) / 2
#         return total_loss



# class RouteClipLoss(ClipLoss):

#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#             opts=None
#     ):
#         super(RouteClipLoss,self).__init__(local_loss, gather_with_grad, cache_labels, rank, world_size, use_horovod, opts)

#     def forward(self, image_features, text_features, logit_scale, gpu_idx):
#         device = image_features.device
#         global_idx_device, all_image_features, all_text_features = self.forward_feature(image_features, text_features, gpu_idx)

#         logits_per_image = logit_scale * image_features @ all_text_features.T
#         logits_per_text = logit_scale * text_features @ all_image_features.T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         labels_vis = torch.arange(num_logits, device=device, dtype=torch.long)
#         if self.world_size > 1:
#             labels_vis = (labels_vis + num_logits * self.rank).long()
#         labels_txt = labels_vis if global_idx_device is None else global_idx_device

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels_vis) +
#             F.cross_entropy(logits_per_text, labels_txt)
#             ) / 2
#         return total_loss
    
#     def forward_feature(self, image_features, text_features, gpu_idx=None):
#         if gpu_idx is None: # No data routing is applied
#             global_idx_device = None
#         else:
#             global_idx_device = gpu_idx[:,0] + gpu_idx[:,1] * image_features.shape[0]
        
#         # print('Rank {} {}'.format(self.rank, gpu_idx))
#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)
#             ''' until now, 
#             all_gpu_index and all_text_features are aligned mixed order, 
#             all_image_features are in the right order
#             '''
#             if gpu_idx is not None:
#                 all_gpu_index = torch.cat(torch.distributed.nn.all_gather(gpu_idx), dim=0)
#                 all_text_features = order_recovery(all_text_features, all_gpu_index, image_features.size(0), self.local_loss, self.rank)
#             ''' all_image_features and all_text_features are aligned with right order'''
#         else:
#             all_image_features = image_features
#             all_text_features = text_features
        
#         return global_idx_device, all_image_features, all_text_features
        




# class UniAlignLoss(ClipLoss):
#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#             opts=None
#     ):
#         super(UniAlignLoss,self).__init__(local_loss, gather_with_grad, cache_labels, rank, world_size, use_horovod, opts)
#         self.uni_weight = opts.uni_weight if hasattr(opts, 'uni_weight') else 0.5
#         self.align_weight = opts.align_weight if hasattr(opts, 'align_weight') else 0.5
#         self.t = 2.0
    
#     def forward_regularization(self, image_features, text_features, labels, logit_scale):
#         assert isinstance(text_features,tuple)
#         dist = 2.0 - 2 * torch.mm(text_features[0],text_features[1].T)
#         global_batch_size = text_features[1].size(0)
#         uni_loss = dist[F.one_hot(labels,global_batch_size)==0].mul(-self.t).exp().mean().log()
#         # print(dist.shape, uni_loss, image_features[0].requires_grad,image_features[1].requires_grad, text_features[0].requires_grad, text_features[1].requires_grad)
#         return self.uni_weight * uni_loss
#     # Reference
#     # def align_loss(self, x, y, alpha=2):
#     #     return (x - y).norm(p=2, dim=1).pow(alpha).mean()
#     # def uniform_loss(self, x, t=2):
#     #     return torch.pdist(x, p=2).pow(2).mul(-t).exp().mean().log()

# class MixUpClipLoss(ClipLoss):

#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#             opts=None
#     ):
#         super(MixUpClipLoss, self).__init__(local_loss,gather_with_grad,cache_labels,rank,world_size,use_horovod,opts)
#         self.mixup_detach = opts.mixup_detach
#         self.temp = opts.soft_param['temp']
#         self.ref = 1.0-abs(opts.soft_cluster[1])

#     def forward(self, image_features, text_features, logit_scale, assign_hard, similarity):
#         device = image_features.device
#         global_idx_device, all_image_features, all_text_features = self.forward_feature(image_features, text_features, None)
#         d2c_prob = F.softmax(similarity/self.temp,dim=-1)
#         d2c_entropy = torch.special.entr(d2c_prob).sum(dim=-1) / torch.log(torch.tensor(similarity.size(-1))).to(device=device)
#         ensemble_weight = 0.25+0.5*torch.rand(image_features.size(0)).to(device=device).unsqueeze(1)

#         if self.world_size > 1:
#             all_assign_hard = torch.cat(torch.distributed.nn.all_gather(assign_hard), dim=0)
#             all_similarity = torch.cat(torch.distributed.nn.all_gather(similarity), dim=0)
#             all_entropy = torch.cat(torch.distributed.nn.all_gather(d2c_entropy), dim=0) 
#             all_ensemble_weight = torch.cat(torch.distributed.nn.all_gather(ensemble_weight), dim=0) 
#         else:
#             all_assign_hard = assign_hard.clone()
#             all_similarity = similarity.clone()
#             all_entropy = d2c_entropy.clone()
#             all_ensemble_weight = ensemble_weight.clone()

#         hard_assign_onehot = F.one_hot(all_assign_hard,similarity.size(-1))
#         hard_assign_onehot[all_entropy > self.ref] = 0
#         all_similarity[hard_assign_onehot==0] = -1000.0
#         c2d_prob = F.softmax(all_similarity/self.temp,dim=0)
#         all_image_cluster = F.normalize(c2d_prob.T @ all_image_features,dim=-1)
#         all_text_cluster = F.normalize(c2d_prob.T @ all_text_features,dim=-1)

#         if self.mixup_detach > 0:
#             all_image_cluster = all_image_cluster.detach()
#             all_text_cluster = all_text_cluster.detach()
        
#         inst_wise_image_center = all_image_cluster[all_assign_hard]
#         inst_wise_text_center = all_text_cluster[all_assign_hard]

#         fake_image = inst_wise_image_center * all_ensemble_weight + (1.0-all_ensemble_weight) * all_image_features
#         fake_text = inst_wise_text_center * all_ensemble_weight + (1.0-all_ensemble_weight) * all_text_features
#         fake_image,fake_text = F.normalize(fake_image,dim=-1),F.normalize(fake_text,dim=-1)

#         if self.mixup_detach == 2:
#             fake_image = fake_image.detach()
#             fake_text = fake_text.detach()

#         logits_per_image = logit_scale * image_features @ torch.cat([all_text_features,fake_text]).T
#         logits_per_text = logit_scale * text_features @ torch.cat([all_image_features,fake_image]).T
        
#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         labels_vis = torch.arange(num_logits, device=device, dtype=torch.long)
        
#         if self.world_size > 1:
#             labels_vis = (labels_vis + num_logits * self.rank).long()
#         # same_cluster = torch.eq(all_assign_hard.view(-1,1),all_assign_hard[None])
#         # if self.cluster_id is not None:
#         #     belong_to = (all_assign_hard == self.cluster_id).bool()
#         #     belong_to = belong_to.view(-1,1) * belong_to[None]
#         #     same_cluster = same_cluster * belong_to
#         # edge_case = all_entropy > self.ref
#         # if edge_case.sum() > 0:
#         #     same_cluster[edge_case,:] = 0
#         #     same_cluster[:,edge_case] = 0
#         labels_txt = labels_vis
#         total_loss = (F.cross_entropy(logits_per_image, labels_vis) + F.cross_entropy(logits_per_text, labels_txt)) / 2.0
#         return total_loss

# class HeteroCLIPLoss(ClipLoss):

#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#             opts=None
#     ):
#         super(HeteroCLIPLoss,self).__init__(local_loss, gather_with_grad, cache_labels, rank, world_size, use_horovod, opts)
#         self.schedule = opts.hetero_schedule
#         self.uni_weight = opts.uni_weight if hasattr(opts, 'uni_weight') else 0.5
#         self.align_weight = opts.align_weight if hasattr(opts, 'align_weight') else 0.5
#         self.clip_weight = 1.0 - (self.uni_weight + self.align_weight) / 2.0
#         # self.global_uni_weight = opts.local_uni_weight if hasattr(opts, 'global_uni_weight') else 0.0

#     def forward(self, image_features, text_features, logit_scale, gpu_idx=None):
#         device = image_features.device
#         global_idx_device, all_image_features, all_text_features = self.forward_feature(image_features, text_features, gpu_idx)

#         logits_per_image = logit_scale * image_features @ all_text_features.T
#         logits_per_text = logit_scale * text_features @ all_image_features.T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         labels_vis = torch.arange(num_logits, device=device, dtype=torch.long)
#         if self.world_size > 1:
#             if self.local_loss:
#                 labels_txt = labels_vis
#             else:
#                 labels_vis = (labels_vis + num_logits * self.rank).long()
#                 labels_txt = labels_vis if gpu_idx is None else global_idx_device.long()

#         clip_loss = (F.cross_entropy(logits_per_image, labels_vis) + F.cross_entropy(logits_per_text, labels_txt)) / 2
#         if self.rank in self.schedule['vis'] and not self.rank in self.schedule['txt']:
#             align_loss = self.align_loss(image_features,all_text_features[labels_vis])
#             uniform_loss = self.uniform_loss(image_features)
#         elif self.rank in self.schedule['txt'] and not self.rank in self.schedule['vis']:
#             align_loss = self.align_loss(text_features,all_image_features[labels_txt])
#             uniform_loss = self.uniform_loss(text_features)
#         elif self.rank in self.schedule['txt'] and self.rank in self.schedule['vis']:
#             align_loss = (
#                 self.align_loss(image_features,all_text_features[labels_vis]) + 
#                 self.align_loss(text_features,all_image_features[labels_txt])
#             ) / 2
#             uniform_loss = (self.uniform_loss(text_features) + self.uniform_loss(image_features)) / 2.0
#         else:
#             align_loss = uniform_loss = 0.0
#         total_loss = self.clip_weight * clip_loss + (self.uni_weight * uniform_loss + self.align_weight * align_loss) / 2

#         return total_loss
    
#     def align_loss(self, x, y, alpha=2):
#         return (x - y).norm(p=2, dim=1).pow(alpha).mean()

#     def uniform_loss(self, x, t=2):
#         return torch.pdist(x, p=2).pow(2).mul(-t).exp().mean().log()


# class MTClipLoss(nn.Module):

#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def forward(self, image_features, text_features, logit_scale):
#         device = image_features.device
#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)

#             if self.local_loss:
#                 logits_per_image = logit_scale * image_features[:, 0, :] @ all_text_features[:, 0, :].T
#                 logits_per_text = logit_scale * text_features[:, 1, :] @ all_image_features[:, 1, :].T
#             else:
#                 logits_per_image = logit_scale * all_image_features[:, 0, :] @ all_text_features[:, 0, :].T
#                 logits_per_text = logit_scale * all_text_features[:, 1, :] @ all_image_features[:, 1, :].T
#                 # logits_per_text = logits_per_image.T
#         else:
#             logits_per_image = logit_scale * image_features[:, 0, :] @ text_features[:, 0, :].T
#             logits_per_text = logit_scale * text_features[:, 1, :] @ image_features[:, 1, :].T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


# class WeightedSumClipLoss(nn.Module):
#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#             target_ratio=0.25,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         self.target_ratio = target_ratio
#         self.mask_selectors = []

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def update(self):
#         self.mask_selectors = []
#         return True  # update every step seems better.
#         """
#         if len(self.mask_selectors) > 0:
#             mask_selectors = torch.cat(self.mask_selectors, dim=0)
#             if mask_selectors.sum() >= self.mask_selectors[0].size(0):
#                 self.mask_selectors = []
#                 return True
#         return False"""


#     def forward(self, image_features, text_features, logit_scale):
#         device = image_features.device
#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)
#         else:
#             all_image_features, all_text_features = image_features, text_features
    
#         if not torch.isfinite(all_image_features).all():
#             print("all_image_features has nan/inf")

#         if not torch.isfinite(all_text_features).all():
#             print("all_text_features has nan/inf")

#         if self.local_loss:
#             with torch.no_grad():  # estimate cosine.
#                 sim = torch.bmm(image_features[:, None, :], text_features[:, :, None]).view(-1)
#                 probs = torch.nn.functional.softmax(logit_scale * sim, dim=-1)

#                 if not torch.isfinite(probs).all():
#                     print(f"probs contains Nan/Inf in Samplingloss.")
#                     print(probs)
#                     probs = torch.nan_to_num(probs, nan=0.0, posinf=0.0, neginf=0.0)

#             logits_per_image = logit_scale * image_features @ all_text_features.T
#             logits_per_text = logit_scale * text_features @ all_image_features.T
#         else:
#             with torch.no_grad():  # estimate cosine.
#                 sim = torch.bmm(all_image_features[:, None, :], all_text_features[:, :, None]).view(-1)
#                 probs = torch.nn.functional.softmax(logit_scale * sim, dim=-1)

#                 if not torch.isfinite(probs).all():
#                     print(f"probs contains Nan/Inf in Samplingloss.")
#                     print(probs)
#                     probs = torch.nan_to_num(probs, nan=0.0, posinf=0.0, neginf=0.0)

#                 # batch_size = image_features.size(0)
#                 # sim = sim.cpu()
#                 # self.local_sim = sim[batch_size * self.rank : batch_size * (self.rank + 1)]
#             logits_per_image = logit_scale * all_image_features @ all_text_features.T
#             logits_per_text = logit_scale * all_text_features @ all_image_features.T

#         # calculated ground-truth and cache if enabled
#         num_logits = all_image_features.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             probs @ F.cross_entropy(logits_per_image, labels, reduction="none") +
#             probs @ F.cross_entropy(logits_per_text, labels, reduction="none")
#             ) / 2.
#         return total_loss


# class VQHardClipLoss(nn.Module):
#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#             target_ratio=0.25,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def update(self):  # TODO: check train.py and see if can remove.
#         return True

#     def forward(self, image_features, text_features, codebook, logit_scale):
#         device = image_features.device
#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)
#         else:
#             all_image_features, all_text_features = image_features, text_features
    
#         if not torch.isfinite(all_image_features).all():
#             print("all_image_features has nan/inf")

#         if not torch.isfinite(all_text_features).all():
#             print("all_text_features has nan/inf")

#         if self.local_loss:
#             logits_per_image = logit_scale * image_features @ codebook
#             logits_per_text = logit_scale * text_features @ codebook
#         else:
#             logits_per_image = logit_scale * all_image_features @ codebook
#             logits_per_text = logit_scale * all_text_features @ codebook

#         with torch.no_grad():  # estimate cosine.
#             image_labels = logits_per_text.argmax(dim=-1)
#             text_labels = logits_per_image.argmax(dim=-1)

#         total_loss = (
#             F.cross_entropy(logits_per_image, image_labels) +
#             F.cross_entropy(logits_per_text, text_labels)
#         ) / 2.
#         return total_loss


# ################################# VQ losses #################################

# class VQContraClipLoss(nn.Module):
#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#             target_ratio=0.25,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def update(self):  # TODO: check train.py and see if can remove.
#         return True

#     def forward(self, image_features, text_features, codebook, logit_scale):
#         device = image_features.device
#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)
#         else:
#             all_image_features, all_text_features = image_features, text_features

#         if not torch.isfinite(all_image_features).all():
#             print("all_image_features has nan/inf")

#         if not torch.isfinite(all_text_features).all():
#             print("all_text_features has nan/inf")
#         """ # this doesn't work.
#         all_image_logits = logit_scale * all_image_features @ codebook
#         all_text_logits = logit_scale * all_text_features @ codebook

#         if self.local_loss:
#             batch_size = image_features.size(0)
#             image_logits = all_image_logits[batch_size * self.rank : batch_size * (self.rank + 1)]
#             text_logits = all_text_logits[batch_size * self.rank : batch_size * (self.rank + 1)]
#             logits_per_image = image_logits @ all_text_logits.T
#             logits_per_text = text_logits @ all_image_logits.T
#         else:
#             logits_per_image = all_image_logits @ all_text_logits.T
#             logits_per_text = logits_per_image.T"""

#         all_image_logits = all_image_features @ codebook  # cosine
#         all_text_logits = all_text_features @ codebook

#         if self.local_loss:
#             batch_size = image_features.size(0)
#             image_logits = all_image_logits[batch_size * self.rank : batch_size * (self.rank + 1)]
#             text_logits = all_text_logits[batch_size * self.rank : batch_size * (self.rank + 1)]
#             logits_per_image = logit_scale * image_logits @ all_text_logits.T
#             logits_per_text = logit_scale * text_logits @ all_image_logits.T
#         else:
#             logits_per_image = logit_scale * all_image_logits @ all_text_logits.T
#             logits_per_text = logits_per_image.T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


# class VQCosineContraClipLoss(nn.Module):
#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#             target_ratio=0.25,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def update(self):  # TODO: check train.py and see if can remove.
#         return True

#     def forward(self, image_features, text_features, codebook, logit_scale):
#         device = image_features.device
#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)
#         else:
#             all_image_features, all_text_features = image_features, text_features

#         if not torch.isfinite(all_image_features).all():
#             print("all_image_features has nan/inf")

#         if not torch.isfinite(all_text_features).all():
#             print("all_text_features has nan/inf")

#         all_image_logits = F.normalize(all_image_features @ codebook, dim=-1)  # no logit_scale inside.
#         all_text_logits = F.normalize(all_text_features @ codebook, dim=-1)

#         if self.local_loss:
#             batch_size = image_features.size(0)
#             image_logits = all_image_logits[batch_size * self.rank : batch_size * (self.rank + 1)]
#             text_logits = all_text_logits[batch_size * self.rank : batch_size * (self.rank + 1)]
#             logits_per_image = logit_scale * image_logits @ all_text_logits.T
#             logits_per_text = logit_scale * text_logits @ all_image_logits.T
#         else:
#             logits_per_image = logit_scale * all_image_logits @ all_text_logits.T
#             logits_per_text = logits_per_image.T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


# class VQLinearCosine2ContraClipLoss(nn.Module):
#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#             target_ratio=0.25,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def update(self):  # TODO: check train.py and see if can remove.
#         return True

#     def forward(self, image_features, text_features, codebook, logit_scale):
#         device = image_features.device
#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)
#         else:
#             all_image_features, all_text_features = image_features, text_features

#         if not torch.isfinite(all_image_features).all():
#             print("all_image_features has nan/inf")

#         if not torch.isfinite(all_text_features).all():
#             print("all_text_features has nan/inf")

#         all_image_logits = F.normalize(codebook(all_image_features), dim=-1)  # no logit_scale inside.
#         all_text_logits = F.normalize(codebook(all_text_features), dim=-1)

#         if self.local_loss:
#             batch_size = image_features.size(0)
#             image_logits = all_image_logits[batch_size * self.rank : batch_size * (self.rank + 1)]
#             text_logits = all_text_logits[batch_size * self.rank : batch_size * (self.rank + 1)]
#             logits_per_image = logit_scale * image_logits @ all_text_logits.T
#             logits_per_text = logit_scale * text_logits @ all_image_logits.T
#         else:
#             logits_per_image = logit_scale * all_image_logits @ all_text_logits.T
#             logits_per_text = logits_per_image.T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


# class VQAttnMSEClipLoss(nn.Module):
#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#             target_ratio=0.25,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def update(self):  # TODO: check train.py and see if can remove.
#         return True

#     def forward(self, image_features, text_features, codebook, logit_scale):
#         device = image_features.device
#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)
#         else:
#             all_image_features, all_text_features = image_features, text_features

#         if not torch.isfinite(all_image_features).all():
#             print("all_image_features has nan/inf")

#         if not torch.isfinite(all_text_features).all():
#             print("all_text_features has nan/inf")

#         if self.local_loss:
#             attn_per_image = F.softmax(logit_scale * image_features @ codebook, dim=-1)
#             attn_per_text = F.softmax(logit_scale * text_features @ codebook, dim=-1)

#             image_features = F.normalize(attn_per_image @ codebook.t(), dim=-1)
#             text_features = F.normalize(attn_per_text @ codebook.t(), dim=-1)
#         else:
#             attn_per_image = F.softmax(logit_scale * all_image_features @ codebook, dim=-1)
#             attn_per_text = F.softmax(logit_scale * all_text_features @ codebook, dim=-1)
#             image_features = F.normalize(attn_per_image @ codebook.t(), dim=-1)
#             text_features = F.normalize(attn_per_text @ codebook.t(), dim=-1)

#         total_loss = F.mse_loss(image_features, text_features)

#         return total_loss


# class VQAttnContraClipLoss(nn.Module):
#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#             target_ratio=0.25,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def update(self):  # TODO: check train.py and see if can remove.
#         return True

#     def forward(self, image_features, text_features, codebook, logit_scale):
#         device = image_features.device
#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)
#         else:
#             all_image_features, all_text_features = image_features, text_features

#         if not torch.isfinite(all_image_features).all():
#             print("all_image_features has nan/inf")

#         if not torch.isfinite(all_text_features).all():
#             print("all_text_features has nan/inf")

#         if self.local_loss:
#             attn_per_image = F.softmax(logit_scale * all_image_features @ codebook, dim=-1)
#             attn_per_text = F.softmax(logit_scale * all_text_features @ codebook, dim=-1)

#             all_image_features = F.normalize(attn_per_image @ codebook.t(), dim=-1)
#             all_text_features = F.normalize(attn_per_text @ codebook.t(), dim=-1)

#             batch_size = image_features.size(0)
#             image_features = all_image_features[batch_size * self.rank : batch_size * (self.rank + 1)]
#             text_features = all_text_features[batch_size * self.rank : batch_size * (self.rank + 1)]
#             logits_per_image = logit_scale * image_features @ all_text_features.T
#             logits_per_text = logit_scale * text_features @ all_image_features.T
#         else:
#             attn_per_image = F.softmax(logit_scale * all_image_features @ codebook, dim=-1)
#             attn_per_text = F.softmax(logit_scale * all_text_features @ codebook, dim=-1)
#             all_image_features = F.normalize(attn_per_image @ codebook.t(), dim=-1)
#             all_text_features = F.normalize(attn_per_text @ codebook.t(), dim=-1)

#             logits_per_image = logit_scale * all_image_features @ all_text_features.T
#             logits_per_text = logits_per_image.T


#         num_logits = logits_per_image.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


# ############## deprecated, not working
# class SamplingClipLoss(nn.Module):
#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#             target_ratio=0.25,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         self.target_ratio = target_ratio
#         self.mask_selectors = []

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def update(self):
#         self.mask_selectors = []
#         return True  # update every step seems better.
#         """
#         if len(self.mask_selectors) > 0:
#             mask_selectors = torch.cat(self.mask_selectors, dim=0)
#             if mask_selectors.sum() >= self.mask_selectors[0].size(0):
#                 self.mask_selectors = []
#                 return True
#         return False"""


#     def forward(self, image_features, text_features, logit_scale):
#         device = image_features.device
#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)
#         else:
#             all_image_features, all_text_features = image_features, text_features
#             # if self.local_loss:
#             #     logits_per_image = logit_scale * image_features @ all_text_features.T
#             #     logits_per_text = logit_scale * text_features @ all_image_features.T
#             # else:

#         if not torch.isfinite(all_image_features).all():
#             print("all_image_features has nan/inf")

#         if not torch.isfinite(all_text_features).all():
#             print("all_text_features has nan/inf")

#         with torch.no_grad():  # estimate cosine.
#             sim = torch.bmm(all_image_features[:, None, :], all_text_features[:, :, None]).view(-1)
#             probs = torch.nn.functional.softmax(logit_scale * sim, dim=-1)

#             if not torch.isfinite(probs).all():
#                 print(f"probs contains Nan/Inf in Samplingloss.")
#                 print(probs)
#                 probs = torch.nan_to_num(probs, nan=0.0, posinf=0.0, neginf=0.0)

#             index = torch.multinomial(probs, int(sim.size(0) * self.target_ratio))
#             # huxu: more sampling across GPUs should be more stable.
#             # if self.world_size > 1:
#             #    dist.broadcast(index, src=0)
#             mask_selector = torch.zeros(sim.size(0), dtype=torch.bool, device=sim.device)
#             mask_selector[index] = True

#             batch_size = image_features.size(0)
#             sim = sim.cpu()
#             self.local_sim = sim[batch_size * self.rank : batch_size * (self.rank + 1)]
#             self.min = float(sim.min())
#             self.max = float(sim.max())
#             mask_selector_cpu = mask_selector.cpu()
#             self.local_mask_selector = mask_selector_cpu[batch_size * self.rank : batch_size * (self.rank + 1)]  # for recording image_ids.
#             self.mask_selectors.append(mask_selector_cpu)  # accumulate mask_selector for effective batch updates.

#         logits_per_image = logit_scale * all_image_features[mask_selector] @ all_text_features.T
#         logits_per_text = logit_scale * all_text_features[mask_selector] @ all_image_features.T

#         # else:
#         #     logits_per_image = logit_scale * image_features @ text_features.T
#         #     logits_per_text = logit_scale * text_features @ image_features.T

#         # calculated ground-truth and cache if enabled
#         num_logits = all_image_features.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]
#         labels = labels[mask_selector]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


# class AltLoss(nn.Module):  # impl. of SimSiam

#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def forward(self, image_features, text_features, logit_scale):
#         device = image_features.device
#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)

#             if self.local_loss:
#                 logits_per_image = logit_scale * image_features.detach() @ all_text_features.T
#                 logits_per_text = logit_scale * text_features.detach() @ all_image_features.T
#             else:
#                 logits_per_image = logit_scale * all_image_features.detach() @ all_text_features.T
#                 logits_per_text = logit_scale * all_text_features.detach() @ all_image_features.T
#         else:
#             logits_per_image = logit_scale * image_features.detach() @ text_features.T
#             logits_per_text = logit_scale * text_features.detach() @ image_features.T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


# class SSLSumClipLoss(nn.Module):

#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def forward(self, image_features, text_features, logit_scale):
#         device = image_features.device
#         features = F.normalize(image_features + text_features, dim=-1)  # not normalized.
#         bsz = features.size(0) // 2
#         image_features = features[:bsz]  # huxu: abuse the variable name for consistent code, though it's MM feature now.
#         text_features = features[bsz:]  # huxu: abuse the variable name for consistent code, though it's MM feature now.

#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)

#             if self.local_loss:
#                 logits_per_image = logit_scale * image_features @ all_text_features.T
#                 logits_per_text = logit_scale * text_features @ all_image_features.T
#             else:
#                 logits_per_image = logit_scale * all_image_features @ all_text_features.T
#                 logits_per_text = logits_per_image.T
#         else:
#             logits_per_image = logit_scale * image_features @ text_features.T
#             logits_per_text = logit_scale * text_features @ image_features.T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


# class SSLSumMDropoutClipLoss(nn.Module):

#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def forward(self, image_features, text_features, logit_scale):
#         device = image_features.device
#         features = F.normalize(
#             torch.nn.functional.dropout(image_features, p=0.1) 
#             + torch.nn.functional.dropout(text_features, p=0.1), 
#             dim=-1)
#         bsz = features.size(0) // 2
#         image_features = features[:bsz]  # huxu: abuse the variable name for consistent code, though it's MM feature now.
#         text_features = features[bsz:]  # huxu: abuse the variable name for consistent code, though it's MM feature now.

#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)

#             if self.local_loss:
#                 logits_per_image = logit_scale * image_features @ all_text_features.T
#                 logits_per_text = logit_scale * text_features @ all_image_features.T
#             else:
#                 logits_per_image = logit_scale * all_image_features @ all_text_features.T
#                 logits_per_text = logits_per_image.T
#         else:
#             logits_per_image = logit_scale * image_features @ text_features.T
#             logits_per_text = logit_scale * text_features @ image_features.T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


# class SSLSumMDropout3ClipLoss(nn.Module):

#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def forward(self, image_features, text_features, logit_scale):
#         device = image_features.device
#         features = F.normalize(
#             torch.nn.functional.dropout(image_features, p=0.3) 
#             + torch.nn.functional.dropout(text_features, p=0.3), 
#             dim=-1)
#         bsz = features.size(0) // 2
#         image_features = features[:bsz]  # huxu: abuse the variable name for consistent code, though it's MM feature now.
#         text_features = features[bsz:]  # huxu: abuse the variable name for consistent code, though it's MM feature now.

#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)

#             if self.local_loss:
#                 logits_per_image = logit_scale * image_features @ all_text_features.T
#                 logits_per_text = logit_scale * text_features @ all_image_features.T
#             else:
#                 logits_per_image = logit_scale * all_image_features @ all_text_features.T
#                 logits_per_text = logits_per_image.T
#         else:
#             logits_per_image = logit_scale * image_features @ text_features.T
#             logits_per_text = logit_scale * text_features @ image_features.T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


# class SSLSumDropoutClipLoss(nn.Module):

#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def forward(self, image_features, text_features, logit_scale):
#         device = image_features.device
#         features = F.normalize(
#             torch.nn.functional.dropout(image_features + text_features, p=0.1),
#             dim=-1)
#         bsz = features.size(0) // 2
#         image_features = features[:bsz]  # huxu: abuse the variable name for consistent code, though it's MM feature now.
#         text_features = features[bsz:]  # huxu: abuse the variable name for consistent code, though it's MM feature now.

#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)

#             if self.local_loss:
#                 logits_per_image = logit_scale * image_features @ all_text_features.T
#                 logits_per_text = logit_scale * text_features @ all_image_features.T
#             else:
#                 logits_per_image = logit_scale * all_image_features @ all_text_features.T
#                 logits_per_text = logits_per_image.T
#         else:
#             logits_per_image = logit_scale * image_features @ text_features.T
#             logits_per_text = logit_scale * text_features @ image_features.T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


# class SSLSumDropout3ClipLoss(nn.Module):

#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def forward(self, image_features, text_features, logit_scale):
#         device = image_features.device
#         features = F.normalize(
#             torch.nn.functional.dropout(image_features + text_features, p=0.3),
#             dim=-1)
#         bsz = features.size(0) // 2
#         image_features = features[:bsz]  # huxu: abuse the variable name for consistent code, though it's MM feature now.
#         text_features = features[bsz:]  # huxu: abuse the variable name for consistent code, though it's MM feature now.

#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)

#             if self.local_loss:
#                 logits_per_image = logit_scale * image_features @ all_text_features.T
#                 logits_per_text = logit_scale * text_features @ all_image_features.T
#             else:
#                 logits_per_image = logit_scale * all_image_features @ all_text_features.T
#                 logits_per_text = logits_per_image.T
#         else:
#             logits_per_image = logit_scale * image_features @ text_features.T
#             logits_per_text = logit_scale * text_features @ image_features.T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


# class SSLSumMMClipLoss(nn.Module):

#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def forward(self, image_features, text_features, logit_scale):
#         device = image_features.device
#         drop_index = torch.randperm(image_features.size(0), device=device)
#         image_drop_index = drop_index[:int(drop_index.size(0) * 0.25)]
#         text_drop_index = drop_index[-int(drop_index.size(0) * 0.25):]
#         image_features[image_drop_index] = 0.
#         text_features[text_drop_index] = 0.
#         features = F.normalize(image_features + text_features, dim=-1)
#         bsz = features.size(0) // 2
#         image_features = features[:bsz]  # huxu: abuse the variable name for consistent code, though it's MM feature now.
#         text_features = features[bsz:]  # huxu: abuse the variable name for consistent code, though it's MM feature now.

#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)

#             if self.local_loss:
#                 logits_per_image = logit_scale * image_features @ all_text_features.T
#                 logits_per_text = logit_scale * text_features @ all_image_features.T
#             else:
#                 logits_per_image = logit_scale * all_image_features @ all_text_features.T
#                 logits_per_text = logits_per_image.T
#         else:
#             logits_per_image = logit_scale * image_features @ text_features.T
#             logits_per_text = logit_scale * text_features @ image_features.T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


# class SSLSumMM3ClipLoss(nn.Module):

#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def forward(self, image_features, text_features, logit_scale):
#         device = image_features.device
#         drop_index = torch.randperm(image_features.size(0), device=device)
#         image_drop_index = drop_index[:int(drop_index.size(0) * 0.15)]
#         text_drop_index = drop_index[-int(drop_index.size(0) * 0.15):]
#         image_features[image_drop_index] = 0.
#         text_features[text_drop_index] = 0.
#         features = F.normalize(image_features + text_features, dim=-1)
#         bsz = features.size(0) // 2
#         image_features = features[:bsz]  # huxu: abuse the variable name for consistent code, though it's MM feature now.
#         text_features = features[bsz:]  # huxu: abuse the variable name for consistent code, though it's MM feature now.

#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)

#             if self.local_loss:
#                 logits_per_image = logit_scale * image_features @ all_text_features.T
#                 logits_per_text = logit_scale * text_features @ all_image_features.T
#             else:
#                 logits_per_image = logit_scale * all_image_features @ all_text_features.T
#                 logits_per_text = logits_per_image.T
#         else:
#             logits_per_image = logit_scale * image_features @ text_features.T
#             logits_per_text = logit_scale * text_features @ image_features.T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


# class SSLMeanClipLoss(nn.Module):

#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def forward(self, image_features, text_features, logit_scale):
#         device = image_features.device
#         features = F.normalize((image_features + text_features)/2., dim=-1)  # not normalized.
#         bsz = features.size(0) // 2
#         image_features = features[:bsz]  # huxu: abuse the variable name for consistent code, though it's MM feature now.
#         text_features = features[bsz:]  # huxu: abuse the variable name for consistent code, though it's MM feature now.

#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)

#             if self.local_loss:
#                 logits_per_image = logit_scale * image_features @ all_text_features.T
#                 logits_per_text = logit_scale * text_features @ all_image_features.T
#             else:
#                 logits_per_image = logit_scale * all_image_features @ all_text_features.T
#                 logits_per_text = logits_per_image.T
#         else:
#             logits_per_image = logit_scale * image_features @ text_features.T
#             logits_per_text = logit_scale * text_features @ image_features.T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


# class SSLMulClipLoss(nn.Module):

#     def __init__(
#             self,
#             local_loss=False,
#             gather_with_grad=False,
#             cache_labels=False,
#             rank=0,
#             world_size=1,
#             use_horovod=False,
#     ):
#         super().__init__()
#         self.local_loss = local_loss
#         self.gather_with_grad = gather_with_grad
#         self.cache_labels = cache_labels
#         self.rank = rank
#         self.world_size = world_size
#         self.use_horovod = use_horovod

#         # cache state
#         self.prev_num_logits = 0
#         self.labels = {}

#     def forward(self, image_features, text_features, logit_scale):
#         device = image_features.device
#         features = F.normalize(image_features * text_features, dim=-1)  # not normalized.
#         bsz = features.size(0) // 2
#         image_features = features[:bsz]  # huxu: abuse the variable name for consistent code, though it's MM feature now.
#         text_features = features[bsz:]  # huxu: abuse the variable name for consistent code, though it's MM feature now.

#         if self.world_size > 1:
#             all_image_features, all_text_features = gather_features(
#                 image_features, text_features,
#                 self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)

#             if self.local_loss:
#                 logits_per_image = logit_scale * image_features @ all_text_features.T
#                 logits_per_text = logit_scale * text_features @ all_image_features.T
#             else:
#                 logits_per_image = logit_scale * all_image_features @ all_text_features.T
#                 logits_per_text = logits_per_image.T
#         else:
#             logits_per_image = logit_scale * image_features @ text_features.T
#             logits_per_text = logit_scale * text_features @ image_features.T

#         # calculated ground-truth and cache if enabled
#         num_logits = logits_per_image.shape[0]
#         if self.prev_num_logits != num_logits or device not in self.labels:
#             labels = torch.arange(num_logits, device=device, dtype=torch.long)
#             if self.world_size > 1 and self.local_loss:
#                 labels = labels + num_logits * self.rank
#             if self.cache_labels:
#                 self.labels[device] = labels
#                 self.prev_num_logits = num_logits
#         else:
#             labels = self.labels[device]

#         total_loss = (
#             F.cross_entropy(logits_per_image, labels) +
#             F.cross_entropy(logits_per_text, labels)
#             ) / 2
#         return total_loss


"""
class SSLCatClipLoss(nn.Module):

    def __init__(
            self,
            local_loss=False,
            gather_with_grad=False,
            cache_labels=False,
            rank=0,
            world_size=1,
            use_horovod=False,
    ):
        super().__init__()
        self.local_loss = local_loss
        self.gather_with_grad = gather_with_grad
        self.cache_labels = cache_labels
        self.rank = rank
        self.world_size = world_size
        self.use_horovod = use_horovod

        # cache state
        self.prev_num_logits = 0
        self.labels = {}

    def forward(self, image_features, text_features, logit_scale):
        device = image_features.device
        features = F.normalize(torch.cat([image_features, text_features], dim=-1))  # not normalized.
        bsz = features.size(0) // 2
        image_features = features[:bsz]  # huxu: abuse the variable name for consistent code, though it's MM feature now.
        text_features = features[bsz:]  # huxu: abuse the variable name for consistent code, though it's MM feature now.

        if self.world_size > 1:
            all_image_features, all_text_features = gather_features(
                image_features, text_features,
                self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)

            if self.local_loss:
                logits_per_image = logit_scale * image_features @ all_text_features.T
                logits_per_text = logit_scale * text_features @ all_image_features.T
            else:
                logits_per_image = logit_scale * all_image_features @ all_text_features.T
                logits_per_text = logits_per_image.T
        else:
            logits_per_image = logit_scale * image_features @ text_features.T
            logits_per_text = logit_scale * text_features @ image_features.T

        # calculated ground-truth and cache if enabled
        num_logits = logits_per_image.shape[0]
        if self.prev_num_logits != num_logits or device not in self.labels:
            labels = torch.arange(num_logits, device=device, dtype=torch.long)
            if self.world_size > 1 and self.local_loss:
                labels = labels + num_logits * self.rank
            if self.cache_labels:
                self.labels[device] = labels
                self.prev_num_logits = num_logits
        else:
            labels = self.labels[device]

        total_loss = (
            F.cross_entropy(logits_per_image, labels) +
            F.cross_entropy(logits_per_text, labels)
            ) / 2
        return total_loss


class SSLCat12ClipLoss(nn.Module):

    def __init__(
            self,
            local_loss=False,
            gather_with_grad=False,
            cache_labels=False,
            rank=0,
            world_size=1,
            use_horovod=False,
    ):
        super().__init__()
        self.local_loss = local_loss
        self.gather_with_grad = gather_with_grad
        self.cache_labels = cache_labels
        self.rank = rank
        self.world_size = world_size
        self.use_horovod = use_horovod

        # cache state
        self.prev_num_logits = 0
        self.labels = {}

    def forward(self, image_features, text_features, logit_scale):
        device = image_features.device
        features = F.normalize(image_features, dim=-1)  # not normalized.
        bsz = features.size(0) // 2
        image_features = features[:bsz]  # huxu: abuse the variable name for consistent code, though it's MM feature now.
        text_features = features[bsz:]  # huxu: abuse the variable name for consistent code, though it's MM feature now.

        if self.world_size > 1:
            all_image_features, all_text_features = gather_features(
                image_features, text_features,
                self.local_loss, self.gather_with_grad, self.rank, self.world_size, self.use_horovod)

            if self.local_loss:
                logits_per_image = logit_scale * image_features @ all_text_features.T
                logits_per_text = logit_scale * text_features @ all_image_features.T
            else:
                logits_per_image = logit_scale * all_image_features @ all_text_features.T
                logits_per_text = logits_per_image.T
        else:
            logits_per_image = logit_scale * image_features @ text_features.T
            logits_per_text = logit_scale * text_features @ image_features.T

        # calculated ground-truth and cache if enabled
        num_logits = logits_per_image.shape[0]
        if self.prev_num_logits != num_logits or device not in self.labels:
            labels = torch.arange(num_logits, device=device, dtype=torch.long)
            if self.world_size > 1 and self.local_loss:
                labels = labels + num_logits * self.rank
            if self.cache_labels:
                self.labels[device] = labels
                self.prev_num_logits = num_logits
        else:
            labels = self.labels[device]

        total_loss = (
            F.cross_entropy(logits_per_image, labels) +
            F.cross_entropy(logits_per_text, labels)
            ) / 2
        return total_loss
"""