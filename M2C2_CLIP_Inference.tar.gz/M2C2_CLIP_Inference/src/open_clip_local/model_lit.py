from collections import OrderedDict
from dataclasses import dataclass
import logging
import math
from typing import Tuple, Union, Callable, Optional

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn
from torch.utils.checkpoint import checkpoint

from .model import Transformer,QuickGELU,LayerNorm
from .utils import to_2tuple
import pdb

LU_LIST = ['u','du']

class TextWrapper(nn.Module):
    def __init__(
            self, text_cfg, embed_dim, act_layer):
        super().__init__()


        self.transformer = Transformer(
            width=text_cfg.width,
            layers=text_cfg.layers,
            heads=text_cfg.heads,
            act_layer=act_layer,
        )
        self.width = self.transformer.width
        self.layers = self.transformer.layers
        self.embed_dim = embed_dim

        self.vocab_size = text_cfg.vocab_size
        self.context_length = text_cfg.context_length

        self.token_embedding = nn.Embedding(text_cfg.vocab_size, text_cfg.width)
        self.positional_embedding = nn.Parameter(torch.empty(self.context_length, text_cfg.width))
        self.ln_final = LayerNorm(text_cfg.width)

        self.text_projection = nn.Parameter(torch.empty(text_cfg.width, embed_dim))
        self.register_buffer('attn_mask', self.build_attention_mask(), persistent=False)
    
    def build_attention_mask(self):
        # lazily create causal attention mask, with full attention between the vision tokens
        # pytorch uses additive attention mask; fill with -inf
        mask = torch.empty(self.context_length, self.context_length)
        mask.fill_(float("-inf"))
        mask.triu_(1)  # zero out the lower diagonal
        return mask
    
    def forward(self, text, return_pre=False):
        x = self.token_embedding(text)  # [batch_size, n_ctx, d_model]

        x = x + self.positional_embedding
        x = x.permute(1, 0, 2)  # NLD -> LND
        x = self.transformer(x, attn_mask=self.attn_mask)
        x = x.permute(1, 0, 2)  # LND -> NLD
        x = self.ln_final(x)

        x_pre = x[torch.arange(x.shape[0]), text.argmax(dim=-1)] 
        x = x_pre @ self.text_projection
        return (x,x_pre) if return_pre else x
    
    def init_parameters(self):
        nn.init.normal_(self.token_embedding.weight, std=0.02)
        nn.init.normal_(self.positional_embedding, std=0.01)

        proj_std = (self.transformer.width ** -0.5) * ((2 * self.transformer.layers) ** -0.5)
        attn_std = self.transformer.width ** -0.5
        fc_std = (2 * self.transformer.width) ** -0.5
        for block in self.transformer.resblocks:
            nn.init.normal_(block.attn.in_proj_weight, std=attn_std)
            nn.init.normal_(block.attn.out_proj.weight, std=proj_std)
            nn.init.normal_(block.mlp.c_fc.weight, std=fc_std)
            nn.init.normal_(block.mlp.c_proj.weight, std=proj_std)

        nn.init.normal_(self.text_projection, std=self.embed_dim ** -0.5)


class LogitPostPro(nn.Module):
    def __init__(self, sigmoid=False, both=False):
        super().__init__()
        if both:
            self.logit_scale = nn.Parameter(torch.ones([]) * 10.0)
            self.logit_bias = nn.Parameter(torch.ones([]) * (-10.0))
            self.logit_log_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))
        else:
            if sigmoid:
                self.logit_scale = nn.Parameter(torch.ones([]) * 10.0)
                self.logit_bias = nn.Parameter(torch.ones([]) * (-10.0))
            else:
                self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))
                self.logit_bias = None
    

@dataclass
class CLIPTextCfg:
    context_length: int = 77
    vocab_size: int = 49408
    width: int = 512
    heads: int = 8
    layers: int = 12


class CLIPLiT(nn.Module):
    def __init__(
            self,
            embed_dim: int,
            text_cfg: CLIPTextCfg,
            quick_gelu: bool = False,
            visual_init: str = 'dinov2_vitl14', # dino_vitb16
            lu_mode: str = 'u'
    ):
        super().__init__()
        if isinstance(text_cfg, dict):
            text_cfg = CLIPTextCfg(**text_cfg)
        if lu_mode == 'du':
            text_cfg.width = 768

        self.context_length = text_cfg.context_length
        act_layer = QuickGELU if quick_gelu else nn.GELU
        self.visual = torch.hub.load('facebookresearch/dinov2', visual_init)
        self.embed_dim = self.visual.norm.weight.size(0)
        self.lu_mode = lu_mode
        self.visual.image_size = to_2tuple(224)
        
        if lu_mode in LU_LIST:
            logging.info('LiT mode is Lu, training from scratch')
            self.text_transformer = TextWrapper(text_cfg, self.embed_dim, act_layer)
        else:
            from transformers import AutoModel
            try:
                self.text_transformer = AutoModel.from_pretrained(lu_mode)
            except:
                self.text_transformer = AutoModel.from_pretrained("princeton-nlp/sup-simcse-bert-base-uncased")
            text_dim = self.text_transformer.pooler.dense.weight.size(0)
            self.text_transformer.text_projection = nn.Parameter(torch.empty(text_dim, self.embed_dim))
        
        self.logit_postpro = LogitPostPro(False)
        self.logit_scale = self.logit_postpro.logit_scale
        self.init_parameters()

    def init_parameters(self):
        for p in self.visual.parameters():
            p.requires_grad=False
        if self.lu_mode in LU_LIST:
            self.text_transformer.init_parameters()
        else:
            nn.init.normal_(self.text_transformer.text_projection, std=self.embed_dim ** -0.5)

    def encode_image(self, image, is_feature=False):
        return image if is_feature else self.visual(image)

    def encode_text(self, text, return_pre=False):
        if self.lu_mode in LU_LIST:
            return self.text_transformer(text,return_pre)
        else:
            x_pre = self.text_transformer(**text, output_hidden_states=True, return_dict=True).pooler_output
            if hasattr(self.text_transformer,'module'):
                x = x_pre @ self.text_transformer.module.text_projection
            else:
                x = x_pre @ self.text_transformer.text_projection
            return (x,x_pre) if return_pre else x

    def forward(self, image, text, clamp_logit_scale_to=None):
        if image is not None:
            image_features = self.encode_image(image, (len(image.size())==2))
            image_features = F.normalize(image_features, dim=-1)
        else:
            image_features = None
        if text is not None:
            text_features = self.encode_text(text)
            text_features = F.normalize(text_features, dim=-1)
        else:
            text_features = None
        if clamp_logit_scale_to is not None:
            with torch.no_grad():
                self.logit_postpro.logit_scale.data.clamp_(0, clamp_logit_scale_to)
        if hasattr(self.logit_postpro,'module'):
            scaler = self.logit_postpro.module.logit_scale.exp()
        else:
            scaler = self.logit_postpro.logit_scale.exp()
        return image_features, text_features, scaler


class CLIPLiTSigmoid(CLIPLiT):
    def __init__(
            self,
            embed_dim: int,
            text_cfg: CLIPTextCfg,
            quick_gelu: bool = False,
            visual_init: str = 'dinov2_vitl14', # dino_vitb16
            lu_mode: str = 'u'
    ):
        super(CLIPLiTSigmoid, self).__init__(embed_dim, text_cfg, quick_gelu, visual_init, lu_mode)

        self.logit_postpro = LogitPostPro(True)
        self.logit_scale = self.logit_postpro.logit_scale
        self.logit_bias = self.logit_postpro.logit_bias

    def forward(self, image, text, clamp_logit_scale_to=None):
        if image is not None:
            image_features = self.encode_image(image, (len(image.size())==2))
            image_features = F.normalize(image_features, dim=-1)
        else:
            image_features = None
        if text is not None:
            text_features = self.encode_text(text)
            text_features = F.normalize(text_features, dim=-1)
        else:
            text_features = None
        
        return image_features, text_features, self.logit_scale, self.logit_bias


class CLIPLiTSS(CLIPLiT):
    def __init__(
            self,
            embed_dim: int,
            text_cfg: CLIPTextCfg,
            quick_gelu: bool = False,
            visual_init: str = 'dinov2_vitl14', # dino_vitb16
            lu_mode: str = 'u'
    ):
        super(CLIPLiTSigmoid, self).__init__(embed_dim, text_cfg, quick_gelu, visual_init, lu_mode)

        self.logit_postpro = LogitPostPro(both=True)
        self.logit_scale = self.logit_postpro.logit_scale
        self.logit_bias = self.logit_postpro.logit_bias
        self.logit_log_scale = self.logit_postpro.logit_log_scale

    def forward(self, image, text, clamp_logit_scale_to=None):
        if image is not None:
            image_features = self.encode_image(image, (len(image.size())==2))
            image_features = F.normalize(image_features, dim=-1)
        else:
            image_features = None
        if text is not None:
            text_features = self.encode_text(text)
            text_features = F.normalize(text_features, dim=-1)
        else:
            text_features = None
        if hasattr(self.logit_postpro,'module'):
            scaler = self.logit_postpro.module.logit_log_scale.exp()
        else:
            scaler = self.logit_postpro.logit_log_scale.exp()
        return image_features, text_features, scaler, self.logit_scale, self.logit_bias