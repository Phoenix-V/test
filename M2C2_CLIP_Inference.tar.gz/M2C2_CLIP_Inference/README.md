# OpenCLIP

For Async CLIP

It looks like the best performance is always achieved when soft_cluster is set as 0.3
with some luck, it can sometimes hit 0.9~1.0 percent gain

May be can try other clustering results like DiffCSE to see if we can improve the performance?


For Semi-Sync CLIP,
I have prepare the commands for Sigmoid/CE LiT and list the commands in run.sh.
It will be great if it can be run asap.