import os
import json
import time
import torch
import numpy as np
import random
from tqdm import tqdm

from PIL import Image, ImageSequence


class GIFDataset(torch.utils.data.Dataset):
    '''from demos/video/test_gif.py'''
    def __init__(self, task_example_ids, tokenizer, hist_thres=None):
        self.size = 224
        self.max_len = 16
        self.dataset_dir = "/large_experiments/cmd/m2c2/m2c2_raw/gif/CC-MAIN-2021-49"
        self.tokenizer = tokenizer

        with open(os.path.join(self.dataset_dir, "gif_ann_en.json")) as fr:
            metadata = json.load(fr)

        if hist_thres is not None:
            print("using hist_thres", hist_thres)
            with open("data/CLIP/CLIP_eval/minim2c2_hist_ratio.json") as fr:
                img_hist_ratio = json.load(fr)

        data = []
        for videoid in metadata:
            if task_example_ids is not None and videoid not in task_example_ids:
                continue
            if hist_thres is not None:
                if img_hist_ratio[videoid] > hist_thres:
                    continue
            rec = metadata[videoid]
            text = " ".join([rec["alt"], rec["text"]])
            data.append((videoid, text))
        if task_example_ids is not None:
            print(f"apply task filter with {len(data)} examples.")
        self.data = data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        fn, caption = self.data[idx]
        images = []
        img_path = os.path.join(self.dataset_dir, fn)
        with Image.open(img_path) as im:
            t_frame = im.n_frames
            frame_indices = sorted(
                random.choices(range(t_frame), k=self.max_len)
            )
            for frame_idx in frame_indices:
                im.seek(frame_idx)
                height, width = self._get_output_dim(im.height, im.width)
                img = im.copy().resize((width, height), Image.ANTIALIAS).convert("RGB")
                x = int((width - self.size) / 2.0)
                y = int((height - self.size) / 2.0)
                img = img.crop((x, y, x+self.size, y+self.size))
                images.append(torch.from_numpy(np.array(img)))
        images = torch.stack(images)
        result = {"pixel_values": images, "captions": caption}
        if self.tokenizer is not None:
            caption_ids = self.tokenizer(
                caption, padding='max_length', truncation=True, max_length=77, return_tensors="pt")
            for key in caption_ids:
                caption_ids[key] = caption_ids[key][0]
            result.update(**caption_ids)
        return result

    def _get_output_dim(self, height, width):
        """
        keep the shorter side be `self.size`, strech the other.
        """
        if height >= width:
            return int(height * self.size / width), self.size
        else:
            return self.size, int(width * self.size / height)


if __name__ == '__main__':
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained("princeton-nlp/unsup-simcse-bert-base-uncased")
    dataset = GIFDataset(None, tokenizer)

    rec = dataset[0]
    print(rec["pixel_values"].size())
    print(rec["input_ids"].size())
