import os
import random
import json
import pandas as pd
import torch

import av
import decord
decord.bridge.set_bridge('torch')

from decord import VideoReader


class KineticsDataset(torch.utils.data.Dataset):
    def __init__(self, mode, tokenizer=None):
        csv_dir = "/private/home/huxu/mmpt/slowfast/k400_adaclip"
        self.sequence_length = 16
        self.size = 224

        self.data = []
        with open(os.path.join(csv_dir, f"{mode}.csv")) as fr:
            for line in fr:
                video_path, target = line.strip().split()
                self.data.append((video_path, int(target)))

        with open("clipeval/k400_labels.json") as fr:
            self.labels = json.load(fr)["kinetics400"]
        with open("clipeval/templates.json") as fr:
            self.templates = json.load(fr)["kinetics700_frames"]
        self.tokenizer = tokenizer

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        # not sure what two pieces mean but we just pick one.
        trial = 10
        while trial:
            trial -= 1
            try:
                videopath, target = self.data[idx]
                height, width = self._decode_dim(videopath)
                reader = VideoReader(videopath, height=height, width=width)
                assert len(reader) > 0, "at least one frame is needed."

                frame_indices = sorted(
                    random.choices(range(len(reader)), k=self.sequence_length)
                )
                assert all(idx >= 0 for idx in frame_indices)
                assert all(idx < len(reader) for idx in frame_indices)

                video = reader.get_batch(frame_indices)

                x = int(width - self.size)
                y = int(height - self.size)

                x = random.randint(0, x)
                y = random.randint(0, y)

                video = video[:, y : y + self.size, x : x + self.size, :]
                break
            except Exception as e:  # gently sample another video and try to avoid locked on bad video.
                idx = random.randint(0, len(self)-1)
        else:
            raise ValueError("10 trials failed.")

        caption = self.templates[idx % len(self.templates)].format(self.labels[target])
        if self.tokenizer is not None:
            caption = self.tokenizer(
                caption, padding="max_length", truncation=True, max_length=77, return_tensors="pt")
            for key in caption:
                caption[key] = caption[key][0]
            result = {"pixel_values": video}
            result.update(caption)
            return result
        else:
            return {"pixel_values": video, "targets": target}

    def _decode_dim(self, video_path):
        height, width = self._get_video_dim(video_path)
        return self._get_output_dim(height, width)

    def _get_output_dim(self, height, width):
        """
        keep the shorter side be `self.size`, strech the other.
        """
        if height >= width:
            return int(height * self.size / width), self.size
        else:
            return self.size, int(width * self.size / height)

    def _get_video_dim(self, video_fn):
        """decord cannot probe the size of a video, we use pyav instead."""
        # video_path = os.path.join(self.video_dir, video_fn)
        with av.open(video_fn) as container:
            height = container.streams.video[0].codec_context.height
            width = container.streams.video[0].codec_context.width
        return height, width


class KineticsWrapperDataset(torch.utils.data.Dataset):
    def __init__(self, mode, tokenizer=None, use_template=True):
        import sys
        sys.path.append("/private/home/huxu/mmpt/slowfast")
        import slowfast.utils.logging as logging

        from slowfast.config.defaults import assert_and_infer_cfg
        from slowfast.utils.parser import load_config, parse_args
        from slowfast.datasets import loader, build_dataset

        class Arg:
            cfg_file = "/private/home/huxu/MMPT/pretrained_models/maskfeat/MB_FT.yaml"
            opts = [
                "DATA.PATH_TO_DATA_DIR", "/private/home/huxu/mmpt/slowfast/k400_adaclip",
                "DATA.DECODING_BACKEND", "pyav",
                "NUM_GPUS", "8",
                "TRAIN.BATCH_SIZE", "384",
                "TRAIN.CHECKPOINT_FILE_PATH", "",
                "TEST.BATCH_SIZE", "384",
                "OUTPUT_DIR", "runs/adaclip"
            ]

        args = Arg()

        cfg = load_config(args)
        cfg = assert_and_infer_cfg(cfg)

        logger = logging.get_logger(__name__)
        logging.setup_logging(cfg.OUTPUT_DIR)

        self.data = build_dataset(cfg.TRAIN.DATASET, cfg, mode)
        with open("clipeval/k400_labels.json") as fr:
            self.labels = json.load(fr)["kinetics400"]
        with open("clipeval/templates.json") as fr:
            self.templates = json.load(fr)["kinetics700_frames"]
        self.tokenizer = tokenizer
        self.mode = mode
        self.use_template = use_template

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        # not sure what two pieces mean but we just pick one.
        images, target, _, meta = self.data[idx]
        if self.mode == "train":
            images, target = images[0], target[0]
        images = images[0]

        if self.use_template:
            caption = self.templates[idx % len(self.templates)].format(self.labels[target])
        else:
            caption = self.labels[target]

        if self.tokenizer is not None:
            input_ids = self.tokenizer(
                caption, padding='max_length', truncation=True, max_length=77, return_tensors="pt")
            for key in input_ids:
                input_ids[key] = input_ids[key][0]
            result = {"pixel_values": images, "captions": caption}
            result.update(**input_ids)
            return result
        else:
            return {"pixel_values": images, "targets": target}


if __name__ == '__main__':

    dataset = KineticsWrapperDataset("val")
    rec = dataset[0]
    print(rec["pixel_values"].size())
    print(rec["targets"])

    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained("princeton-nlp/unsup-simcse-bert-base-uncased")

    dataset = KineticsWrapperDataset("train", tokenizer)
    rec = dataset[0]
    print(rec["pixel_values"].size())
    print(rec["input_ids"].size())
