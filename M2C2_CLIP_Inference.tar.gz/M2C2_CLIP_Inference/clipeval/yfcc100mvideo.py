import os
import random
import json
import pandas as pd
import torch
import pickle
import av

import decord
decord.bridge.set_bridge('torch')

from decord import VideoReader


def get_world_size():
    if torch.distributed.is_initialized():
        world_size = torch.distributed.get_world_size()
    else:
        world_size = 1
    return world_size


class YFCC100MVideoDataset(torch.utils.data.Dataset):
    """
    huxu: from mmpt.webvidprocessor.
    we move mean/std data transformation (slowfast/datasets/kinetics.py) to GPU side to speed up (see hfmodels/maskfeat.py).
    WebVid has pre-splitted csv
    """
    def __init__(self, task_example_ids, tokenizer):
        self.size = 224
        self.sequence_length = 16
        self.tokenizer = tokenizer

        with open("data/yfcc100m_video/yfcc100m_video.pkl", 'rb') as f:
            samples = pickle.load(f)
            if task_example_ids is not None:
                self.samples = []
                for image_id, title, desc in samples:
                    if image_id in task_example_ids:
                        self.samples.append((image_id, title, desc))
                        # if len(self.samples) == 27892:  # TODO: remove for testing m2c2 only.
                        #     break
                print(f"apply task filter with {len(self.samples)} examples.")
            else:
                self.samples = samples

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        trial = 10
        while trial:
            trial -= 1
            try:
                videopath, title, desc = self.samples[idx]
                caption = " ".join([title, desc]).strip()
                height, width = self._decode_dim(videopath)
                reader = VideoReader(videopath, height=height, width=width)
                assert len(reader) > 0, "at least one frame is needed."
                total_frames = len(reader)
                fps = reader.get_avg_fps()
                clip_frames = int(fps * 10)  # 10 secs of video as kinetics.
                # sample 10 seconds
                start_frame = random.randint(0, total_frames-1-clip_frames) if total_frames > clip_frames else 0
                end_frame = min(start_frame + clip_frames, total_frames)
                frame_indices = sorted(
                    random.choices(range(start_frame, end_frame), k=self.sequence_length)
                )
                assert all(idx >= 0 for idx in frame_indices)
                assert all(idx < len(reader) for idx in frame_indices)
                video = reader.get_batch(frame_indices)

                # center crop:
                # x = int((width - self.size) / 2.0)
                # y = int((height - self.size) / 2.0)

                x = int(width - self.size)
                y = int(height - self.size)

                x = random.randint(0, x)
                y = random.randint(0, y)

                video = video[:, y : y + self.size, x : x + self.size, :]
                break
            except Exception as e:  # gently sample another video and try to avoid locked on bad video.
                idx = random.randint(0, len(self)-1)
        else:
            raise ValueError("10 trials failed.")
        result = {"pixel_values": video, "captions": caption}
        if self.tokenizer is not None:
            input_ids = self.tokenizer(caption, padding='max_length', truncation=True, max_length=77, return_tensors="pt")
            for key in input_ids:
                input_ids[key] = input_ids[key][0]
            result.update(**input_ids)
        return result

    def _decode_dim(self, video_path):
        height, width = self._get_video_dim(video_path)
        return self._get_output_dim(height, width)

    def _get_output_dim(self, height, width):
        """
        keep the shorter side be `self.size`, strech the other.
        """
        if height >= width:
            return int(height * self.size / width), self.size
        else:
            return self.size, int(width * self.size / height)

    def _get_video_dim(self, video_fn):
        """decord cannot probe the size of a video, we use pyav instead."""
        # video_path = os.path.join(self.video_dir, video_fn)
        with av.open(video_fn) as container:
            height = container.streams.video[0].codec_context.height
            width = container.streams.video[0].codec_context.width
        return height, width


if __name__ == '__main__':
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained("princeton-nlp/unsup-simcse-bert-base-uncased")

    val_task = "kinetics400"
    dataset = "yfcc100m_video"
    thres = 0.55
    task_meta = torch.load(f"data/CLIP/CLIP_eval/{val_task}_ub_{dataset}_simcse{thres}.pt")
    train_task_example_ids = set(task_meta["example_ids"])

    dataset = YFCC100MVideoDataset(train_task_example_ids, tokenizer)

    for idx in range(10):
        rec = dataset[idx]
        print(rec["pixel_values"].size())
        print(rec["input_ids"].size())
