import os
import random
import json
import pandas as pd
import torch
import av
import decord
decord.bridge.set_bridge('torch')

from decord import VideoReader


def get_world_size():
    if torch.distributed.is_initialized():
        world_size = torch.distributed.get_world_size()
    else:
        world_size = 1
    return world_size


class WebVidDataset(torch.utils.data.Dataset):
    """
    huxu: from mmpt.webvidprocessor.
    we move mean/std data transformation (slowfast/datasets/kinetics.py) to GPU side to speed up (see hfmodels/maskfeat.py).
    WebVid has pre-splitted csv
    """
    def __init__(self, task_example_ids, tokenizer, max_sample=None):
        vfeat_dir = "/checkpoint/huxu/feat/WebVid_r224f8"
        self.sequence_length = 16
        self.tokenizer = tokenizer

        csv_data = pd.read_csv("data/WebVid/results_2M_combined.csv")
        # remove videoids that are invalid.
        meta_id2path_fn = os.path.join(vfeat_dir, "meta_id2path.json")

        with open(meta_id2path_fn) as fr:
            meta_id2path = json.load(fr)

        data = []

        for idx in range(len(csv_data)):
            videoid = str(csv_data["videoid"].values[idx])
            if videoid in meta_id2path:
                if task_example_ids is not None and videoid not in task_example_ids:
                    continue
                data.append((
                    (videoid, meta_id2path[videoid]),
                    csv_data["name"].values[idx]
                ))
                if max_sample is not None and len(data) >= max_sample:  # TODO: remove for testing m2c2 only.
                    break

        if task_example_ids is not None:
            print(f"apply task filter with {len(data)} examples.")
        self.data = data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        (video_id, videopath), caption = self.data[idx % len(self.data)]
        try:
            reader = VideoReader(videopath)
            assert len(reader) > 0, "at least one frame is needed."
        except Exception:
            print("[VideoReader]", videopath)
            assert False

        frame_indices = sorted(
            random.choices(range(len(reader)), k=self.sequence_length)
        )
        assert all(idx >= 0 for idx in frame_indices)
        assert all(idx < len(reader) for idx in frame_indices)

        video = reader.get_batch(frame_indices)
        result = {"pixel_values": video, "captions": caption}
        if self.tokenizer is not None:
            input_ids = self.tokenizer(
                caption, padding='max_length', truncation=True, max_length=77, return_tensors="pt")
            for key in input_ids:
                input_ids[key] = input_ids[key][0]
            result.update(**input_ids)
        return result


class WebvidSlowFastDataset:
    def __init__(self, task_example_ids, tokenizer):
        import sys
        sys.path.append("/private/home/huxu/mmpt/slowfast")
        import slowfast.utils.logging as logging

        from slowfast.config.defaults import assert_and_infer_cfg
        from slowfast.utils.parser import load_config, parse_args
        from slowfast.datasets import loader, build_dataset, Kinetics

        class Arg:
            cfg_file = "/private/home/huxu/MMPT/pretrained_models/maskfeat/MB_FT.yaml"
            opts = [
                "DATA.PATH_TO_DATA_DIR", "data/WebVid/kinetics",
                "DATA.DECODING_BACKEND", "pyav",
                "NUM_GPUS", "8",
                "TRAIN.BATCH_SIZE", "384",
                "TRAIN.CHECKPOINT_FILE_PATH", "",
                "TEST.BATCH_SIZE", "384",
                "OUTPUT_DIR", "runs/adaclip"
            ]

        args = Arg()

        cfg = load_config(args)
        cfg = assert_and_infer_cfg(cfg)

        logger = logging.get_logger(__name__)
        logging.setup_logging(cfg.OUTPUT_DIR)

        # Webviddataset
        vfeat_dir = "/checkpoint/huxu/feat/WebVid_r224f8"
        self.sequence_length = 16
        self.tokenizer = tokenizer

        csv_data = pd.read_csv("data/WebVid/results_2M_combined.csv")
        # remove videoids that are invalid.
        meta_id2path_fn = os.path.join(vfeat_dir, "meta_id2path.json")

        with open(meta_id2path_fn) as fr:
            meta_id2path = json.load(fr)

        data = []
        '''
        # generate csv.
        with open(os.path.join("data/WebVid/kinetics", "train.csv"), "w") as fw:
            for idx in range(len(csv_data)):
                videoid = str(csv_data["videoid"].values[idx])
                if videoid in meta_id2path:
                    if task_example_ids is not None and videoid not in task_example_ids:
                        continue
                    fw.write(meta_id2path[videoid]+" 0\n")  # 0 is a dummy label.
        exit()
        '''
        for idx in range(len(csv_data)):
            videoid = str(csv_data["videoid"].values[idx])
            if videoid in meta_id2path:
                if task_example_ids is not None and videoid not in task_example_ids:
                    continue
                data.append((
                    (videoid, meta_id2path[videoid]),
                    csv_data["name"].values[idx]
                ))
        
        if task_example_ids is not None:
            print(f"apply task filter with {len(data)} examples.")
        self.data = data
        self.data_vid = Kinetics(cfg, "train")

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        (video_id, videopath), caption = self.data[idx % len(self.data)]

        video, _, _, meta = self.data_vid[idx]
        video = video[0][0]
        result = {"pixel_values": video, "captions": caption}
        if self.tokenizer is not None:
            input_ids = self.tokenizer(
                caption, padding='max_length', truncation=True, max_length=77, return_tensors="pt")
            for key in input_ids:
                input_ids[key] = input_ids[key][0]
            result.update(**input_ids)
        return result


class WebVidDataset10M(torch.utils.data.Dataset):
    """
    huxu: from mmpt.webvidprocessor.
    we move mean/std data transformation (slowfast/datasets/kinetics.py) to GPU side to speed up (see hfmodels/maskfeat.py).
    WebVid has pre-splitted csv
    """
    def __init__(self, task_example_ids, tokenizer, max_sample=None):
        self.vfeat_dir = "/large_experiments/creativity/datasets/webvid/"
        self.sequence_length = 16
        self.size = 224
        self.tokenizer = tokenizer

        csv_data = pd.read_csv("data/WebVid/results_10M_combined.csv")
        # remove videoids that are invalid.

        meta_id2path = {}
        for fn in [
            "/checkpoint/thayes427/data/gif_video_datasets/webvid10M/train.json",
            "/checkpoint/thayes427/data/gif_video_datasets/webvid10M/val.json",
        ]:
            with open(fn) as fr:
                recs = json.load(fr)["data"]
                for rec in recs:
                    meta_id2path[rec["video"]["id"]] = rec["video"]["video_path"]

        data = []

        for idx in range(len(csv_data)):
            videoid = str(csv_data["videoid"].values[idx])
            if videoid in meta_id2path:
                if task_example_ids is not None and videoid not in task_example_ids:
                    continue
                data.append((
                    (videoid, meta_id2path[videoid]),
                    csv_data["name"].values[idx]
                ))
                if max_sample is not None and len(data) >= max_sample:  # TODO: remove for testing m2c2 only.
                    break

        if task_example_ids is not None:
            print(f"apply task filter with {len(data)} examples.")
        self.data = data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        trial = 10
        while trial:
            trial -= 1
            try:
                (video_id, videopath), caption = self.data[idx % len(self.data)]
                videopath = os.path.join(self.vfeat_dir, videopath)
                height, width = self._decode_dim(videopath)
                reader = VideoReader(videopath, height=height, width=width)
                assert len(reader) > 0, "at least one frame is needed."
                total_frames = len(reader)
                fps = reader.get_avg_fps()
                clip_frames = int(fps * 10)  # 10 secs of video as kinetics.
                # sample 10 seconds
                start_frame = random.randint(0, total_frames-1-clip_frames) if total_frames > clip_frames else 0
                end_frame = min(start_frame + clip_frames, total_frames)
                frame_indices = sorted(
                    random.choices(range(start_frame, end_frame), k=self.sequence_length)
                )
                assert all(idx >= 0 for idx in frame_indices)
                assert all(idx < len(reader) for idx in frame_indices)
                video = reader.get_batch(frame_indices)

                # center crop:
                # x = int((width - self.size) / 2.0)
                # y = int((height - self.size) / 2.0)

                x = int(width - self.size)
                y = int(height - self.size)

                x = random.randint(0, x)
                y = random.randint(0, y)

                video = video[:, y : y + self.size, x : x + self.size, :]
                break
            except Exception:  # gently sample another video and try to avoid locked on bad video.
                idx = random.randint(0, len(self)-1)
        else:
            raise ValueError("10 trials failed.")
        result = {"pixel_values": video, "captions": caption}
        if self.tokenizer is not None:
            input_ids = self.tokenizer(
                caption, padding='max_length', truncation=True, max_length=77, return_tensors="pt")
            for key in input_ids:
                input_ids[key] = input_ids[key][0]
            result.update(**input_ids)
        return result

    def _decode_dim(self, video_path):
        height, width = self._get_video_dim(video_path)
        return self._get_output_dim(height, width)

    def _get_output_dim(self, height, width):
        """
        keep the shorter side be `self.size`, strech the other.
        """
        if height >= width:
            return int(height * self.size / width), self.size
        else:
            return self.size, int(width * self.size / height)

    def _get_video_dim(self, video_fn):
        """decord cannot probe the size of a video, we use pyav instead."""
        # video_path = os.path.join(self.video_dir, video_fn)
        with av.open(video_fn) as container:
            height = container.streams.video[0].codec_context.height
            width = container.streams.video[0].codec_context.width
        return height, width


class WebvidSlowFastDataset:
    def __init__(self, task_example_ids, tokenizer):
        import sys
        sys.path.append("/private/home/huxu/mmpt/slowfast")
        import slowfast.utils.logging as logging

        from slowfast.config.defaults import assert_and_infer_cfg
        from slowfast.utils.parser import load_config, parse_args
        from slowfast.datasets import loader, build_dataset, Kinetics

        class Arg:
            cfg_file = "/private/home/huxu/MMPT/pretrained_models/maskfeat/MB_FT.yaml"
            opts = [
                "DATA.PATH_TO_DATA_DIR", "data/WebVid/kinetics",
                "DATA.DECODING_BACKEND", "pyav",
                "NUM_GPUS", "8",
                "TRAIN.BATCH_SIZE", "384",
                "TRAIN.CHECKPOINT_FILE_PATH", "",
                "TEST.BATCH_SIZE", "384",
                "OUTPUT_DIR", "runs/adaclip"
            ]

        args = Arg()

        cfg = load_config(args)
        cfg = assert_and_infer_cfg(cfg)

        logger = logging.get_logger(__name__)
        logging.setup_logging(cfg.OUTPUT_DIR)

        # Webviddataset
        vfeat_dir = "/checkpoint/huxu/feat/WebVid_r224f8"
        self.sequence_length = 16
        self.tokenizer = tokenizer

        csv_data = pd.read_csv("data/WebVid/results_2M_combined.csv")
        # remove videoids that are invalid.
        meta_id2path_fn = os.path.join(vfeat_dir, "meta_id2path.json")

        with open(meta_id2path_fn) as fr:
            meta_id2path = json.load(fr)

        data = []
        '''
        # generate csv.
        with open(os.path.join("data/WebVid/kinetics", "train.csv"), "w") as fw:
            for idx in range(len(csv_data)):
                videoid = str(csv_data["videoid"].values[idx])
                if videoid in meta_id2path:
                    if task_example_ids is not None and videoid not in task_example_ids:
                        continue
                    fw.write(meta_id2path[videoid]+" 0\n")  # 0 is a dummy label.
        exit()
        '''
        for idx in range(len(csv_data)):
            videoid = str(csv_data["videoid"].values[idx])
            if videoid in meta_id2path:
                if task_example_ids is not None and videoid not in task_example_ids:
                    continue
                data.append((
                    (videoid, meta_id2path[videoid]),
                    csv_data["name"].values[idx]
                ))
        
        if task_example_ids is not None:
            print(f"apply task filter with {len(data)} examples.")
        self.data = data
        self.data_vid = Kinetics(cfg, "train")

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        (video_id, videopath), caption = self.data[idx % len(self.data)]

        video, _, _, meta = self.data_vid[idx]
        video = video[0][0]

        result = {"pixel_values": video}
        if self.tokenizer is not None:
            caption = self.tokenizer(
                caption, padding='max_length', truncation=True, max_length=77, return_tensors="pt")
            for key in caption:
                caption[key] = caption[key][0]
            result.update(**caption)
        return result


if __name__ == '__main__':
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained("princeton-nlp/unsup-simcse-bert-base-uncased")
    dataset = WebVidDataset(tokenizer)

    rec = dataset[0]
    print(rec["pixel_values"].size())
    print(rec["input_ids"].size())
