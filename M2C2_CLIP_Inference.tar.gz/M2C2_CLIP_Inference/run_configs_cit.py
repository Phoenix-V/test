# torchrun --nproc_per_node=8 src/training/main.py m2c2_base32
# https://github.com/mlfoundations/open_clip/issues/191
# https://docs.google.com/document/d/1EFbMLRWSSV0LUf9Du1pWzWqgeiIRPwEWX2s1C6mAk5c/edit


from configs import Config
CIT_IDX = "/private/home/huxu/mmpt/open_clip/data/cit_pilot/base/20000_60800.npy"
CIT_IDX_AUG = "/private/home/huxu/mmpt/open_clip/data/cit_pilot/base/20000_63000.npy"
CIT_IDX_2B5 = "/private/home/huxu/mmpt/open_clip/data/cit_pilot/fullcc/fullcc_index/subset_170000"
CIT_DATA = "/private/home/huxu/mmpt/open_clip/data/cit_pilot/{0..60800}.tar"
CIT_DATA_AUG = "/private/home/huxu/mmpt/open_clip/data/cit_pilot/{0..63000}.tar"
CIT_DATA_2B5 = "/private/home/huxu/mmpt/open_clip/data/cit_pilot/fullcc/{0..200000}.tar"


QKS_CKPT_B32 = "/private/home/huxu/mmpt/open_clip/logs/b32_cit400m/"
QKS_CKPT_B32_2B5 = "/private/home/huxu/mmpt/open_clip/logs/b32_fullcc"
QKS_CKPT_B16 = "/private/home/huxu/mmpt/open_clip/logs/b16_cit400m/"
QKS_CKPT_B16_2B5 = "/private/home/phoenixma/project/M2C2_CLIP/logs/b16_fullcc/"
QKS_CKPT_L14 = "/private/home/huxu/mmpt/open_clip/logs/l14128_cit400m_bk/"
QKS_CKPT_L14_AUG = "/private/home/huxu/mmpt/open_clip/logs/l14128_cit400m/"
QKS_CKPT_L14_2B5 = "/private/home/phoenixma/project/M2C2_CLIP/logs/l14128_fullcc/"


SIMCSE_BERT="/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/group_summary/2-bert"
DIFFCSE_STS="/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/group_summary/2-bert_sts"
DIFFCSE_TRANS="/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/group_summary/2-bert_trans"
SIMCSE_BERTCOS="/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/group_summary/2-bert-cos"
SIMCSE_BERT_AUG="/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/group_summary/2-sbert-aug"
SIMCSE_BERT_FCC="/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/group_summary/2-sbert-fullcc"
SIMCSE_BERT_FAISS="/large_experiments/cmd/m2c2/cit/phoenix/checkpoints/clustering_cit/group_summary/sbert-faiss/cit400m"

# =======================================
#  baseline
#   optional args: init_epoch=27 
#   \ load specified epoch as init
# =======================================
def b32_cit400m_vanilla(**overwrite):
    return Config(
        overwrite,
        cit_dir=CIT_IDX, # equivalent of index_dir
        train_data=CIT_DATA,
        inmem=True,
        engine="train_one_epoch_ex",
        eval_steps=5000,
        save_frequency=1,
        workers=6,
        train_num_samples=400_000_000,
        nodes=16, ngpus=4, 
        quick_start_init=QKS_CKPT_B32,
    )

def b32_cit2b5_vanilla(**overwrite):
    return Config(
        overwrite,
        cit_dir=CIT_IDX_2B5, # equivalent of index_dir
        train_data=CIT_DATA_2B5,
        inmem=True,
        engine="train_one_epoch_ex",
        eval_steps=5000,
        save_frequency=1,
        workers=6,
        train_num_samples=400_000_000,
        nodes=16, ngpus=4, 
        quick_start_init=QKS_CKPT_B32_2B5,
    )

def b16_cit400m_vanilla(**overwrite):
    return Config(
        overwrite,
        cit_dir=CIT_IDX, # equivalent of index_dir
        train_data=CIT_DATA,
        inmem=True,
        engine="train_one_epoch_ex",
        model="ViT-B-16",
        lr=0.0005,
        grad_checkpointing=True,
        eval_steps=5000,
        save_frequency=1,
        workers=6,
        train_num_samples=400_000_000,
        nodes=16, ngpus=4, 
        quick_start_init=QKS_CKPT_B16,
    )

def b16_cit2b5_vanilla(**overwrite):
    return Config(
        overwrite,
        cit_dir=CIT_IDX_2B5, # equivalent of index_dir
        train_data=CIT_DATA_2B5,
        inmem=True,
        engine="train_one_epoch_ex",
        model="ViT-B-16",
        lr=0.0005,
        grad_checkpointing=True,
        eval_steps=5000,
        save_steps=2000,
        save_frequency=1,
        workers=6,
        train_num_samples=400_000_000,
        nodes=16, ngpus=4, 
        quick_start_init=QKS_CKPT_B16_2B5,
    )

def l14_cit400m_vanilla(**overwrite):
    # ignore the hurt from face bluring, 
    # still use the same data
    return Config(
        overwrite,
        cit_dir=CIT_IDX, # equivalent of index_dir
        train_data=CIT_DATA,
        inmem=True,
        engine="train_one_epoch_ex",
        model="ViT-L-14",
        lr=0.0004,
        grad_checkpointing=True,
        eval_steps=5000,
        save_steps=1000,
        save_frequency=1,
        workers=6,
        train_num_samples=400_000_000,
        nodes=16, ngpus=8, 
        quick_start_init=QKS_CKPT_L14,
    )


def l14_cit400m_fm_vanilla(**overwrite):
    # ignore the hurt from face bluring, 
    # still use the same data
    return Config(
        overwrite,
        cit_dir=CIT_IDX_AUG, # equivalent of index_dir
        train_data=CIT_DATA_AUG,
        inmem=True,
        engine="train_one_epoch_ex",
        model="ViT-L-14",
        lr=0.0004,
        grad_checkpointing=True,
        eval_steps=5000,
        save_steps=1000,
        save_frequency=1,
        workers=6,
        train_num_samples=400_000_000,
        nodes=32, ngpus=4, 
        quick_start_init=QKS_CKPT_L14_AUG,
    )


def l14_cit2b5_vanilla(**overwrite):
    # ignore the hurt from face bluring, 
    # still use the same data
    return Config(
        overwrite,
        cit_dir=CIT_IDX_2B5, # equivalent of index_dir
        train_data=CIT_DATA_2B5,
        inmem=True,
        engine="train_one_epoch_ex",
        model="ViT-L-14",
        lr=0.0004,
        grad_checkpointing=True,
        eval_steps=5000,
        save_steps=1000,
        save_frequency=1,
        workers=6,
        train_num_samples=400_000_000,
        nodes=32, ngpus=4,
        quick_start_init=QKS_CKPT_L14_2B5,
    )

def clip_eval():
    return b32_cit400m_vanilla(
        model="ViT-B-16", seed=49, 
        # model="ViT-L-14", seed=49, 
        num_groups=0,evaluate_train=False,
    )

def ori_eval():
    return b32_cit400m_vanilla(
        model="ViT-L-14",
        num_groups=0, seed=48, 
        evaluate_train=False,
        force_quick_gelu=False,
    )

def b32_cit400m_vanilla_long():
    return b32_cit400m_vanilla(epochs=37)

def b32_cit400m_vanilla_tunelong():
    return b32_cit400m_vanilla(
        init_epoch=27,
        train_num_samples=800_000_000,
    )

def b32_cit2b5_vanilla_tunelong():
    return b32_cit2b5_vanilla(
        init_epoch=27,
        train_num_samples=800_000_000,
        resume='/private/home/phoenixma/project/M2C2_CLIP_BTM/logs/b32_cit2b5_vanilla_tunelong1x64_init27/checkpoints/epoch_latest.pt'
    )
# =======================================
# Async CLIP
# =======================================

def b32_cit400m_async_csebert_full(**overwrite):
    return b32_cit400m_vanilla(
        group_dir=SIMCSE_BERT,
        cluster_key='K8B1', soft_cluster=0.4, 
        cluster_id=0, init_epoch=27, 
        loss='ClipDeDupLoss', rerun=1, debuging=True,
        # resume='/private/home/phoenixma/project/M2C2_CLIP_BTM/logs/b32_cit400m_async_csebert_full1x64/K8B1C0O0.4_init26/checkpoints/epoch_latest_epoch.pt'
    )

def b32_cit400m_async_csebertcos_full(**overwrite):
    return b32_cit400m_vanilla(
        group_dir=SIMCSE_BERTCOS,
        cluster_key='K8B1', soft_cluster=0.2, 
        cluster_id=0, init_epoch=27, 
    )

# =======================================
#  Hierarchical Sampling
# =======================================
def b32_cit400m_async_csebert_hrchy(**overwrite):
    return b32_cit400m_vanilla(
        group_dir=SIMCSE_BERT,
        cluster_key='K1024B1', soft_cluster=0.2, fine_mode='H4B0C1', init_epoch=27, cut=-1, fuseavg=False, must_cls=-1, fusemust=False, 
        dataset_arg=('IterativeHrchyWebDataset',{}),
        resume='/private/home/phoenixma/project/M2C2_CLIP_BTM/logs/b32_cit400m_async_csebert_hrchy1x64/K1024B1_H4B0C1CNO0.2_init27/checkpoints/epoch_latest.pt'
        # resume='/private/home/phoenixma/project/M2C2_CLIP_BTM/logs/b32_cit2b5_async_csebert_hrchy1x64/K1024B1_ImgNetAvgCNO0.2_init7/checkpoints/epoch_latest.pt',
    )

# def b32_cit400m_async_csebert_hrchy(**overwrite):
#     return b32_cit400m_vanilla(
#         group_dir=SIMCSE_BERT,
#         cluster_key='K1024B1', soft_cluster=0.2, fine_mode='CLIPAvg', init_epoch=27, cut=-1, fuseavg=False, must_cls=10, fusemust=False,
#         dataset_arg=('IterativeHrchyWebDataset',{'thre_ic':0.0, 'thre_ooc':0.0, 'rand_ic':0.0, 'rand_ooc':0.0}),
#         resume='/private/home/phoenixma/project/M2C2_CLIP_BTM/logs/b32_cit400m_async_csebert_hrchy1x64/K1024B1_CLIPAvgCNO0.2_init27/checkpoints/epoch_latest.pt',
#     )

def b32_cit2b5_async_csebert_random(**overwrite):
    return b32_cit2b5_vanilla(
        group_dir=SIMCSE_BERT_FCC,
        cluster_key='K1024B1', soft_cluster=0.02, fine_mode='R4C0', init_epoch=27, cut=-1, fuseavg=False, must_cls=-1, fusemust=False, 
        dataset_arg=('IterativeHrchyWebDataset',{}), # debuging=True
        # resume='/private/home/phoenixma/project/M2C2_CLIP_BTM/logs/b32_cit2b5_async_csebert_hrchy1x64/K1024B1_H16B0C8CNO0.02_init27/checkpoints/epoch_latest.pt',
    )

def b32_cit2b5_async_csebert_hrchy(**overwrite):
    return b32_cit2b5_vanilla(
        group_dir=SIMCSE_BERT_FCC, debuging=True,
        cluster_key='K1024B1', soft_cluster=0.02, fine_mode='H4B0C2', init_epoch=27, cut=-1, fuseavg=False, must_cls=-1, fusemust=False, 
        dataset_arg=('IterativeHrchyWebDataset',{}), # debuging=True
        # resume='/private/home/phoenixma/project/M2C2_CLIP_BTM/logs/b32_cit2b5_async_csebert_hrchy1x64/K1024B1_H32B0C16CNO0.02_init27/checkpoints/epoch_latest.pt',
    )

def b32_cit400m_asoft_csebert_hrchy(**overwrite):
    return b32_cit400m_vanilla(
        group_dir=SIMCSE_BERT, debuging=True,
        cluster_key='K1024B1', fine_mode='ImgNetAvg', init_epoch=27, 
        dataset_arg=('IterativeHrchySoftWebDataset',{'cluster_dist_scaler':14.5,'sample_dist_scaler':0,'cs_joint':False, 'topk':100}),
    )

def b32_cit2b5_asoft_csebert_hrchy(**overwrite):
    return b32_cit2b5_vanilla(
        group_dir=SIMCSE_BERT_FCC, 
        cluster_key='K1024B1', fine_mode='ImgNetAvg', init_epoch=27, 
        dataset_arg=('IterativeHrchySoftWebDataset',{'cluster_dist_scaler':12.0,'sample_dist_scaler':-1,'cs_joint':False, 'topk':50}),
        # resume='/private/home/phoenixma/project/M2C2_CLIP_BTM/logs/b32_cit2b5_asoft_csebert_hrchy1x64/K1024B1_ImgNetAvgC10.0T50_init27/checkpoints/epoch_latest.pt'
    )

def b16_cit2b5_async_csebert_hrchy(**overwrite):
    return b16_cit2b5_vanilla(
        group_dir=SIMCSE_BERT_FCC,
        cluster_key='K1024B1', soft_cluster=0.02, fine_mode='H8B0C2', init_epoch=27, cut=-1, fuseavg=False, must_cls=-1, fusemust=False, 
        dataset_arg=('IterativeHrchyWebDataset',{}), 
        resume='/private/home/phoenixma/project/M2C2_CLIP_BTM/logs/b16_cit2b5_async_csebert_hrchy1x64/K1024B1_H8B0C2CNO0.02_init27/checkpoints/epoch_latest.pt',
    )

def b16_cit400m_async_csebert_hrchy(**overwrite):
    return b16_cit400m_vanilla(
        group_dir=SIMCSE_BERT,
        cluster_key='K1024B1', soft_cluster=0.2, fine_mode='H2B0C0', init_epoch=27, cut=-1, fuseavg=False, must_cls=-1, fusemust=False, 
        dataset_arg=('IterativeHrchyWebDataset',{}),
        resume='/private/home/phoenixma/project/M2C2_CLIP_BTM/logs/b16_cit400m_async_csebert_hrchy1x64/K1024B1_H4B0C0CNO0.2_init27/checkpoints/epoch_latest.pt',
    )

def l14_cit2b5_async_csebert_hrchy(**overwrite):
    return l14_cit2b5_vanilla(
        group_dir=SIMCSE_BERT_FCC,
        cluster_key='K1024B1', soft_cluster=0.02, fine_mode='H2B1C0', init_epoch=24, cut=-1, fuseavg=False, must_cls=-1, fusemust=False,
        dataset_arg=('IterativeHrchyWebDataset',{}),
        resume='/private/home/phoenixma/project/M2C2_CLIP_BTM/logs/l14_cit2b5_async_csebert_hrchy1x128/K1024B1_H2B1C0CNO0.02_init24/checkpoints/epoch_latest.pt',
        # rerun=1, resume='/private/home/phoenixma/project/M2C2_CLIP_BTM/logs/l14_cit2b5_async_csebert_hrchy1x128/K1024B1_H4B0C3CNO0.02_init27_run1/checkpoints/epoch_latest.pt',
    )

def l14_cit400m_async_csebert_hrchy(**overwrite):
    return l14_cit400m_fm_vanilla(
        group_dir=SIMCSE_BERT_AUG, debuging=True,
        cluster_key='K1024B1', soft_cluster=0.2, fine_mode='H4B0C0', init_epoch=29, cut=-1, fuseavg=False, must_cls=-1, fusemust=False, 
        dataset_arg=('IterativeHrchyWebDataset',{}),
        resume='/private/home/phoenixma/project/M2C2_CLIP_BTM/logs/l14_cit400m_async_csebert_hrchy1x128/K1024B1_H4B0C0CNO0.2_init29/checkpoints/epoch_latest.pt',
    )

# def l14_cit400m_async_csebert_hrchy(**overwrite):
#     return l14_cit400m_vanilla(
#         group_dir=SIMCSE_BERT,
#         cluster_key='K1024B1', soft_cluster=0.2, fine_mode='ImgNetInd', init_epoch=27, cut=1, fuseavg=True, must_cls=-1, fusemust=False, 
#         dataset_arg=('IterativeHrchyWebDataset',{}),
#         # resume='/private/home/phoenixma/project/M2C2_CLIP_BTM/logs/l14_cit400m_async_csebert_hrchy1x128/K1024B1_ImgNetAvgC1O0.2_init27/checkpoints/epoch_latest.pt',
#     )

