import os
import torch
import uuid
import random
import functools

from pathlib import Path
from transformers import AutoModel, AutoTokenizer, BertLayer
from tqdm import tqdm

import torch
from torch import nn
from torch import distributed as dist
from torch.profiler import profile, record_function, ProfilerActivity

import sys


batch_size = 44

if 'LOCAL_RANK' in os.environ:
    """torchrun --nproc_per_node=8 demos/pytorch/demo_dist.py"""
    rank = device = int(os.environ['LOCAL_RANK'])
    world_size = int(os.environ['WORLD_SIZE'])
    dist.init_process_group(backend="nccl")
    print("distributed-{}".format(device))
else:
    rank = device = 0


def send_recv():
    if rank == 0:
        tensor = torch.ones(16, device=rank)  # must be on cuda to use nccl to transfer
        with profile() as prof:
            for dst in range(1, world_size):
                with record_function("send"):
                    dist.send(tensor=tensor, dst=dst)
        print(prof.key_averages().table(sort_by="cpu_time_total", row_limit=10))
    else:
        tensor = torch.empty(16, device=rank)
        dist.recv(tensor=tensor, src=0)
        # print(rank, tensor)


def isend_recv():
    if rank == 0:
        tensor = torch.ones(1024, device=rank)  # must be on cuda to use nccl to transfer
        with profile() as prof:
            for dst in range(1, world_size):
                with record_function("send"):
                    dist.isend(tensor=tensor, dst=dst)
        print(prof.key_averages().table(sort_by="cpu_time_total", row_limit=10))
    else:
        tensor = torch.empty(1024, device=rank)
        dist.irecv(tensor=tensor, src=0)
        # print(rank, tensor)


def all_reduce(async_op):
    tensor = torch.ones(1024, device=rank)
    with profile() as prof:
        with record_function("all_reduce"):
            dist.all_reduce(tensor, op=dist.ReduceOp.SUM, async_op=async_op)
    if rank == 0:
        print(prof.key_averages().table(sort_by="cpu_time_total", row_limit=10))


def broadcast(async_op=False):
    tensor = torch.empty(1, device=rank).fill_(rank)
    dist.broadcast(tensor, src=5, async_op=async_op)
    print(tensor)


def all_gather():
    tensor = torch.empty(1, device=rank).fill_(rank)
    tensors = [torch.empty(1, device=rank) for _ in range(world_size)]
    dist.all_gather(tensors, tensor)
    if rank == 0:
        print(tensors)


def all_gather_object():
    gather_objects = ["foo", 12, {1: 2}, "foo", 12, {1: 2}, "foo", 12, {1: 2}]
    output = [None for _ in range(world_size)]
    dist.all_gather_object(output, gather_objects[dist.get_rank()])
    if rank == 0:
        print(output)


def scatter():
    output = torch.empty(1, device=rank)
    scatter_list = [torch.fill(torch.empty(1, device=rank), _rank+rank*world_size) for _rank in range(world_size)]
    print('scatter_list-{}-{}'.format(rank, scatter_list))
    dist.scatter(output, scatter_list, src=rank)
    print('output-rank{}-{}'.format(rank, output))
    # if rank == 0:
    #     print(output)


def reduce_scatter():
    output = torch.empty(1, device=rank)
    scatter_list = [torch.fill(torch.empty(1, device=rank), _rank) for _rank in range(world_size)]
    print('scatter_list', rank, scatter_list)
    dist.reduce_scatter(output, scatter_list)
    print('output', rank, output)


def all_to_all():
    output_scatter_list = [torch.empty(1, device=rank) for _rank in range(world_size)]
    scatter_list = [torch.fill(torch.empty(1, device=rank), _rank) for _rank in range(world_size)]
    dist.all_to_all(output_scatter_list, scatter_list)
    print(rank, output_scatter_list)


def all_to_all_single():
    input = torch.arange(4,device=rank).float() + rank * 4
    print('input rank-{}-{}'.format(rank,input))
    output = torch.empty([4], device=rank)
    print('preout rank-{}-{}'.format(rank,output))
    dist.all_to_all_single(output, input)
    print('postout rank-{}-{}'.format(rank,output))

    # output_scatter_list = [torch.empty(1, device=rank) for _rank in range(world_size)]
    # scatter_list = [torch.fill(torch.empty(1, device=rank), _rank) for _rank in range(world_size)]
    # dist.all_to_all(output_scatter_list, scatter_list)
    # print(rank, output_scatter_list)


# send_recv()  
# isend_recv()

# all_reduce(True)  # all_reduce(False)

# broadcast()

# all_gather()
# all_gather_object()  # not working for nccl.

all_to_all_single()

# reduce_scatter()

# all_to_all()
