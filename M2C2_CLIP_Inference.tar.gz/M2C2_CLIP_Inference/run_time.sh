# PORT=0
GPUS=1
set -x

# CUDA_VISIBLE_DEVICES=${GPUS} torchrun --master_port=226${GPUS}0 --nproc_per_node=1 src/training_local/main.py b32_cit400m_vanilla
CUDA_VISIBLE_DEVICES=${GPUS} torchrun --master_port=226${GPUS}0 --nproc_per_node=1 src/training_local/main.py b16_cit400m_vanilla
CUDA_VISIBLE_DEVICES=${GPUS} torchrun --master_port=226${GPUS}0 --nproc_per_node=1 src/training_local/main.py l14_cit400m_vanilla
